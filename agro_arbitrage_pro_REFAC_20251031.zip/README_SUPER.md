# SUPER ARCHIVE

This bundle contains:
- **Original project**: `agro_arbitrage_pro_final` (as base, preserved structure)
- **Integrated Upgrade Pack**: added into the same tree under respective folders
  - `python_app/engine/execution_gateway.py` (idempotent orders + per-symbol/exchange queues + retries)
  - `risk/risk_hub.py` (limits, circuit breaker)
  - `marketdata/ws_manager.py` (snapshot+delta, heartbeat stub)
  - `telemetry/server.py` (Prometheus metrics)
  - basic `tests/` (pytest)
  - `docs/README_UPGRADE.md`
  - CI workflow copy as `ci_upgrade.yml` if conflicts; docker-compose as `docker-compose.upgrade.yml`

## Quick Start (Upgrade Demo)
```bash
cd python_app
pip install -r requirements.txt
python main.py
# Metrics at http://localhost:9102/metrics
```

## Notes on Integration
- We avoided overwriting existing files. If a filename collided, an `*.upgrade.*` copy was created.
- Review diffs and merge settings into your production paths (secrets, real exchange adapters).
- Keep your existing CI; consider merging rules from `ci_upgrade.yml` into `.github/workflows/ci.yml`.
