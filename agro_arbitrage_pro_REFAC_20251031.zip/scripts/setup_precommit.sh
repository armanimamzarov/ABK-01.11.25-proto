#!/usr/bin/env bash
set -euo pipefail
python -m pip install --upgrade pip pre-commit ruff mypy black
pre-commit install
echo "Pre-commit installed. Hooks: ruff, ruff-format, mypy, black."
