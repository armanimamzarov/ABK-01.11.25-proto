# RUNBOOK

## Services
- core (Rust) — market data, execution, risk
- py (Python) — strategies, simulator, orchestration
- prometheus, grafana

## Health
- `/metrics` on ports 9100 (core) and 9200 (py)
- Grafana dashboards in folder "Agro"

## Incidents
- High rejects → check `order_reject_total{code}` and gateway connectivity
- Stale WS → resubscribe, verify time sync (Chrony/NTP), network
- Kill switch active → inspect risk events and inventory breaches

## Playbooks
- Resync orderbooks on gap detection or sequence mismatch
- Rotate keys safely; never commit secrets

## Backups & Recovery
- Configs in `/configs/*.yaml` with comments and defaults

## Incident Playbooks
- WS Gap: verify `book_seq_skips`, `ws_gap_total`, trigger resync via adapter; confirm fresh snapshot.
- Reject Flood: check `order_reject_total{code}`, categorize by `category`, enable cancel-on-fail.
- Orphan Legs: monitor `orphan_leg_seconds`, ensure hedge path; consider increasing orphan timer.
- Kill Switch: `kill_switch_active=1` → wait for `cooldown_seconds` to drop to 0; auto re-enable.
