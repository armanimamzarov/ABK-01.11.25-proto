# Agro Arbitrage Pro — READY BUILD

## Quick Start
1) Скопируйте `configs/exchanges.json.sample` → `configs/exchanges.json` и заполните ключи.
2) Проверьте `configs/global_config.json` (лимиты риска и параметры SOR/MD gate).
3) Запуск dev-окружения:
```bash
docker compose up -d --build
```
Сервисы:
- `python_app` — API `:8081/health`, метрики `/metrics`
- `rust_core` — gRPC
- `postgres`, `redis`, `prometheus`, `grafana`

## Что добавлено в этой сборке
- Adaptive Limit Pricing
- Smart Order Router (fees/latency/slippage aware)
- Orphan Hedge Dagger (таймаут + notional guard)
- Rate Limit Manager per venue/endpoint
- Market Data Quality Gate (gap/seq/staleness)
- Обновлённые конфиги и базовые тесты на новые модули

## Мини-гайд по продекшену
- Включите `reduce_only_on_trip=true` для мягкой деградации при kill-switch.
- Настройте лимиты rate-limit'ов per endpoint в `python_app/core/rate_limit_manager.py` (регистрация бакетов).
- Запустите нагрузочные прогоны и проверьте p95/p99 латентность исполнения и orphan_leg_seconds.


## Что обновлено в READY2
- Reduce-Only/Quotes-Only режимы при триггере kill-switch (python_app/core/risk_modes.py)
- Нормализация reject-кодов per exchange (configs/reject_codes.json + core/reject_normalizer.py)
- Clock/Nonce guard (core/clock_guard.py)
- Cancel-on-Disconnect политики (core/cof_policies.py)
- Event-Sourcing журнал для восстановления (core/event_journal.py)
- Impact/Slippage модель для симуляции (simulator/impact_model.py)
- Chaos/Reject/Clock/Event тесты (tests_extra/*)
- Grafana дашборд-шаблоны (ops/grafana/dashboards/)
\n\n### TAO + ML (Contextual Bandit)\n- Запуск локально: `python -m python_app.tao.launcher`\n- Модель LinUCB хранится в `db/tao_linucb.json` и обучается онлайн по PnL.\n- Действия агента: `sor-fast`, `sor-cheap`, `hedge-tight`; можно расширять.\n