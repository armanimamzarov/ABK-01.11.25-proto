# AGRO Arbitrage PRO — Полный продакшен RUNBOOK (Canary → GA)

> Версия: 1.0 • Последнее изменение: сегодня  
> Цель: безопасно запустить систему арбитража в продакшене, обнаруживать/локализовать сбои и быстро откатываться.

---

## 0. Термины и контур
- **Trader** – Python-приложение (стратегии, риск, gateway_v2).
- **Core** – Rust ядро (низкий уровень/стриминг/утилиты).
- **Adapters** – биржевые драйверы (Binance/Bybit/OKX).
- **MD** – маркет-дата (WS/REST).
- **Recon** – сверка сделок/позиций/балансов с биржами.
- **SRE Stack** – Prometheus/Grafana/Alertmanager.
- **Kill-switch** – принудительный выход: cancel open + flatten/hedge.

---

## 1. SLO / Guardrails (обязательно перед запуском)
### 1.1 SLO
- **ACK latency p99** ≤ **1200 ms** (5 минут подряд – алерт).
- **Reject rate** ≤ **2%** на окно 5 минут.
- **WS heartbeat** – 0 пропусков на 2 минуты (иначе предупреждение).
- **Clock skew** ≤ **50 ms**.
- **Intraday DD** ≤ **3%** от дневного лимита риска.

### 1.2 Kill-switch триггеры
- `ws_gaps` > 5 за 2 минуты → Kill.
- `intraday_dd_pct` > 3.0 → Kill.
- `reject_rate_pct` > 2% → Degrade (урезать агрессию, понизить лимиты).
- `ack_p99_ms` > 1200 ms → Degrade.

### 1.3 Обязательные флаги
- По умолчанию **LIMIT + post_only**.
- Для хеджа **reduce_only**.
- MARKЕТ/IOC только при `max_slippage_bps` выполнен.

---

## 2. Предзапуск: чек-лист (T-48h → T-1h)

### 2.1 Инфраструктура
- [ ] NTP/PTP синхронизация на всех нодах (clock skew < 50ms).
- [ ] Отдельные узлы/пулы для WS и REST (сетевой QoS).
- [ ] Secrets через Vault/K8s Secrets/SealedSecrets (*не* .env).
- [ ] Разделить **prod** и **testnet** аккаунты/ключи/IP whitelist.

### 2.2 Данные и схемы
- [ ] Применить SQL миграции:
  ```bash
  psql "$DATABASE_URL" -f migrations/0001_orders_outbox.sql
  psql "$DATABASE_URL" -f migrations/0002_positions_snapshots.sql
  psql "$DATABASE_URL" -f migrations/0003_recon_ledger.sql
  ```
- [ ] Инициализировать спецификации символов (tick/step/minNotional).
- [ ] Проверить полноту `global_config.yaml` (execution/risk/router/venues/observability).

### 2.3 Мониторинг/алерты
- [ ] Prometheus/Alertmanager/Grafana задеплоены (см. `monitoring/` и `charts/agro/templates/prometheus-rules.yaml`).
- [ ] Дашборды импортированы: `monitoring/grafana/dashboards/execution.json`.
- [ ] Тест алертов: искусственно поднять метрику и убедиться в доставке уведомления.

### 2.4 Безопасность/Доступы
- [ ] Ограничение по IP для биржевых API.
- [ ] Ротация HMAC-ключей раз в N дней.
- [ ] RBAC: только «on-call» имеет право выкатывать/останавливать Trader.

### 2.5 Репетиция аварии (Game Day)
- [ ] Прервать WS и наблюдать auto-resubscribe + gap-fill.
- [ ] Смоделировать RejectBurst (например, precision fail) – алерт и деградация.
- [ ] Нажать Kill-switch (тестовый) – bulk cancel + flatten.

---

## 3. Подготовка приложения
### 3.1 Включить hardened компоненты
- Gateway: `ExecutionGatewayV2`.
- Router: `BestVenueRouter` (weights в `global_config.yaml`).
- Risk: `RiskGuard` + `kill/degrade` hooks.
- Recon: `ReconWorkerV2` по расписанию.

### 3.2 Health/metrics
- Экспонировать `/metrics` (python_app:9101, rust_core:9102) и `/health`:
  ```bash
  curl -sf http://python_app:9101/health
  curl -sf http://python_app:9101/metrics | head
  ```

### 3.3 Настройки стратегий
- Постоянно `post_only`, кроме хеджа.
- `max_slippage_bps` ≤ 5 (под продуктовую ликвидность).
- Порог количества открытых ордеров/скорости – в `execution.per_symbol_backpressure`.

---

## 4. Канареечный релиз (T-0)

### 4.1 Режим **Shadow** (30–60 мин)
- [ ] Стратегии выполняются, но постановка ордеров **post_only** и объём **0%** (или направлять только в dry-run).
- [ ] Сравнить «ожидаемые» арбитражные спреды с «реальными» market data (ошибка < 10 bps).
- [ ] Метрики: ACK отсутствуют (нет ордеров) — но латентности и WS/REST стабильны.

### 4.2 **Canary 1%** (30–60 мин)
- [ ] Включить отправку ордеров с объёмом 1% от целевого дневного лимита.
- [ ] Контрольные метрики:
  - p99 ACK < 1200 ms
  - Reject rate < 1%
  - WS gaps = 0
  - Backlog < 20
- [ ] Recon: EOD/инкрементальная сверка — **0 расхождений**.

### 4.3 **Canary 5–10%** (60–120 мин)
- [ ] Постепенно поднять объёмы шагами (1 → 5 → 10%).
- [ ] Наблюдать funding/fees и фактический PnL **по стратегиям** (нет «утечек»).
- [ ] Проверить kill/degrade: вызвать тестовую деградацию, убедиться в снижении нагрузки.

### 4.4 **Go/No-Go**
- No-Go причины: p99 > 1200ms (устойчиво), Reject > 2%, recon mismatch > 0, частые WS gaps, сильный negative slippage.
- При No-Go → **Rollback** (см. §7).

### 4.5 **Ramp-up до 100%**
- Поднимаем 25% → 50% → 100% с интервалами 30–60 мин при стабильных SLO.
- Включаем дополнительные стратегии только после стабилизации базовых.

---

## 5. Операционные процедуры (Run-time)

### 5.1 Ежечасный чек-лист
- [ ] `ACK p99` < 1200ms
- [ ] `reject_rate` < 2%
- [ ] `order_backlog` стабилен, без тренда вверх
- [ ] `risk_kill_switch_total` не растёт
- [ ] `recon` mismatch = 0

### 5.2 Flatten & Exit (Kill-switch)
1. Остановить агрессивные стратегии (деградировать).
2. Выполнить `bulk cancel` по всем venue.
3. Закрыть остаточные позиции хеджем (reduce_only).
4. Проверить балансы/позиции через REST, убедиться в нуле неттинга.
5. Включить Shadow-режим для 30 мин.
6. Документировать инцидент.

### 5.3 Частые инциденты и решения
- **Burst rejects**: проверить precision/minNotional/stepSize; снизить order rate; сверить символ-спеки.
- **High ACK latency**: сетевой QoS, раскидать workload WS/REST по разным нодам, снизить объём.
- **WS gaps**: проверить gap-fill (snapshot + reapply); увеличить буфер апдейтов; прокси/пиринг.
- **Recon mismatch**: выкачать книги trades/balances повторно; сверить комиссии/фандинг; исправить локальную агрегацию.

---

## 6. Recon и учёт

### 6.1 Инкрементальная сверка (каждые 5–15 мин)
- Pull trades/positions/balances с биржи.
- Записать недостающие в `recon_ledger`.
- Алёрт при `missing>0` или `extras>0`.

### 6.2 EOD
- Снимок позиций и балансов (`positions_snapshots`).
- Отчёт: Realized/Unrealized PnL, комиссии, funding.
- Архивация логов и экспорт метрик.

---

## 7. Rollback / Rollforward

### 7.1 Rollback (безопасный откат)
- [ ] Перевести стратегии в Shadow (0% объёма).
- [ ] Выполнить Flatten & Exit.
- [ ] Откатить релиз (образы/деплой).
- [ ] Вернуть конфиги на предыдущую версию.
- [ ] Разбор инцидента; оформить Postmortem.

### 7.2 Rollforward
- Исправить дефект (конфиг/код).
- Повторить §4 (канареечный цикл).

---

## 8. Команда и роли
- **On-Call SRE** – мониторинг/алерты/решение инцидентов, рулит Kill-switch.
- **Execution Lead** – Gateway/Adapters/Router, отвечает за исполнение.
- **Strategy Lead** – профили и параметры стратегий.
- **Risk Lead** – капы, kill/degrade правила.
- **Data/Recon** – чистота учёта, EOD отчёты.

Контакты/эскалация: см. внутренний справочник.

---

## 9. Чек-листы команд

### 9.1 Быстрый старт (K8s)
```bash
# PrometheusRule (если Prometheus Operator)
kubectl apply -f charts/agro/templates/prometheus-rules.yaml

# Мониторинг локально (опционально)
docker compose -f docker-compose.monitoring.yml up -d

# Проверка сервисов
curl -sf http://python_app:9101/health
curl -sf http://rust_core:9102/metrics | head
```

### 9.2 Перед каждым повышением доли канареек
- [ ] Метрики в зелёной зоне за последние 30 мин.
- [ ] Нет активных алертов.
- [ ] Recon чистый.
- [ ] Режимы стратегий подтверждены (post_only/Reduce_only).

---

## 10. Изменение параметров на лету

### 10.1 Router Weights
- Менять `router.weights.*` → reload конфиг/Envoy (если есть).
- Наблюдать влияние на venue mix и ACK latency.

### 10.2 Risk Caps
- Менять `risk.*` и `execution.per_symbol_backpressure.*` с осторожностью.
- При увеличении лимитов – только при зелёных метриках.

---

## 11. Чистота данных и аудит
- Хеширование снапшотов EOD, хранение артефактов 90 дней+.
- Логи критических действий (kill/degrade/flatten) – с подписью ответственного.
- Регулярные сверки комиссий/фандинга.

---

## 12. Postmortem (после инцидента)
- Что сломалось? (симптомы, timeline, метрики)
- Почему? (root cause)
- Что помогло/помешало обнаружить? (детекторы)
- Как исключаем повтор? (фикс, чекап, обучение)
- Сроки выполнения действий и ответственные.

---

## Приложения
- Конфиги: `global_config.yaml` (актуальный), `monitoring/*`, `charts/*`.
- Тесты: `tests/*` (идемпотентность, retry, router, WS, risk, recon, стратегии).
- Справка по API бирж – см. внутренние wiki/документы.
