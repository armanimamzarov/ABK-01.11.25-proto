
# Agro Arbitrage Pro — Production Runbook

## 1. Подготовка окружения
- Скопируйте `.env.example` → `.env` и заполните ключи бирж, БД и Telegram.
- Убедитесь, что `configs/global_config.json` отражает ваши лимиты риска.
- Требования: Docker 24+, docker-compose 2+, 4 CPU, 8GB RAM.

## 2. Запуск
```bash
docker compose up -d --build
```
Сервисы:
- `python_app` — FastAPI: `http://localhost:8081/health`, метрики: `/metrics`
- `rust_core` — gRPC движок
- `postgres`, `redis`, `prometheus`

## 3. Наблюдаемость
- Prometheus конфиг: `./prometheus.yml`, алерты: `./configs/prometheus/alerts.yml`
- (Опционально) Grafana импортируйте: `./configs/grafana/dashboards/arbitrage_overview.json`

## 4. Тесты и CI
- Локально: `pytest -q` и `cargo test`
- CI включает ruff, mypy, bandit и cargo-audit

## 5. Безопасность
- Secrets храним в переменных окружения, не коммитим ключи.
- Ограничения риска задаются в `global_config.json`.

## 6. Реальная торговля
- Установите `TRADE_MODE=live` и включите нужные биржи в `configs/exchanges.json`.
- Задайте лимиты размеров ордеров и дневной риск.
- Включите алерты Prometheus.

## 7. Экстренная остановка
```bash
docker compose down
```
