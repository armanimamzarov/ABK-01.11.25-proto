# Changes
- Execution Gateway: token-bucket, risk hooks
- WS Aggregator: mock streams + anti-stale
- Recon: auto-cancel logic; summary metrics
- PnL: sessions & events tables

# Metrics
- orders_submitted_total, order_roundtrip_seconds, py_orders_sent_total

# Alerts
- p95 latency > 1s (5m)
- recon fixed > 10/min

# Rollback
- Redeploy previous image tags
