# ALERTS

- `orders_submitted_total` sudden drop -> Possible submission outage.
- `order_roundtrip_seconds` p95 > 1s for 5m -> Latency degradation.
- Python `py_orders_sent_total` flatline -> Client outage.
- Recon auto-cancels > 10/min -> Exchange issues.
