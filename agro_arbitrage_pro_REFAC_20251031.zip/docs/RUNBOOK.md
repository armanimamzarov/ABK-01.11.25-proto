# RUNBOOK

## Incident: Orders Stuck in Ack
1. Check /metrics on rust_core for rising retries and growing queue depth.
2. Toggle kill-switch via config and restart deployment if cascading failures.
3. Run Recon service once to auto-cancel stale orders.
4. Validate exchange connectivity and rate limits.

## Kill-Switch
- Set `app.kill_switch: true` in ConfigMap and restart pods.
