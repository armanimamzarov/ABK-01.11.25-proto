# Merge Report — agro_arbitrage_pro (SUPER + UPGRADE)
Generated: 2025-10-31T10:42:07.214879Z

Base:   /mnt/data/extract_super/agro_arbitrage_pro_super/agro_arbitrage_pro_final
Upgrade:/mnt/data/extract_upgrade/agro_arbitrage_pro_final

Strategy:
- Took **SUPER** archive as base.
- Overlaid **UPGRADE** files.
- On conflict: kept UPGRADE as primary, saved original SUPER version as `*.orig` next to the file.

Summary:
- Added files from upgrade: 13
- Updated conflicting files: 2
- Identical files skipped: 432
- Conflicts total: 2

Notes:
- Prometheus alerts and dashboard are present under `configs/prometheus/alerts.yml` and `infra/grafana/dashboards/arbitrage_overview.json`.
- CI pipeline at `.github/workflows/ci.yml`.
- Python JSON logging at `python_app/common/logging_json.py`.
- Config validator at `python_app/common/config_validator.py`.
- Order recovery (Python) in `python_app/recovery/`, (Rust) in `rust_core/src/order/recovery.rs`.
- Pre-commit tooling configured (`.pre-commit-config.yaml`, `ruff.toml`, `mypy.ini`).

Conflicted files list (sample up to 100 shown below). Full list is in `MERGE_LOG.json`.
- prometheus.yml (backup: prometheus.yml.orig)
- .github/workflows/ci.yml (backup: .github/workflows/ci.yml.orig)
