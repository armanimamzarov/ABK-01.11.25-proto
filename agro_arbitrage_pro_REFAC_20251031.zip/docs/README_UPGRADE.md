
# Upgrade Pack — Execution, Risk, WS, Metrics

Этот пак включает:
- ExecutionGateway с идемпотентностью, очередями per symbol/exchange и ретраями.
- RiskHub с лимитами и circuit breaker.
- WSManager с heartbeat и заглушкой снапшот/дельты.
- Prometheus-метрики (порт 9102).
- CI workflow + docker-compose.

## Быстрый старт (dry-run)
```bash
cd python_app
pip install -r requirements.txt
python main.py
# метрики на http://localhost:9102/metrics
```

## Интеграция в основной репозиторий
- Переместите содержимое `python_app/*` в ваш `python_app/`.
- Обновите импорты и подключите реальные адаптеры бирж вместо `DummyExchange`.
- Включите Prometheus scrape в вашей инфре.
- Расширьте тесты, подключите Postgres/Redis/Kafka для продакшена.
