# Monitoring Setup (Prometheus + Alertmanager + Grafana)

## Files
- `monitoring/prometheus.yml` — scrape configs for python app (9101), rust core (9102), node-exporter.
- `monitoring/alertmanager.yml` — stub receiver; replace with your endpoint.
- `charts/agro/templates/prometheus-rules.yaml` — PrometheusRule with SLO alerts.
- `monitoring/grafana/dashboards/execution.json` — prebuilt dashboard.

## Notes
- `order_ack_latency_ms` is a Histogram — use `_bucket` for quantiles (see alert and dashboard examples).
- Ensure your services expose `/metrics` on the ports above or adjust targets.
- For Kubernetes, apply the `PrometheusRule` (needs Prometheus Operator) and point Grafana to Prometheus.
