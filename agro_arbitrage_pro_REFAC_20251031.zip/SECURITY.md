# Security Policy

- Do not commit secrets. Use `.env` locally and secret managers in prod.
- Rotate any leaked keys immediately.
- Dependencies are pinned via requirements/pyproject; update with care.
- Report vulnerabilities privately to maintainers.
