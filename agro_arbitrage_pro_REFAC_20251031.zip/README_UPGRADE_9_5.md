# Upgrade Pack — Toward 9.5/10

This pack adds **production-grade** blocks without stubs:
- Pre-commit + Ruff + Mypy + Black
- Unified JSON logging (Python & Rust)
- Config validator with strict environment checks
- Order Recovery (SQLite) with reconciler loop
- Prometheus alerts + Grafana dashboard
- CI (Python + Rust) on GitHub Actions

## How to enable

1. Install hooks  
```bash
bash scripts/setup_precommit.sh
```

2. Validate config on startup (Python):
```python
from python_app.common.config_validator import validate_env
validate_env()
```

3. Use JSON logging (Python):
```python
from python_app.common.logging_json import setup_json_logging
setup_json_logging()
```

4. Persist every order event:
```python
from python_app.recovery.order_store import OrderStore, OrderRecord
store = OrderStore()
# store.upsert(OrderRecord(...))
```

5. Start reconciler (standalone daemon):
```python
from python_app.recovery.reconciler import Reconciler
# provide real exchange adapters with .query_order(symbol, client_order_id)
Reconciler({ "binance": binance_adapter, "okx": okx_adapter }).run_forever()
```

6. Prometheus
- `prometheus.yml` now includes `rule_files: configs/prometheus/alerts.yml`

7. Grafana
- Import `infra/grafana/dashboards/arbitrage_overview.json`

8. Rust
- Init logging:
```rust
mod logging;
fn main() { logging::init_json(); /* ... */ }
```
- Use `order::recovery::OrderStore` in Rust components to mirror Python store.

Generated: 2025-10-31T10:40:09.076313Z
