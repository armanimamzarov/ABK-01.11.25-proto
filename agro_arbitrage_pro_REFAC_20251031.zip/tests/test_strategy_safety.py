import asyncio
import types
from python_app.strategies.base_arbitrage import BaseArbitrage, Market

class DummyPort:
    def size(self, symbol, px): return 0.01
    def net_notional_usd(self): return 0.0
    def symbol_notional_usd(self, symbol): return 0.0
    def open_orders(self, venue, symbol): return 0
    def order_rate(self, venue, symbol): return 0

class DummyGW:
    async def place(self, *args, **kwargs): return {"status":"ack"}

class DummyRouter:
    def choose(self, symbol, side): return "binance"

class DummyRisk:
    def pre_order(self, *a, **k): return None

class MiniStrat(BaseArbitrage):
    NAME = "mini"
    async def run(self):
        m = Market(bid=100, ask=101)
        return await self.place_limit_passive("BTCUSDT", "BUY", 0.01, m, 0.5)

def test_passive_limit_exec():
    s = MiniStrat({"execution":{"max_slippage_bps":5}}, DummyPort(), DummyGW(), DummyRouter(), DummyRisk())
    res = asyncio.get_event_loop().run_until_complete(s.run())
    assert res["status"] == "ack"
