import asyncio
from python_app.execution.gateway_v2 import ExecutionGatewayV2
from python_app.execution.router import BestVenueRouter, MarketSnapshot

class DummyAdapter:
    class TemporaryError(Exception):
        def __init__(self, message, reason="NetworkError"):
            super().__init__(message); self.reason=reason
    class ValidationError(Exception): pass
    def __init__(self):
        self.calls = 0
    async def send_order(self, client_order_id: str, **payload):
        self.calls += 1
        if self.calls == 1:
            raise DummyAdapter.TemporaryError("net", reason="NetworkError")
        return {"ack": True}
    async def bulk_cancel(self, symbol=None): return {"count": 0}
    async def sleep(self, seconds: float):
        await asyncio.sleep(0)

class DummyMD:
    def get_snapshot(self, venue, symbol):
        return MarketSnapshot(bid=100, bid_qty=1, ask=101, ask_qty=1, ts_ms=10**12, latency_ms=10)

class DummyFee:
    def taker_fee_bps(self, venue, symbol): return 1.0
    def maker_fee_bps(self, venue, symbol): return 0.0

class DummyBP:
    def backlog(self, venue, symbol): return 0
    def rate_ok(self, venue): return True

def test_gateway_retries_then_ack(monkeypatch):
    cfg = {
        "execution":{"default_time_in_force":"GTC","default_flags":["post_only"],"per_symbol_backpressure":{"max_inflight_orders":50}},
        "router":{"candidates":["v"],"weights":{"spread_bps":1,"top_qty":1,"fee_bps":1,"latency_ms":1}}
    }
    adapters = {"v": DummyAdapter()}
    md, fee, bp = DummyMD(), DummyFee(), DummyBP()
    router = BestVenueRouter(cfg, md, fee, bp)

    class DummyDB:
        def cursor(self): return self
        def __enter__(self): return self
        def __exit__(self, a,b,c): return False
        def execute(self, *a, **k): self._last=a
        def fetchone(self): return ["00000000-0000-0000-0000-000000000000"]
    gw = ExecutionGatewayV2(cfg, DummyDB(), adapters, router)

    loop = asyncio.get_event_loop()
    res = loop.run_until_complete(gw.place("s","v","BTCUSDT","BUY",0.1,100.0,"LIMIT"))
    assert res["status"] == "ack"
