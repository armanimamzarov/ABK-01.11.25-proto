
from python_app.engine.circuit_breaker import CircuitBreaker

class R:
    def __init__(self): self.k={}
    def get(self,k): return self.k.get(k)
    def set(self,k,v, ex=None): self.k[k]=v
    def incr(self,k): self.k[k]=int(self.k.get(k,0))+1; return self.k[k]
    def expire(self,k,ttl): pass
    def delete(self,k): self.k.pop(k, None)

def test_cb():
    r=R(); cb=CircuitBreaker(r, threshold=2, cooldown_sec=60)
    assert not cb.is_open("V","op")
    cb.incr_failure("V","op")
    assert not cb.is_open("V","op")
    cb.incr_failure("V","op")
    assert cb.is_open("V","op")
