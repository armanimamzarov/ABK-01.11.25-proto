from python_app.execution.retry_policy import get_rule

def test_retry_map_has_expected_reasons():
    assert get_rule("NetworkError") is not None
    assert get_rule("RateLimit").max_retries >= 5
    assert get_rule("ExchangeDown").backoff_ms >= 500
    assert get_rule("ValidationError") is None
