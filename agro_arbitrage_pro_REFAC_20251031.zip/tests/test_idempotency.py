import types
from python_app.execution.idempotency import IdempotencyRegistry
from python_app.execution.order_state import OrderState

class MemCursor:
    def __init__(self, db): self.db = db; self.result=None
    def execute(self, sql, args):
        sql_low = sql.lower()
        if "insert into orders_outbox" in sql_low and "on conflict" in sql_low:
            coid = args[10]
            if coid not in self.db:
                self.db[coid] = {"order_uid": args[0]}
            self.result = [(self.db[coid]["order_uid"],)]
        elif "update orders_outbox set state" in sql_low:
            coid = args[2]
            if coid in self.db:
                self.db[coid]["state"] = args[0]
        elif "update orders_outbox set retry_count" in sql_low:
            coid = args[1]
            self.db.setdefault(coid, {})["retry_count"] = self.db.get(coid,{}).get("retry_count",0) + 1
            self.result = [(self.db[coid]["retry_count"],)]
        else:
            self.result=None
    def fetchone(self): return self.result[0] if self.result else None
    def __enter__(self): return self
    def __exit__(self, exc_type, exc, tb): return False

class MemConn:
    def __init__(self): self.store = {}
    def cursor(self): return MemCursor(self.store)
    def __enter__(self): return self
    def __exit__(self, exc_type, exc, tb): return False

def test_idempotency_ensure_and_update_state():
    conn = MemConn()
    idem = IdempotencyRegistry(conn)
    coid = "test-venue-abc"
    uid1 = idem.ensure_outbox(coid, {
        "order_uid":"11111111-1111-1111-1111-111111111111",
        "strategy":"s","venue":"v","symbol":"X","side":"BUY","ord_type":"LIMIT","tif":"GTC","qty":1,"price":1.0,"flags":[]
    })
    uid2 = idem.ensure_outbox(coid, {
        "order_uid":"22222222-2222-2222-2222-222222222222",
        "strategy":"s","venue":"v","symbol":"X","side":"BUY","ord_type":"LIMIT","tif":"GTC","qty":1,"price":1.0,"flags":[]
    })
    assert str(uid1) == str(uid2)  # same coid => same order_uid returned

    idem.update_state(coid, OrderState.ACK)
    idem.inc_retry(coid, "NetworkError")
    assert conn.store[coid]["retry_count"] == 1
