import pytest
import asyncio
from python_app.exchanges.base import BaseExchangeAdapter, SymbolSpec, ValidationError, TemporaryError

class Dummy(BaseExchangeAdapter):
    async def send_order(self, client_order_id: str, **payload):
        await super().send_order(client_order_id, **payload)
        return {"ok": True}
    async def bulk_cancel(self, symbol=None): return {"count": 0}

def test_validation_rounding_and_min_notional():
    a = Dummy("x", cfg={"venues":[{"name":"x","weight_budget_per_min":60}]})
    a.set_symbol_spec(SymbolSpec("BTCUSDT", price_precision=2, qty_precision=6, tick_size=0.1, step_size=0.001, min_notional=10.0))
    # wrong price alignment
    with pytest.raises(ValidationError):
        asyncio.get_event_loop().run_until_complete(a.send_order("id", venue="x", symbol="BTCUSDT", side="BUY", ord_type="LIMIT", tif="GTC", qty=0.01, price=100.05, flags=[]))
    # ok alignment but min notional fail (qty too small)
    with pytest.raises(ValidationError):
        asyncio.get_event_loop().run_until_complete(a.send_order("id", venue="x", symbol="BTCUSDT", side="BUY", ord_type="LIMIT", tif="GTC", qty=0.0001, price=100.0, flags=[]))
    # ok
    res = asyncio.get_event_loop().run_until_complete(a.send_order("id", venue="x", symbol="BTCUSDT", side="BUY", ord_type="LIMIT", tif="GTC", qty=0.2, price=100.0, flags=["post_only"]))
    assert res["ok"] == True
