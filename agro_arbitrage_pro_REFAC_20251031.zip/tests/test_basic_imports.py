import os, importlib, pkgutil

def test_python_app_imports():
    # Try to import top-level python_app package if present
    if os.path.isdir("python_app"):
        spec = pkgutil.find_loader("python_app")
        assert spec is not None, "python_app package not importable"
