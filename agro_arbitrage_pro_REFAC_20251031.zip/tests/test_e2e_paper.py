import time
from python_app.execution.gateway import ExecutionGateway, Order
from python_app.adapters.fake_exchange import send
from python_app.simulator.replay import ReplayEngine

def test_e2e_paper_trade():
    gw = ExecutionGateway(send_func=send, metrics_port=0)
    sim = ReplayEngine(metrics_port=0)
    o = Order(client_id="", exchange="okx", symbol="ETHUSDT", side="BUY", qty=0.1, price=2000.0, hedge=True)
    cid = gw.submit(o)
    time.sleep(0.2)
    ok, exit_price = sim.submit(price=2001.0, qty=0.1, side="SELL")
    assert ok
    sim.on_close(entry=o.price, exit=exit_price, qty=0.1, side="BUY")
