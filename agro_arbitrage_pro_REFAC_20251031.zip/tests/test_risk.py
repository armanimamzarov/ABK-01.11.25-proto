
from python_app.risk.risk_hub import RiskHub, RiskConfig

def test_limits():
    r = RiskHub(RiskConfig(max_position_usd=100))
    assert r.can_place("BTC/USDT", 50)
    assert not r.can_place("BTC/USDT", 1000)
