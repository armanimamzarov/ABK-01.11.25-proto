
from python_app.engine.order_fsm import OrderState, can_transition

def test_transitions():
    assert can_transition(OrderState.NEW, OrderState.PENDING_NEW)
    assert not can_transition(OrderState.NEW, OrderState.FILLED)
