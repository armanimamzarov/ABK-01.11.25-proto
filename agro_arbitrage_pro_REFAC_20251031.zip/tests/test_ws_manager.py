
from python_app.marketdata.ws_manager import WSManager
seen = {"snap":0,"delta":0}
def on_snapshot(s): seen["snap"]+=1
def on_delta(d): seen["delta"]+=1
def test_ws_sim():
    ws = WSManager(on_snapshot, on_delta, heartbeat_seconds=5)
    ws.start()
    import time; time.sleep(2.5)
    ws.stop()
    assert seen["snap"]>=1 and seen["delta"]>=1
