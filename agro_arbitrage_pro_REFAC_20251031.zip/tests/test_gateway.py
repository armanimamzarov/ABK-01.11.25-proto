from python_app.execution.gateway import ExecutionGateway, Order
from python_app.adapters.fake_exchange import send

def test_idempotency_and_retry():
    gw = ExecutionGateway(send_func=send, metrics_port=0)
    o = Order(client_id="", exchange="binance", symbol="BTCUSDT", side="BUY", qty=0.01, price=100.0, hedge=True)
    cid1 = gw.submit(o)
    cid2 = gw.submit(o)  # identical, should map to same client id
    assert cid1 == cid2
