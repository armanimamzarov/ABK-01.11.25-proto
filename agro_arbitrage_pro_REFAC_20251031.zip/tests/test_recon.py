from python_app.services.recon_worker_v2 import ReconWorkerV2, ExecFill
from datetime import datetime, timezone

class DummyDB:
    def __init__(self):
        self._local = {}
        self._ex = []
        self.snapshots = []
        self.inserted = []

    def load_exchange_trades(self, venue): return list(self._ex)
    def load_local_trades(self, venue): return dict(self._local)
    def insert_recon_trade(self, **row): self.inserted.append(row)
    def snapshot_position(self, **row): self.snapshots.append(row)
    def load_positions_balances(self, venue):
        return [
            {"asset":"USDT","symbol":"BTCUSDT","position_qty":0.1,"balance_free":1000,"balance_locked":0}
        ]

def test_reconcile_detects_missing_and_inserts():
    db = DummyDB()
    db._ex = [ExecFill(exec_id="1", venue="binance", symbol="BTCUSDT", side="BUY", qty=0.01, price=60000, fee=0.1, fee_asset="USDT", ts_exchange=datetime.now(timezone.utc))]
    db._local = {}
    w = ReconWorkerV2(db)
    res = w.reconcile("binance")
    assert res["missing"] == 1
    assert len(db.inserted) == 1

def test_snapshot_writes_rows():
    db = DummyDB()
    w = ReconWorkerV2(db)
    w.write_snapshot("binance")
    assert len(db.snapshots) == 1
