
from python_app.engine.idem_guard import IdemGuard

class R:
    def __init__(self): self.k={}
    def setnx(self, k,v, ex=0):
        if k in self.k: return False
        self.k[k]=v; return True
    def delete(self,k): self.k.pop(k, None)

def test_idem():
    g = IdemGuard(R())
    assert g.acquire("V","X")
    assert not g.acquire("V","X")
