from python_app.risk.risk_guard import RiskGuard, Telemetry
from types import SimpleNamespace

class DummyPortfolio:
    def __init__(self, net=0.0, sym=0.0, open_orders=0, rate=0):
        self._net=net; self._sym=sym; self._open=open_orders; self._rate=rate
    def net_notional_usd(self): return self._net
    def symbol_notional_usd(self, symbol): return self._sym
    def open_orders(self, venue, symbol): return self._open
    def order_rate(self, venue, symbol): return self._rate

def test_pre_order_caps():
    cfg = {"risk": {"max_net_notional_usd": 100, "max_symbol_notional_usd": 80, "max_open_orders": 1},
           "execution": {"per_symbol_backpressure":{"max_order_rate_per_sec": 2}}}
    killed = []
    def kill_hook(r): killed.append(r)
    degraded = []
    def degrade_hook(r): degraded.append(r)

    guard = RiskGuard(cfg, DummyPortfolio(net=50, sym=60, open_orders=1, rate=2), kill_hook, degrade_hook)
    # Проверка капов — не должно кидать исключение, но вызовет внутренние нарушения
    guard.pre_order("binance", "BTCUSDT", "BUY", qty=0.001, price=40000)
    assert isinstance(killed, list)  # smoke

def test_control_loop_kills_on_ws_gaps_and_dd():
    cfg = {"risk": {"kill_switch": {"ws_gap_threshold": 1, "intraday_dd_pct": 1.0}}}
    killed = []
    def kill_hook(r): killed.append(r)
    degraded = []
    def degrade_hook(r): degraded.append(r)

    guard = RiskGuard(cfg, DummyPortfolio(), kill_hook, degrade_hook)
    guard.control_loop(Telemetry(reject_rate_pct=0.0, ack_p99_ms=0.0, ws_gaps=2, intraday_dd_pct=0.5))
    guard.control_loop(Telemetry(reject_rate_pct=0.0, ack_p99_ms=0.0, ws_gaps=0, intraday_dd_pct=2.0))
    assert len(killed) >= 1
