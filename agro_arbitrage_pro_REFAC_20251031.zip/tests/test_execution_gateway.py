
from python_app.engine.execution_gateway import ExecutionGateway, DummyExchange

def test_idempotency():
    gw = ExecutionGateway({"DUMMY": DummyExchange()})
    coid = gw.submit_order(exchange="DUMMY", symbol="BTC/USDT", side="buy", qty=1.0, price=None, ord_type="MARKET")
    coid2 = gw.submit_order(exchange="DUMMY", symbol="BTC/USDT", side="buy", qty=1.0, price=None, ord_type="MARKET", client_order_id=coid)
    assert coid == coid2
