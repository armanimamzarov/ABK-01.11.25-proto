import asyncio
from python_app.exchanges.ws_manager import WebSocketManager, WSConfig

class DummyAdapter:
    def __init__(self):
        self.gaps = 0
    def update_heartbeat(self): pass
    async def notify_gap(self, symbol: str):
        self.gaps += 1
    async def gap_fill_snapshot(self, symbol: str): pass

class DummyWS:
    def __init__(self, msgs):
        self.msgs = msgs
        self.idx = 0
    async def connect(self, url): return
    async def send(self, payload): return
    async def recv(self):
        if self.idx >= len(self.msgs):
            await asyncio.sleep(0.01)
            return None
        m = self.msgs[self.idx]; self.idx += 1
        await asyncio.sleep(0.001)
        return m
    async def close(self): return

def test_gap_detection_event_loop():
    adapter = DummyAdapter()
    msgs = [{"u":1}, {"u":2}, {"u":4}, {"u":5}]  # gap at 3
    ws = DummyWS(msgs)
    mgr = WebSocketManager(adapter, ws)
    cfg = WSConfig(url="wss://dummy", subscribe_payload={"s":"x"}, symbol="BTCUSDT")
    loop = asyncio.get_event_loop()
    async def run_once():
        task = asyncio.create_task(mgr.run(cfg))
        await asyncio.sleep(0.05)
        await mgr.stop()
    loop.run_until_complete(run_once())
    assert adapter.gaps >= 1
