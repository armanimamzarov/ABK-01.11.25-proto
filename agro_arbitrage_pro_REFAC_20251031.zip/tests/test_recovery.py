from python_app.market_data.recovery import RecoveryManager

def test_recovery_gap_and_resync():
    rm = RecoveryManager()
    rm.on_snapshot("binance","BTCUSDT", 100, [(100.0,1.0)], [(101.0,1.0)])
    assert rm.on_diff("binance","BTCUSDT", 101, 101, [(100.0,0.5)], [(101.0,0.8)])
    assert not rm.on_diff("binance","BTCUSDT", 103, 103, [], []), "gap should force resync"
    assert rm.books[("binance","BTCUSDT")].last_update_id is None
