# Setup Guide

## Prerequisites
- Docker & Docker Compose
- Exchange API keys (Binance / OKX / Bybit / KuCoin / MEXC / Gate)

## 1) Environment
Copy `.env.example` to `.env` and fill credentials.

## 2) Start stack
```bash
docker compose -f docker-compose.prod.yml up -d --build
```

## 3) Telegram bot
Talk to your bot and use `/latency`, `/drawdown`, `/pnl`.

## 4) Grafana
- Open http://localhost:3000
- Dashboard “AGRO Overview” is preloaded.

## Notes
- Replace default passwords for production.
- Configure Vault/etcd for dynamic config if needed.


### ML-пайплайн
1. Наполните ClickHouse котировками (ingest API).
2. Запустите обучение:
   ```bash
   docker compose -f docker-compose.prod.yml run --rm python_app python -m python_app.ml.automl_train
   ```
3. (Опционально) Настройте автосинхронизацию ONNX из S3:
   - В `.env` задайте `AGRO_MODEL_SRC=s3://your-bucket/risk.onnx`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION`.
   - Rust ядро автоматически подхватит новую модель (hot-reload по mtime).


### Риск-контур (онлайн)
1. Установите лимиты в `.env` (`AGRO_RISK_VAR_LIMIT`, `AGRO_RISK_DRAWDOWN_LIMIT`).
2. Примените миграции Postgres (equity_curve, audit_log) и ClickHouse DDL.
3. Поднимите сервисы: `python_risk_guard`, `python_configsync`.
4. В случае аварии флаг `/models/halt.flag` будет создан автоматически → торговля остановится.

### CDC без Kafka
1. Выполните `db/pg_audit_cdc.sql` в Postgres.
2. Запустите `python_cdc_poller` — записи будут появляться в ClickHouse таблице `audit_log`.


### RBAC и аудит Telegram
1. В `.env` задайте `TELEGRAM_ALLOWLIST` через запятую (числовые user id).
2. Команды `/latency`, `/drawdown`, `/pnl` будут доступны только allowlist-пользователям и логироваться в Postgres.

### Запуск тюнинга
```bash
docker compose -f docker-compose.prod.yml run --rm python_app python -m python_app.ml.tune_optuna
docker compose -f docker-compose.prod.yml run --rm python_app python -m python_app.ml.tune_flaml
```


### Отчёты по рискам
- Генерация: `/risk_report` из Telegram или HTTP POST `http://localhost:9105/report`.
- Файлы сохраняются в директорию, заданную `AGRO_REPORT_DIR` (по умолчанию `/models/reports`).

### Роли и доступ
- Пропишите `TELEGRAM_ALLOWLIST` и `TELEGRAM_ROLES` в `.env`.
- Команды `/halt_on` и `/halt_off` доступны только `admin`.
