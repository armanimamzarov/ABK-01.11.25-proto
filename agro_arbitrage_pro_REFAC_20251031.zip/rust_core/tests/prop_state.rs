use agro_rust_core::engine::execution_gateway::{ExecutionGateway, make_order};
use proptest::prelude::*;
use std::sync::Arc;

proptest! {
    #[test]
    fn no_invalid_terminal_transitions(qty in 0.01f64..100.0) {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async {
            let gw = Arc::new(ExecutionGateway::new(1, 10));
            let o = make_order("MOCK", "BTCUSDT", "buy", qty, None);
            gw.submit(o.clone()).unwrap();
            let workers = gw.clone().start_workers();
            tokio::time::sleep(std::time::Duration::from_millis(300)).await;
            let st = gw.state(&o.client_order_id).unwrap();
            assert!(st.is_terminal());
            for h in workers { h.abort(); }
        });
    }
}
