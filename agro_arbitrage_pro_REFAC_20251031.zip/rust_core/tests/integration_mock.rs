use agro_rust_core::engine::execution_gateway::{ExecutionGateway, make_order};
use std::sync::Arc;

#[tokio::test]
async fn retries_and_rejections() {
    let gw = Arc::new(ExecutionGateway::new(0, 10)); // force no retries
    let o = make_order("MOCK", "ETHUSDT", "sell", 2.0, None);
    gw.submit(o.clone()).unwrap();
    let workers = gw.clone().start_workers();
    tokio::time::sleep(std::time::Duration::from_millis(200)).await;
    let st = gw.state(&o.client_order_id).unwrap();
    assert!(st.is_terminal());
    for h in workers { h.abort(); }
}
