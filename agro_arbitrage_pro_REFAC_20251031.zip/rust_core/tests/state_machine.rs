use agro_rust_core::engine::execution_gateway::{ExecutionGateway, make_order};
use std::sync::Arc;

#[tokio::test]
async fn state_machine_happy_path() {
    let gw = Arc::new(ExecutionGateway::new(2, 50));
    let o = make_order("MOCK", "BTCUSDT", "buy", 1.0, Some(50000.0));
    gw.submit(o.clone()).unwrap();
    let workers = gw.clone().start_workers();
    tokio::time::sleep(std::time::Duration::from_millis(400)).await;
    let st = gw.state(&o.client_order_id).unwrap();
    assert!(st.is_terminal());
    for h in workers { h.abort(); }
}
