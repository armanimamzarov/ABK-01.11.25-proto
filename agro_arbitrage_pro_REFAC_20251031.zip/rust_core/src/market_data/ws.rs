use tokio::sync::broadcast;
use chrono::Utc;
use crate::market_data::mod::{BookAggregator};
use rand::Rng;
use tokio::time::{sleep, Duration};

pub async fn spawn_mock_ws(agg: BookAggregator, exchange: &str, symbol: &str) {
    tokio::spawn(async move {
        loop {
            let mid = 50000.0 + rand::thread_rng().gen_range(-50.0..50.0);
            agg.update(exchange, symbol, mid-1.0, mid+1.0, Utc::now());
            sleep(Duration::from_millis(200)).await;
        }
    });
}
