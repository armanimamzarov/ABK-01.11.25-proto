use std::collections::HashMap;
use parking_lot::RwLock;
use chrono::{DateTime, Utc};

#[derive(Clone, Debug)]
pub struct Quote {
    pub bid: f64,
    pub ask: f64,
    pub ts: DateTime<Utc>,
}

pub struct BookAggregator {
    books: RwLock<HashMap<(String,String), Quote>>, // (exchange,symbol)->quote
}

impl BookAggregator {
    pub fn new() -> Self { Self { books: RwLock::new(HashMap::new()) } }
    pub fn update(&self, exchange: &str, symbol: &str, bid: f64, ask: f64, ts: DateTime<Utc>) {
        let mut w = self.books.write();
        w.insert((exchange.to_string(), symbol.to_string()), Quote{bid, ask, ts});
    }
    pub fn quote(&self, exchange: &str, symbol: &str) -> Option<Quote> {
        self.books.read().get(&(exchange.to_string(), symbol.to_string())).cloned()
    }
}
