
use anyhow::Result;
use sqlx::{PgPool, postgres::PgPoolOptions};
use std::env;

#[derive(Clone)]
pub struct PgRepo {
    pool: PgPool
}

impl PgRepo {
    pub async fn connect_from_env() -> Result<Self> {
        let url = env::var("DATABASE_URL").expect("DATABASE_URL not set");
        let pool = PgPoolOptions::new().max_connections(5).connect(&url).await?;
        Ok(Self { pool })
    }

    pub fn pool(&self) -> &PgPool { &self.pool }
}
