pub mod engine;
pub mod services;
pub mod storage;
pub mod risk;
pub mod market_data;
pub mod analytics;

use once_cell::sync::Lazy;
use prometheus::{self, IntCounter, Histogram, Registry};

pub static REGISTRY: Lazy<Registry> = Lazy::new(Registry::new);

pub static MET_ORDERS_SUBMITTED: Lazy<IntCounter> = Lazy::new(|| {
    let c = IntCounter::new("orders_submitted_total", "Total orders submitted").unwrap();
    REGISTRY.register(Box::new(c.clone())).unwrap();
    c
});

pub static H_ORDER_LATENCY: Lazy<Histogram> = Lazy::new(|| {
    let h = Histogram::with_opts(prometheus::HistogramOpts::new("order_roundtrip_seconds", "Order roundtrip latency")).unwrap();
    REGISTRY.register(Box::new(h.clone())).unwrap();
    h
});

pub mod ml;
