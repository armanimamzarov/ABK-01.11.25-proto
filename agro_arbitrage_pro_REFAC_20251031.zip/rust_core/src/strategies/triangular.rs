
use anyhow::Result;

pub struct Signal {
    pub symbol: String,
    pub edge_bps: f64,
}

pub fn compute_signal(bid: f64, ask: f64) -> Option<Signal> {
    if ask <= 0.0 { return None; }
    let edge = (bid/ask - 1.0) * 10_000.0;
    if edge > 1.0 {
        Some(Signal{ symbol: "BTCUSDT".into(), edge_bps: edge })
    } else {
        None
    }
}
