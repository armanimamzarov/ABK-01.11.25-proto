
pub mod triangular;
pub mod cross_exchange;
pub mod spread_scalping;
pub mod cash_and_carry;
pub mod synthetic;
pub mod volatility_rebalance;
