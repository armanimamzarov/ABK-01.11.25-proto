\
use anyhow::Result;
use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Serialize, Deserialize)]
pub struct OrderRecord {
    pub client_order_id: String,
    pub symbol: String,
    pub side: String,
    pub qty: f64,
    pub price: f64,
    pub state: String,
    pub exchange: String,
    pub created_ts: f64,
    pub updated_ts: f64,
    pub meta: serde_json::Value,
}

pub struct OrderStore {
    conn: Connection,
}

impl OrderStore {
    pub fn new(path: Option<&str>) -> Result<Self> {
        let p = path.unwrap_or("db/order_store.sqlite3");
        let parent = std::path::Path::new(p).parent().unwrap_or(std::path::Path::new("."));
        std::fs::create_dir_all(parent)?;
        let conn = Connection::open(p)?;
        conn.execute_batch(r#"
        CREATE TABLE IF NOT EXISTS orders(
            client_order_id TEXT PRIMARY KEY,
            symbol TEXT NOT NULL,
            side TEXT NOT NULL,
            qty REAL NOT NULL,
            price REAL NOT NULL,
            state TEXT NOT NULL,
            exchange TEXT NOT NULL,
            created_ts REAL NOT NULL,
            updated_ts REAL NOT NULL,
            meta TEXT NOT NULL
        );"#)?;
        Ok(Self{conn})
    }

    pub fn upsert(&self, rec: &OrderRecord) -> Result<()> {
        self.conn.execute(r#"
            INSERT INTO orders(client_order_id,symbol,side,qty,price,state,exchange,created_ts,updated_ts,meta)
            VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10)
            ON CONFLICT(client_order_id) DO UPDATE SET
              state=excluded.state,
              updated_ts=excluded.updated_ts,
              meta=excluded.meta
        "#, params![
            rec.client_order_id, rec.symbol, rec.side, rec.qty, rec.price, rec.state, rec.exchange,
            rec.created_ts, rec.updated_ts, rec.meta.to_string()
        ])?;
        Ok(())
    }

    pub fn list_unfinished(&self) -> Result<Vec<OrderRecord>> {
        let mut stmt = self.conn.prepare("SELECT * FROM orders WHERE state NOT IN ('Filled','Cancelled','Rejected')")?;
        let rows = stmt.query_map([], |row| {
            Ok(OrderRecord {
                client_order_id: row.get(0)?,
                symbol: row.get(1)?,
                side: row.get(2)?,
                qty: row.get(3)?,
                price: row.get(4)?,
                state: row.get(5)?,
                exchange: row.get(6)?,
                created_ts: row.get(7)?,
                updated_ts: row.get(8)?,
                meta: serde_json::from_str::<serde_json::Value>(row.get::<_, String>(9)?.as_str()).unwrap_or_default(),
            })
        })?;
        Ok(rows.filter_map(Result::ok).collect())
    }
}

pub fn now() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs_f64()
}
