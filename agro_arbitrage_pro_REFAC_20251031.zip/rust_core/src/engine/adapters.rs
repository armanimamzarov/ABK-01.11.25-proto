use anyhow::{Result, anyhow};
use chrono::Utc;
use tracing::{debug, warn};
use uuid::Uuid;
use crate::engine::models::{NewOrder, OrderState};
use crate::engine::rate_limit::TokenBucket;
use std::time::Duration;
use tokio::time::sleep;

pub struct MockExchangeAdapter {
    pub name: String,
    pub bucket: TokenBucket,
}

impl MockExchangeAdapter {
    pub fn new(name: &str, rps: u32) -> Self {
        Self { name: name.into(), bucket: TokenBucket::new(rps, rps) }
    }
    pub async fn send_new(&self, order: &NewOrder) -> Result<OrderState> {
        if !self.bucket.take(1) {
            warn!("{} rate limited new order {}", self.name, order.client_order_id);
            return Err(anyhow!("rate limited"));
        }
        // simulate variable ack
        sleep(Duration::from_millis(10)).await;
        Ok(OrderState::Ack)
    }
    pub async fn cancel(&self, _client_order_id: Uuid) -> Result<()> {
        if !self.bucket.take(1) { return Err(anyhow!("rate limited")); }
        sleep(Duration::from_millis(5)).await;
        Ok(())
    }
}
