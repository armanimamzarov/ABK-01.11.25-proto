use crate::engine::models::{NewOrder, OrderState, OrderUpdate};
use crate::{MET_ORDERS_SUBMITTED, H_ORDER_LATENCY};
use anyhow::{Result, anyhow};
use dashmap::DashMap;
use parking_lot::{Mutex, RwLock};
use rand::Rng;
use std::{collections::{VecDeque, HashMap}, sync::{Arc, atomic::{AtomicBool, Ordering}}, time::Duration};
use tokio::{task::JoinHandle, time::sleep};
use tracing::{info, warn, error};
use uuid::Uuid;
use chrono::Utc;

/// ExecutionGateway provides:
/// - Idempotency by client_order_id (UUID)
/// - Per (exchange,symbol) FIFO queue
/// - Explicit state machine with guarded transitions
/// - Retry with bounded attempts and jitter
/// - Global kill switch
pub struct ExecutionGateway {
    kill_switch: AtomicBool,
    queues: DashMap<(String, String), Arc<Mutex<VecDeque<NewOrder>>>>,
    states: DashMap<Uuid, Arc<RwLock<OrderState>>>,
    retries: DashMap<Uuid, usize>,
    max_retries: usize,
    retry_base_ms: u64,
}

impl ExecutionGateway {
    pub fn new(max_retries: usize, retry_base_ms: u64) -> Self {
        Self {
            kill_switch: AtomicBool::new(false),
            queues: DashMap::new(),
            states: DashMap::new(),
            retries: DashMap::new(),
            max_retries,
            retry_base_ms,
        }
    }

    pub fn kill(&self) {
        self.kill_switch.store(true, Ordering::SeqCst);
        warn!("Kill switch engaged. No new orders will be processed.");
    }

    pub fn revive(&self) {
        self.kill_switch.store(false, Ordering::SeqCst);
        info!("Kill switch disengaged.");
    }

    pub fn submit(&self, order: NewOrder) -> Result<()> {
        // File-based halt switch (written by risk guard)
        if let Ok(path) = std::env::var("AGRO_RISK_HALT_FILE") {
            if std::path::Path::new(&path).exists() { return Err(anyhow!("Trading halted by risk guard")); }
        }
        // ML risk gate (ONNX)
        if !crate::ml::infer::allow_order_simple(&[order.qty as f32, if order.price.is_some(){1.0}else{0.0}]) { return Err(anyhow!("Blocked by ML risk gate")); }

        if self.kill_switch.load(Ordering::SeqCst) {
            return Err(anyhow!("Kill switch is engaged"));
        }
        // idempotency: if already known, ignore duplicate submissions
        if self.states.contains_key(&order.client_order_id) {
            warn!("Duplicate submit for {}", order.client_order_id);
            return Ok(());
        }
        self.states.insert(order.client_order_id, Arc::new(RwLock::new(OrderState::PendingNew)));
        self.retries.insert(order.client_order_id, 0usize);
        let key = (order.exchange.clone(), order.symbol.clone());
        let q = self.queues.entry(key).or_insert_with(|| Arc::new(Mutex::new(VecDeque::new())));
        q.lock().push_back(order);
        MET_ORDERS_SUBMITTED.inc();
        Ok(())
    }

    /// Spawn per-queue workers
    pub fn start_workers(self: Arc<Self>) -> Vec<JoinHandle<()>> {
        let mut handles = Vec::new();
        for key in self.queues.iter().map(|e| e.key().clone()).collect::<Vec<_>>() {
            let this = self.clone();
            let handle = tokio::spawn(async move {
                this.run_queue(key).await;
            });
            handles.push(handle);
        }
        handles
    }

    async fn run_queue(self: Arc<Self>, key: (String, String)) {
        loop {
            if self.kill_switch.load(Ordering::SeqCst) {
                sleep(Duration::from_millis(200)).await;
                continue;
            }
            let maybe_order = {
                if let Some(q) = self.queues.get(&key) {
                    q.lock().pop_front()
                } else { None }
            };

            if let Some(order) = maybe_order {
                let start = std::time::Instant::now();
                match self.process_order(order.clone()).await {
                    Ok(_) => {
                        let sec = start.elapsed().as_secs_f64();
                        H_ORDER_LATENCY.observe(sec);
                    }
                    Err(e) => {
                        error!("Order {} failed: {}", order.client_order_id, e);
                        // retry
                        let n = self.retries.get(&order.client_order_id).map(|v| *v.value()).unwrap_or(0);
                        if n < self.max_retries {
                            let next = n + 1;
                            self.retries.insert(order.client_order_id, next);
                            let backoff = self.retry_base_ms * 2u64.saturating_pow(next as u32);
                            let jitter = rand::thread_rng().gen_range(0..self.retry_base_ms);
                            sleep(Duration::from_millis(backoff + jitter)).await;
                            // push back to queue
                            if let Some(q) = self.queues.get(&key) {
                                q.lock().push_back(order.clone());
                            }
                        } else {
                            if let Some(st) = self.states.get(&order.client_order_id) {
                                *st.write() = OrderState::Rejected(format!("Retries exhausted: {}", e));
                            }
                        }
                    }
                }
            } else {
                sleep(Duration::from_millis(20)).await;
            }
        }
    }

    /// Simulated exchange interaction + guarded transitions.
    async fn process_order(&self, order: NewOrder) -> Result<()> {
        // Guard transitions from PendingNew -> Ack/Rejected
        let st = self.states.get(&order.client_order_id).unwrap();
        {
            let s = st.read().clone();
            match s {
                OrderState::PendingNew => {},
                _ => return Err(anyhow!("Invalid state on process: {:?}", s))
            }
        }
        // Simulate exchange ACK or immediate reject
        let r: u8 = rand::thread_rng().gen_range(0..100);
        if r < 5 {
            *st.write() = OrderState::Rejected("Exchange down".into());
            return Err(anyhow!("Exchange down"));
        } else {
            *st.write() = OrderState::Ack;
        }

        // Fill logic simulation
        let mut remaining = order.qty;
        while remaining > 0.0 {
            if self.kill_switch.load(std::sync::atomic::Ordering::SeqCst) {
                *st.write() = OrderState::Canceled;
                break;
            }
            let fill = (order.qty * 0.4).min(remaining);
            remaining -= fill;
            if remaining > 0.0 {
                *st.write() = OrderState::PartialFilled;
            } else {
                *st.write() = OrderState::Filled;
            }
            sleep(Duration::from_millis(30)).await;
        }
        Ok(())
    }

    pub fn state(&self, id: &Uuid) -> Option<OrderState> {
        self.states.get(id).map(|s| s.read().clone())
    }
}

/// Convenience helper to craft a NewOrder
pub fn make_order(exchange: &str, symbol: &str, side: &str, qty: f64, price: Option<f64>) -> NewOrder {
    use crate::engine::models::{Side, OrderType, TimeInForce};
    NewOrder {
        client_order_id: Uuid::new_v4(),
        exchange: exchange.to_string(),
        symbol: symbol.to_string(),
        side: if side.eq_ignore_ascii_case("buy") { Side::Buy } else { Side::Sell },
        qty,
        price,
        order_type: if price.is_some() { OrderType::Limit } else { OrderType::Market },
        tif: TimeInForce::GTC,
        ts: Utc::now(),
    }
}
