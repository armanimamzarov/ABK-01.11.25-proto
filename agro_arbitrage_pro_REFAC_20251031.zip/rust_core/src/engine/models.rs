use serde::{Serialize, Deserialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum Side { Buy, Sell }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum OrderType { Limit, Market }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum TimeInForce { GTC, IOC, FOK }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct NewOrder {
    pub client_order_id: Uuid,
    pub exchange: String,
    pub symbol: String,
    pub side: Side,
    pub qty: f64,
    pub price: Option<f64>,
    pub order_type: OrderType,
    pub tif: TimeInForce,
    pub ts: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum OrderState {
    PendingNew,
    Ack,
    PartialFilled,
    Filled,
    Canceled,
    Rejected(String),
}

impl OrderState {
    pub fn is_terminal(&self) -> bool {
        matches!(self, OrderState::Filled | OrderState::Canceled | OrderState::Rejected(_))
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct OrderUpdate {
    pub client_order_id: Uuid,
    pub state: OrderState,
    pub filled_qty: f64,
    pub remaining_qty: f64,
    pub last_price: Option<f64>,
    pub ts: DateTime<Utc>,
}
