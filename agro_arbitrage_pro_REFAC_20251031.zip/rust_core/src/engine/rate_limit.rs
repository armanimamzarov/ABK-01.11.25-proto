use std::time::{Duration, Instant};
use parking_lot::Mutex;

pub struct TokenBucket {
    capacity: u32,
    tokens: Mutex<(u32, Instant, u32)>,
    refill_per_sec: u32,
}

impl TokenBucket {
    pub fn new(capacity: u32, refill_per_sec: u32) -> Self {
        Self {
            capacity,
            tokens: Mutex::new((capacity, Instant::now(), refill_per_sec)),
            refill_per_sec,
        }
    }
    pub fn take(&self, n: u32) -> bool {
        let mut g = self.tokens.lock();
        let (ref mut cur, ref mut last, _) = *g;
        let elapsed = last.elapsed().as_secs_f64();
        let refill = (elapsed * self.refill_per_sec as f64).floor() as u32;
        if refill > 0 {
            *cur = (*cur + refill).min(self.capacity);
            *last = Instant::now();
        }
        if *cur >= n {
            *cur -= n;
            true
        } else {
            false
        }
    }
}
