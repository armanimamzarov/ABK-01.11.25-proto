pub fn apply_fees_slippage(notional: f64, maker_bps: f64, taker_bps: f64, slip_bps: f64, is_maker: bool) -> f64 {
    let fee = notional * if is_maker { maker_bps } else { taker_bps } / 10_000.0;
    let slip = notional * slip_bps / 10_000.0;
    notional - fee - slip
}
