
use anyhow::{Result, bail};
use crate::repository::PgRepo;
use sqlx::Row;

#[derive(Clone)]
pub struct RiskEngine {
    repo: PgRepo
}

impl RiskEngine {
    pub fn new(repo: PgRepo) -> Self { Self { repo } }

    pub async fn validate(&self, _strategy: &str, _exchange: &str, _symbol: &str, _side: &str, qty: f64, price: f64, _order_type: &str) -> Result<()> {
        if qty <= 0.0 { bail!("qty must be > 0"); }
        if price < 0.0 { bail!("price must be >= 0"); }

        // position sizing: cap notional
        let notional = qty * price.max(1.0);
        if notional > 500.0 { bail!("position exceeds $500 cap"); }

        // daily drawdown check
        if let Ok(row) = sqlx::query("SELECT COALESCE(SUM(realized),0) as r FROM pnl WHERE date = CURRENT_DATE")
            .fetch_one(self.repo.pool()).await {
            let r: f64 = row.try_get("r").unwrap_or(0.0);
            if r < -200.0 { bail!("daily drawdown limit reached"); }
        }
        Ok(())
    }
}
