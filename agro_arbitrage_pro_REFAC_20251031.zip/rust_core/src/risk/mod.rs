use std::collections::HashMap;
use anyhow::{Result, anyhow};

#[derive(Clone, Debug)]
pub struct RiskLimits {
    pub max_notional_per_symbol: HashMap<String, f64>,
    pub max_open_orders_per_symbol: usize,
    pub blocklist_symbols: Vec<String>,
    pub stop_out_drawdown_pct: f64,
}

pub struct RiskEngine {
    limits: RiskLimits,
}

impl RiskEngine {
    pub fn new(limits: RiskLimits) -> Self { Self { limits } }

    /// Validate order against simple limits.
    pub fn validate_new(&self, symbol: &str, notional: f64, open_orders: usize) -> Result<()> {
        if self.limits.blocklist_symbols.iter().any(|s| s == symbol) {
            return Err(anyhow!("Symbol is blocklisted"));
        }
        if let Some(max) = self.limits.max_notional_per_symbol.get(symbol) {
            if &notional > max { return Err(anyhow!("Notional exceeds limit")); }
        }
        if open_orders >= self.limits.max_open_orders_per_symbol {
            return Err(anyhow!("Open order count exceeded"));
        }
        Ok(())
    }
}
