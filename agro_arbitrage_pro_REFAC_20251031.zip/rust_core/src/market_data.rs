
use anyhow::Result;
use tokio::sync::mpsc::{unbounded_channel, UnboundedReceiver};
use tokio_tungstenite::{connect_async, tungstenite::protocol::Message};
use futures::StreamExt;
use serde::{Deserialize, Serialize};
use std::time::{SystemTime, UNIX_EPOCH};

use crate::server::agro::{OrderbookSnapshot, DepthLevel};

#[derive(Clone)]
pub struct BinanceWs {}

impl BinanceWs {
    pub fn new() -> Self { Self {} }

    pub async fn subscribe(&self, symbol: String) -> Result<UnboundedReceiver<OrderbookSnapshot>> {
        let stream_sym = symbol.to_lowercase().replace("/", "");
        let url = format!("wss://stream.binance.com:9443/ws/{}@depth5@100ms", stream_sym);
        let (ws, _) = connect_async(&url).await?;
        let (_, mut read) = ws.split();
        let (tx, rx) = unbounded_channel::<OrderbookSnapshot>();
        tokio::spawn(async move {
            while let Some(msg) = read.next().await {
                if let Ok(Message::Text(t)) = msg {
                    match serde_json::from_str::<serde_json::Value>(&t) {
                        Ok(v) => {
                            let ts = v.get("E").and_then(|x| x.as_i64()).unwrap_or_else(|| {
                                (SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as i64)
                            });
                            let parse_side = |key: &str| -> Vec<DepthLevel> {
                                v.get(key).and_then(|x| x.as_array()).unwrap_or(&vec![]).iter().filter_map(|l| {
                                    let p = l.get(0)?.as_str()?.parse::<f64>().ok()?;
                                    let q = l.get(1)?.as_str()?.parse::<f64>().ok()?;
                                    Some(DepthLevel{ price: p, qty: q })
                                }).collect::<Vec<_>>()
                            };
                            let bids = parse_side("bids");
                            let asks = parse_side("asks");
                            let _ = tx.send(OrderbookSnapshot{ symbol: symbol.clone(), bids, asks, ts_ms: ts });
                        },
                        Err(_) => {}
                    }
                }
            }
        });
        Ok(rx)
    }
}
