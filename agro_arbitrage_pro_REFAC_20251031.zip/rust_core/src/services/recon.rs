use anyhow::Result;
use tracing::{info, warn};
use uuid::Uuid;
use chrono::Utc;
use crate::engine::models::OrderState;
use crate::storage::pg::PgStore;

/// Reconciliation daemon:
/// - Periodically compares orders/trades in DB with gateway states
/// - Auto-corrects statuses and emits metrics
pub struct Recon {
    store: PgStore,
}

impl Recon {
    pub fn new(store: PgStore) -> Self { Self { store } }

    /// Reconcile stale orders and update states if stuck
    pub async fn run_once(&self) -> Result<()> {
        let stale = self.store.fetch_stale_orders(15).await?;
        for o in stale {
            // simplistic correction: if ack > X secs and no fills -> cancel
            if o.state == "Ack" && (Utc::now() - o.updated_at).num_seconds() > 10 {
                self.store.update_order_state(o.client_order_id, "Canceled").await?;
                warn!("Auto-canceled stale order {}", o.client_order_id);
            }
        }
        Ok(())
    }
}
