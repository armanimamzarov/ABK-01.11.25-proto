
use crate::{metrics, market_data::BinanceWs, repository::PgRepo, risk::RiskEngine};
use anyhow::Result;
use prometheus::{Encoder, TextEncoder};
use std::net::SocketAddr;
use tokio::task;
use tokio_stream::wrappers::ReceiverStream;
use tonic::{transport::Server, Request, Response, Status};

use crate::server::agro::risk_service_server::{RiskService, RiskServiceServer};
use crate::server::agro::{OrderRequest, OrderResponse, DepthRequest, OrderbookSnapshot};

pub mod agro {
    tonic::include_proto!("agro");
}

pub struct RiskSvc {
    risk: RiskEngine,
    md: BinanceWs,
}

#[tonic::async_trait]
impl RiskService for RiskSvc {
    async fn validate_order(&self, req: Request<OrderRequest>) -> Result<Response<OrderResponse>, Status> {
        let o = req.into_inner();
        match self.risk.validate(&o.strategy, &o.exchange, &o.symbol, &o.side, o.qty, o.price, &o.order_type).await {
            Ok(_) => Ok(Response::new(OrderResponse { allowed: true, reason: "".into() })),
            Err(e) => Ok(Response::new(OrderResponse { allowed: false, reason: e.to_string() })),
        }
    }

    type StreamOrderbookStream = ReceiverStream<Result<OrderbookSnapshot, Status>>;

    async fn stream_orderbook(&self, req: Request<DepthRequest>) -> Result<Response<Self::StreamOrderbookStream>, Status> {
        let symbol = req.into_inner().symbol;
        let (tx, rx) = tokio::sync::mpsc::channel(32);
        let mut sub = self.md.subscribe(symbol.clone()).await.map_err(|e| Status::internal(e.to_string()))?;
        task::spawn(async move {
            while let Some(snap) = sub.recv().await {
                let _ = tx.send(Ok(snap)).await;
            }
        });
        Ok(Response::new(ReceiverStream::new(rx)))
    }
}

pub async fn run() -> Result<()> {
    let grpc_addr: SocketAddr = "0.0.0.0:50051".parse().unwrap();
    let metrics_addr: SocketAddr = "0.0.0.0:9100".parse().unwrap();

    let repo = PgRepo::connect_from_env().await?;
    let risk = RiskEngine::new(repo.clone());
    let md = BinanceWs::new();

    // Metrics endpoint
    tokio::spawn(async move {
        use hyper::{Body, Request as HRequest, Response as HResponse, Server as HServer, Method};
        let make_svc = hyper::service::make_service_fn(|_| async {
            Ok::<_, hyper::Error>(hyper::service::service_fn(|req: HRequest<Body>| async move {
                if req.method() == Method::GET && req.uri().path() == "/metrics" {
                    let mut buf = Vec::new();
                    let encoder = TextEncoder::new();
                    let mfs = metrics::REGISTRY.gather();
                    encoder.encode(&mfs, &mut buf).unwrap();
                    Ok::<_, hyper::Error>(HResponse::new(Body::from(buf)))
                } else {
                    Ok::<_, hyper::Error>(HResponse::builder().status(404).body(Body::from("Not Found")).unwrap())
                }
            }))
        });
        let server = HServer::bind(&metrics_addr).serve(make_svc);
        if let Err(e) = server.await { eprintln!("metrics server error: {}", e) }
    });

    let svc = RiskSvc { risk, md };
    Server::builder()
        .add_service(RiskServiceServer::new(svc))
        .serve(grpc_addr)
        .await?;

    Ok(())
}
