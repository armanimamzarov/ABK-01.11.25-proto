use anyhow::Result;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::{Pool, Postgres, postgres::PgPoolOptions};
use uuid::Uuid;

#[derive(Clone)]
pub struct PgStore {
    pool: Pool<Postgres>,
}

#[derive(sqlx::FromRow, Serialize, Deserialize, Debug, Clone)]
pub struct DbOrder {
    pub client_order_id: Uuid,
    pub exchange: String,
    pub symbol: String,
    pub state: String,
    pub qty: f64,
    pub price: Option<f64>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl PgStore {
    pub async fn connect(conn_str: &str, max: u32) -> Result<Self> {
        let pool = PgPoolOptions::new().max_connections(max).connect(conn_str).await?;
        Ok(Self { pool })
    }

    pub async fn fetch_stale_orders(&self, older_than_secs: i64) -> Result<Vec<DbOrder>> {
        let rows = sqlx::query_as::<_, DbOrder>(r#"
            SELECT client_order_id, exchange, symbol, state, qty, price, created_at, updated_at
            FROM orders
            WHERE state IN ('Ack','PendingNew') AND now() - updated_at > make_interval(secs => $1)
            ORDER BY updated_at
        "#).bind(older_than_secs).fetch_all(&self.pool).await?;
        Ok(rows)
    }

    pub async fn update_order_state(&self, id: Uuid, state: &str) -> Result<()> {
        sqlx::query("UPDATE orders SET state=$1, updated_at=now() WHERE client_order_id=$2")
            .bind(state).bind(id)
            .execute(&self.pool).await?;
        Ok(())
    }
}
