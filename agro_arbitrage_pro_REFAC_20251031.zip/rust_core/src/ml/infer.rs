
use once_cell::sync::OnceCell;
use onnxruntime::{environment::Environment, session::Session, ndarray::Array, GraphOptimizationLevel};
use std::{env, fs, path::PathBuf, sync::{Arc}, time::SystemTime};
use parking_lot::Mutex;

static ORT_ENV: OnceCell<Arc<Environment>> = OnceCell::new();

struct SessionState {
    path: Option<PathBuf>;
    mtime: Option<SystemTime>;
    session: Option<Arc<Session>>;
}

static STATE: OnceCell<Mutex<SessionState>> = OnceCell::new();

fn ensure_env() -> Arc<Environment> {
    ORT_ENV.get_or_init(|| {
        Arc::new(Environment::builder()
            .with_name("agro-ml")
            .with_log_level(onnxruntime::LoggingLevel::Warning)
            .build().expect("ORT env"))
    }).clone()
}

fn maybe_reload() {
    let mut st = STATE.get_or_init(|| Mutex::new(SessionState{ path: None, mtime: None, session: None })).lock();
    let p = env::var("AGRO_ML_ONNX_PATH").ok().map(PathBuf::from);
    if p.is_none() { return; }
    let p = p.unwrap();
    let md = match fs::metadata(&p) { Ok(m) => m, Err(_) => return };
    let mt = md.modified().ok();
    if st.session.is_none() || st.path.as_ref()!=Some(&p) || st.mtime!=mt {
        // (re)load
        let env = ensure_env();
        match env.new_session_builder()
            .and_then(|b| b.with_optimization_level(GraphOptimizationLevel::All))
            .and_then(|b| b.with_number_threads(1))
            .and_then(|b| b.with_model_from_file(&p)) {
            Ok(sess) => {
                st.session = Some(Arc::new(sess));
                st.path = Some(p.clone());
                st.mtime = mt;
            },
            Err(_) => { /* keep old */ }
        }
    }
}

fn get_session() -> Option<Arc<Session>> {
    maybe_reload();
    let st = STATE.get().unwrap().lock();
    st.session.clone()
}

/// Compute a risk score in [0,1]. If model is missing or fails, returns None.
pub fn risk_score(features: &[f32]) -> Option<f32> {
    let sess = get_session()?;
    let n = features.len();
    let input = Array::from_shape_vec((1, n), features.to_vec()).ok()?;
    let outputs = sess.run(vec![input]).ok()?;
    if outputs.is_empty() { return None; }
    let arr = outputs[0].try_extract::<f32>().ok()?;
    let flat = arr.iter().cloned().collect::<Vec<f32>>();
    if flat.len() == 1 {
        Some(flat[0].clamp(0.0, 1.0))
    } else if flat.len() >= 2 {
        Some(flat[1].clamp(0.0, 1.0))
    } else {
        None
    }
}

/// Decide whether to allow order based on risk score and threshold.
pub fn allow_order_simple(features: &[f32]) -> bool {
    let thr: f32 = std::env::var("AGRO_ML_THRESHOLD").ok().and_then(|s| s.parse().ok()).unwrap_or(0.5);
    match risk_score(features) {
        Some(s) => s >= thr,
        None => true, // fail-open if no model configured
    }
}
