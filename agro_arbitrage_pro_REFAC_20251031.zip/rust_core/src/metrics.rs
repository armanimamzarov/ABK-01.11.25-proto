
use lazy_static::lazy_static;
use prometheus::{Registry, IntCounter, Histogram, HistogramOpts};

lazy_static! {
    pub static ref REGISTRY: Registry = Registry::new();
    pub static ref ORDERS_VALIDATED: IntCounter = IntCounter::new("orders_validated_total", "Orders validated").unwrap();
    pub static ref VALIDATION_LATENCY: Histogram = Histogram::with_opts(
        HistogramOpts::new("validation_latency_seconds", "Validation latency")
    ).unwrap();
}

#[ctor::ctor]
fn init() {
    REGISTRY.register(Box::new(ORDERS_VALIDATED.clone())).unwrap();
    REGISTRY.register(Box::new(VALIDATION_LATENCY.clone())).unwrap();
}
