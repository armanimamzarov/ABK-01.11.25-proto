
mod server;
mod metrics;
mod repository;
mod market_data;
mod risk;
mod strategies;

use anyhow::Result;
use tracing::{info, error};
use tracing_subscriber::EnvFilter;

fn set_panic_hook() {
    std::panic::set_hook(Box::new(|panic_info| {
        eprintln!("PANIC: {:?}", panic_info);
    }));
}

#[tokio::main]
async fn main() -> Result<()> {
    set_panic_hook();
    let filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info"));
    tracing_subscriber::fmt().with_env_filter(filter).init();
    info!("Starting AGRO Rust Core v6...");
    if let Err(e) = server::run().await {
        error!("Server exited with error: {e:?}");
    }
    Ok(())
}
