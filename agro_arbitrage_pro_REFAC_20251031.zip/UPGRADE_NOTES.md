# Upgrade notes
- Prometheus config consolidated to `agro_arbitrage_pro/prometheus/prometheus.yml`.
- Python app port standardized to 9101 (set PY_HTTP_PORT to override).
- Duplicates in requirements removed.
