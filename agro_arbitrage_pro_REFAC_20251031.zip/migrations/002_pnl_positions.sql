CREATE TABLE IF NOT EXISTS pnl_sessions (
  id BIGSERIAL PRIMARY KEY,
  strategy TEXT NOT NULL,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS pnl_events (
  id BIGSERIAL PRIMARY KEY,
  session_id BIGINT NOT NULL REFERENCES pnl_sessions(id),
  client_order_id UUID,
  symbol TEXT NOT NULL,
  entry_price DOUBLE PRECISION,
  exit_price DOUBLE PRECISION,
  qty DOUBLE PRECISION NOT NULL,
  theoretical DOUBLE PRECISION,
  realized DOUBLE PRECISION,
  ts TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pnl_session ON pnl_events(session_id);
