
CREATE TABLE IF NOT EXISTS strategies (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS orders (
    id BIGSERIAL PRIMARY KEY,
    strategy TEXT NOT NULL,
    exchange TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    qty NUMERIC(38, 18) NOT NULL,
    price NUMERIC(38, 18),
    order_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'NEW',
    external_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trades (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT REFERENCES orders(id),
    price NUMERIC(38, 18) NOT NULL,
    qty NUMERIC(38, 18) NOT NULL,
    fee NUMERIC(38, 18) DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pnl (
    id BIGSERIAL PRIMARY KEY,
    strategy TEXT NOT NULL,
    date DATE NOT NULL,
    realized NUMERIC(38, 18) NOT NULL DEFAULT 0,
    unrealized NUMERIC(38, 18) NOT NULL DEFAULT 0,
    UNIQUE(strategy, date)
);
