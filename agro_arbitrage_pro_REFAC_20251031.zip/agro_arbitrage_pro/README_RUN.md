

## Ports & Endpoints
| Service | Port | Endpoints |
|---|---:|---|
| Rust gRPC | 8080 | Health RPC, Version RPC |
| Rust metrics | 9095 | /metrics |
| Python API | 8081 | /health, /metrics, /docs |
| Prometheus | 9090 | / |
