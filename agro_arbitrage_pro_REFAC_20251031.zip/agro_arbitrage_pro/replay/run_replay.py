
"""
Replays recorded orderbooks/trades at accelerated speed for E2E testing.
Input: ./replay/data/*.jsonl with {"ts":..., "type":"ob|trade", "symbol":..., "payload":...}
"""
import os, json, time, glob

SPEEDUP = float(os.getenv("REPLAY_X", "5.0"))

def main():
    files = sorted(glob.glob("replay/data/*.jsonl"))
    if not files:
        print("[replay] no data found in replay/data, skipping")
        return
    t0 = None
    for f in files:
        for line in open(f, "r", encoding="utf-8"):
            ev = json.loads(line)
            if t0 is None:
                t0 = ev["ts"]
            delta = (ev["ts"] - t0) / max(SPEEDUP, 0.1)
            time.sleep(max(0.0, delta))
            # TODO: inject into in-memory bus / strategy feed

if __name__ == "__main__":
    main()
