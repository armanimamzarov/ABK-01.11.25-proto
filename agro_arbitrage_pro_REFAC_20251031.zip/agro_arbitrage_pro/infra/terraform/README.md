# Terraform skeleton for VPC/EKS/RDS/S3 — fill in modules as needed.
