CREATE TABLE IF NOT EXISTS opportunity (
    id SERIAL PRIMARY KEY,
    strategy VARCHAR(64) NOT NULL,
    symbol VARCHAR(32) NOT NULL,
    expected_profit_pct DOUBLE PRECISION NOT NULL,
    payload JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_opp_created_at ON opportunity(created_at);

CREATE TABLE IF NOT EXISTS execution (
    id SERIAL PRIMARY KEY,
    strategy VARCHAR(64) NOT NULL,
    pnl_pct DOUBLE PRECISION NOT NULL,
    slippage_pct DOUBLE PRECISION NOT NULL,
    order_ids VARCHAR(256) NOT NULL,
    payload JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_exec_created_at ON execution(created_at);
