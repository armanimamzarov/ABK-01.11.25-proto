fn main() {
    tonic_build::configure()
        .build_server(true)
        .out_dir("src/proto_out")
        .compile(&["proto/execution.proto"], &["proto"])
        .unwrap();
    println!("cargo:rerun-if-changed=proto/execution.proto");
}
