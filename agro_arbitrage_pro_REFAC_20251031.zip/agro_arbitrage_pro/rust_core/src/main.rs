use agro_rust_core::pb::execution::execution_server::{Execution, ExecutionServer};
use agro_rust_core::pb::execution::{ExecReply, Empty, VersionReply, TwoLegRequest, ThreeLegRequest, HealthReply};
use agro_rust_core::{engine, utils, risk::RiskConfig};
use tonic::{Request, Response, Status};
use tracing::{info, error};
use tracing_subscriber::EnvFilter;
use std::{net::SocketAddr, fs};

struct ExecSvc;

#[tonic::async_trait]
impl Execution for ExecSvc {
    async fn execute_two_leg(&self, req: Request<TwoLegRequest>) -> Result<Response<ExecReply>, Status> {
        Ok(Response::new(engine::execute_two(req.into_inner()).await))
    }
    async fn execute_three_leg(&self, req: Request<ThreeLegRequest>) -> Result<Response<ExecReply>, Status> {
        Ok(Response::new(engine::execute_three(req.into_inner()).await))
    }
    async fn health(&self, _req: Request<Empty>) -> Result<Response<HealthReply>, Status> {
        Ok(Response::new(HealthReply{ ok: true, status: "ok".into() }))
    }
    async fn version(&self, _req: Request<Empty>) -> Result<Response<VersionReply>, Status> {
        Ok(Response::new(VersionReply{ version: env!("CARGO_PKG_VERSION").into() }))
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // split init: logs, config validation, grpc, metrics
    init_logs();
    validate_risk_config();
    let grpc = tokio::spawn(start_grpc());
    let metrics = tokio::spawn(start_metrics());
    grpc.await??;
    metrics.await??;
    Ok(())
}

fn init_logs() {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env().add_directive("info".parse().unwrap()))
        .init();
    info!("Rust core starting");
}

fn validate_risk_config() {
    let path = std::env::var("RISK_CONFIG").unwrap_or_else(|_| "configs/risk_management.json".into());
    if let Ok(data) = fs::read_to_string(&path) {
        if let Ok(cfg) = serde_json::from_str::<RiskConfig>(&data) {
            if let Err(e) = cfg.validate() {
                error!("Invalid risk config: {}", e);
                std::process::exit(1);
            }
        }
    }
}

async fn start_grpc() -> Result<(), Box<dyn std::error::Error>> {
    let addr: SocketAddr = "0.0.0.0:8080".parse().unwrap();
    let svc = ExecSvc{};
    info!("gRPC listening on {}", addr);
    tonic::transport::Server::builder()
        .add_service(ExecutionServer::new(svc))
        .serve(addr)
        .await?;
    Ok(())
}

async fn start_metrics() -> Result<(), Box<dyn std::error::Error>> {
    use hyper::{Body, Request as HRequest, Response as HResponse, Server, Method};
    use hyper::service::{make_service_fn, service_fn};
    let addr: SocketAddr = "0.0.0.0:9095".parse().unwrap();
    let make_svc = make_service_fn(|_conn| async {
        Ok::<_, hyper::Error>(service_fn(|req: HRequest<Body>| async move {
            if req.method() == Method::GET && req.uri().path() == "/metrics" {
                let body = utils::metrics_body().await;
                Ok::<_, hyper::Error>(HResponse::new(Body::from(body)))
            } else {
                Ok::<_, hyper::Error>(HResponse::new(Body::from("ok")))
            }
        }))
    });
    info!("Metrics on {}", addr);
    Server::bind(&addr).serve(make_svc).await?;
    Ok(())
}
