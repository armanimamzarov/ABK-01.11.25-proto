use std::net::SocketAddr;
use std::sync::Arc;
use tracing::info;
use tonic::{transport::Server, Request, Response, Status};
use crate::engine::ArbitrageEngine;
pub mod pb { include!(concat!(env!("CARGO_MANIFEST_DIR"), "/src/grpc/execution.rs")); }

#[derive(Clone)]
pub struct ExecSvc { _engine: Arc<ArbitrageEngine> }

#[tonic::async_trait]
impl pb::execution_service_server::ExecutionService for ExecSvc {
    async fn execute_two_leg(
        &self,
        _req: Request<pb::TwoLegRequest>,
    ) -> Result<Response<pb::ExecutionResponse>, Status> {
        Ok(Response::new(pb::ExecutionResponse{
            success: true, pnl_pct: 0.15, slippage_pct: 0.05,
            order_ids: vec!["sim_1".into(),"sim_2".into()],
            execution_time_ms: 42, error: None
        }))
    }
    async fn execute_three_leg(
        &self,
        _req: Request<pb::ThreeLegRequest>,
    ) -> Result<Response<pb::ExecutionResponse>, Status> {
        Ok(Response::new(pb::ExecutionResponse{
            success: true, pnl_pct: 0.18, slippage_pct: 0.06,
            order_ids: vec!["sim_1".into(),"sim_2".into(),"sim_3".into()],
            execution_time_ms: 64, error: None
        }))
    }
    async fn get_health(
        &self,
        _req: Request<pb::HealthRequest>,
    ) -> Result<Response<pb::HealthResponse>, Status> {
        Ok(Response::new(pb::HealthResponse{
            healthy: true, status: "ok".into(), metrics: Default::default()
        }))
    }
}

pub async fn start_grpc_server(engine: Arc<ArbitrageEngine>, port: u16) -> anyhow::Result<()> {
    let addr = SocketAddr::from(([0,0,0,0], port));
    info!("gRPC listening on {}", addr);
    let svc = ExecSvc{ _engine: engine };
    Server::builder()
        .add_service(pb::execution_service_server::ExecutionServiceServer::new(svc))
        .serve(addr)
        .await?;
    Ok(())
}
