use std::env;

pub struct ApiKeys {
    pub binance_key: String,
    pub binance_secret: String,
    pub bybit_key: String,
    pub bybit_secret: String,
}

impl ApiKeys {
    pub fn from_env_readonly() -> Self {
        let get = |k: &str| env::var(k).unwrap_or_default();
        Self {
            binance_key: get("BINANCE_KEY"),
            binance_secret: get("BINANCE_SECRET"),
            bybit_key: get("BYBIT_KEY"),
            bybit_secret: get("BYBIT_SECRET"),
        }
    }
}
