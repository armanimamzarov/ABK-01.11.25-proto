use serde::Deserialize;

#[derive(Debug, Deserialize, Clone)]
pub struct AssetLimit {
    pub symbol: String,
    pub max_notional_usd: f64,
}

#[derive(Debug, Deserialize, Clone)]
pub struct RiskConfig {
    pub max_position_pct: f64,
    pub max_slippage_pct: f64,
    pub max_open_trades: u32,
    pub assets: Option<Vec<AssetLimit>>,
    pub spike_threshold_bps: Option<f64>, // anti-spike: reject if price jump > threshold within window
}

impl RiskConfig {
    pub fn validate(&self) -> Result<(), String> {
        if !(0.0..=1.0).contains(&self.max_position_pct) { return Err("max_position_pct must be 0..1".into()) }
        if !(0.0..=0.1).contains(&self.max_slippage_pct) { return Err("max_slippage_pct must be 0..0.1".into()) }
        if self.max_open_trades == 0 { return Err("max_open_trades must be > 0".into()) }
        if let Some(asl) = &self.assets {
            for a in asl {
                if a.symbol.trim().is_empty() || a.max_notional_usd <= 0.0 {
                    return Err(format!("invalid asset limit for {}", a.symbol));
                }
            }
        }
        if let Some(bps) = self.spike_threshold_bps {
            if !(0.0..=10_000.0).contains(&bps) { return Err("spike_threshold_bps out of range".into()); }
        }
        Ok(())
    }
}
