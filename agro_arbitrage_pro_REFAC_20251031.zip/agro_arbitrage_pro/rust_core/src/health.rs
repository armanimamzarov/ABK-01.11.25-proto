//! Health module: exports runtime health signals and aggregates subsystem state.
use lazy_static::lazy_static;
use prometheus::{IntGauge, Opts, Registry};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

lazy_static! {
    pub static ref REGISTRY: Registry = Registry::new();
    pub static ref G_HEALTH_OK: IntGauge = {
        let g = IntGauge::with_opts(Opts::new("agro_health_ok", "Overall core health")).unwrap();
        REGISTRY.register(Box::new(g.clone())).ok();
        g
    };
    pub static ref G_WS_CONNECTED: IntGauge = {
        let g = IntGauge::with_opts(Opts::new("agro_ws_connected", "WS connections alive")).unwrap();
        REGISTRY.register(Box::new(g.clone())).ok();
        g
    };
}

#[derive(Clone)]
pub struct Health {
    is_ok: Arc<AtomicBool>,
}
impl Health {
    pub fn new() -> Self { Self{ is_ok: Arc::new(AtomicBool::new(true)) } }
    pub fn set_ok(&self, ok: bool) { self.is_ok.store(ok, Ordering::Relaxed); G_HEALTH_OK.set(if ok {1} else {0}); }
    pub fn ok(&self) -> bool { self.is_ok.load(Ordering::Relaxed) }
}
