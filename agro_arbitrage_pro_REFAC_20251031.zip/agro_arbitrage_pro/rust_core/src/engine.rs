use crate::pb::execution::{ExecReply, Leg, TwoLegRequest, ThreeLegRequest};
use crate::utils::{LATENCY_SEC, EXEC_SUCCESS, ERROR_COUNT};
use std::time::Instant;

pub async fn execute_two(_req: TwoLegRequest) -> ExecReply {
    let now = Instant::now();
    let mut reply = ExecReply::default();
    // mock execution
    reply.success = true;
    reply.pnl_pct = 0.001;
    reply.slippage_pct = 0.0002;
    reply.order_ids = vec!["A123".into(),"B456".into()];
    reply.execution_time_ms = now.elapsed().as_millis() as u32;
    LATENCY_SEC.observe(now.elapsed().as_secs_f64());
    EXEC_SUCCESS.inc();
    reply
}

pub async fn execute_three(_req: ThreeLegRequest) -> ExecReply {
    let now = Instant::now();
    let mut reply = ExecReply::default();
    reply.success = true;
    reply.pnl_pct = 0.0015;
    reply.slippage_pct = 0.0003;
    reply.order_ids = vec!["A1".into(),"B2".into(),"C3".into()];
    reply.execution_time_ms = now.elapsed().as_millis() as u32;
    LATENCY_SEC.observe(now.elapsed().as_secs_f64());
    EXEC_SUCCESS.inc();
    reply
}
