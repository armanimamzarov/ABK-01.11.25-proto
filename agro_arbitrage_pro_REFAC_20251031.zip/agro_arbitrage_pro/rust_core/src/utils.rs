use lazy_static::lazy_static;
use prometheus::{Histogram, IntCounter, Opts, Registry, HistogramOpts, Encoder, TextEncoder};
use std::sync::Arc;
use tokio::sync::RwLock;

lazy_static! {
    pub static ref REGISTRY: Registry = Registry::new();
    pub static ref LATENCY_SEC: Histogram = {
        let opts = HistogramOpts::new("agro_execution_latency_seconds","gRPC execution latency");
        let h = Histogram::with_opts(opts).unwrap();
        REGISTRY.register(Box::new(h.clone())).ok();
        h
    };
    pub static ref ERROR_COUNT: IntCounter = {
        let c = IntCounter::with_opts(Opts::new("agro_error_total","Total errors")).unwrap();
        REGISTRY.register(Box::new(c.clone())).ok();
        c
    };
    pub static ref EXEC_SUCCESS: IntCounter = {
        let c = IntCounter::with_opts(Opts::new("agro_execution_success_total","Successful executions")).unwrap();
        REGISTRY.register(Box::new(c.clone())).ok();
        c
    };
}

pub async fn metrics_body() -> String {
    let encoder = TextEncoder::new();
    let mut buffer = Vec::new();
    encoder.encode(&REGISTRY.gather(), &mut buffer).unwrap();
    String::from_utf8(buffer).unwrap()
}
