use memmap2::{MmapMut, MmapOptions};
use std::{fs::OpenOptions, io::Result as IoResult, path::Path, sync::{Arc, atomic::{AtomicUsize, Ordering}}};

pub struct Ring {
    mmap: MmapMut,
    head: Arc<AtomicUsize>,
    tail: Arc<AtomicUsize>,
    cap: usize,
}

impl Ring {
    pub fn create<P: AsRef<Path>>(path: P, cap: usize) -> IoResult<Self> {
        let file = OpenOptions::new().read(true).write(true).create(true).open(path)?;
        file.set_len(cap as u64)?;
        let mmap = unsafe { MmapOptions::new().len(cap).map_mut(&file)? };
        Ok(Self{ mmap, head: Arc::new(AtomicUsize::new(0)), tail: Arc::new(AtomicUsize::new(0)), cap })
    }

    #[inline]
    pub fn push(&mut self, data: &[u8]) -> bool {
        let needed = data.len() + 8;
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Acquire);
        if head + needed - tail > self.cap { return false; }
        let mut idx = head % self.cap;
        let lenb = (data.len() as u64).to_le_bytes();
        for b in &lenb { self.mmap[idx] = *b; idx = (idx+1)%self.cap; }
        let first = (self.cap - idx).min(data.len());
        self.mmap[idx..idx+first].copy_from_slice(&data[..first]);
        if first < data.len() {
            let rem = data.len() - first;
            self.mmap[0..rem].copy_from_slice(&data[first..]);
            idx = rem;
        } else {
            idx = (idx + first) % self.cap;
        }
        self.head.store(head + needed, Ordering::Release);
        true
    }

    #[inline]
    pub fn pop(&mut self, buf: &mut Vec<u8>) -> Option<usize> {
        let tail = self.tail.load(Ordering::Relaxed);
        if tail == self.head.load(Ordering::Acquire) { return None; }
        let mut idx = tail % self.cap;
        let mut lenb = [0u8;8];
        for i in 0..8 { lenb[i] = self.mmap[idx]; idx = (idx+1)%self.cap; }
        let len = u64::from_le_bytes(lenb) as usize;
        buf.resize(len, 0u8);
        let first = (self.cap - idx).min(len);
        buf[..first].copy_from_slice(&self.mmap[idx..idx+first]);
        if first < len {
            let rem = len - first;
            buf[first..].copy_from_slice(&self.mmap[0..rem]);
            idx = rem;
        } else {
            idx = (idx + first) % self.cap;
        }
        self.tail.store(tail + len + 8, Ordering::Release);
        Some(len)
    }
}
