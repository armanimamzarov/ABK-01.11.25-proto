use std::time::Duration;
use anyhow::Result;
use dashmap::{DashMap, DashSet};
use parking_lot::Mutex;
use tokio::{sync::{mpsc, oneshot}, time::sleep};
use uuid::Uuid;
use tracing::{info, warn, debug, error};
use crate::types::{OrderRequest, OrderUpdate, OrderStatus};
use crate::metrics::METRICS;

#[derive(Clone)]
pub struct ExecutionGateway {
    // Очереди per (exchange,symbol)
    queues: DashMap<(String, String), mpsc::Sender<OrderRequest>>,
    // Идемпотентность
    seen: DashSet<Uuid>,
    // Статусы per order
    states: DashMap<Uuid, OrderStatus>,
    // Контроль параллелизма per key
    limits: DashMap<(String, String), usize>,
}

impl ExecutionGateway {
    pub fn new() -> Self {
        Self {
            queues: DashMap::new(),
            seen: DashSet::new(),
            states: DashMap::new(),
            limits: DashMap::new(),
        }
    }

    pub async fn submit(&self, req: OrderRequest) -> Result<()> {
        // Идемпотентность
        if self.seen.contains(&req.client_order_id) {
            debug!("Duplicate client_order_id={}", req.client_order_id);
            return Ok(());
        }
        self.seen.insert(req.client_order_id);
        self.states.insert(req.client_order_id, OrderStatus::PendingNew);
        METRICS.order_submitted(&req.exchange, &req.symbol, &req.strategy, &req.leg);

        // Очередь для пары
        let key = (req.exchange.clone(), req.symbol.clone());
        let tx = self.queues.entry(key.clone()).or_insert_with(|| {
            let (tx, mut rx) = mpsc::channel::<OrderRequest>(1000);
            // Запускаем воркер
            tokio::spawn(worker_loop(key.clone(), rx));
            tx
        }).clone();

        tx.send(req).await.map_err(|e| anyhow::anyhow!(e))
    }

    pub fn status(&self, id: &Uuid) -> Option<OrderStatus> {
        self.states.get(id).map(|v| v.clone())
    }
}

// Воркер обрабатывает очередь, реализует retry/status flow
async fn worker_loop(key: (String,String), mut rx: mpsc::Receiver<OrderRequest>) {
    let (exchange, symbol) = key;
    while let Some(req) = rx.recv().await {
        let mut attempts = 0usize;
        let max_attempts = 3usize;
        loop {
            attempts += 1;
            debug!("Sending order attempt={} id={} {} {} {}", attempts, req.client_order_id, exchange, symbol, req.side);
            // Здесь реальный вызов к бирже (REST/WS). Мы имитируем успех/ошибку.
            let simulated_ok = attempts >= 1; // заменить на реальный ответ биржи

            if simulated_ok {
                METRICS.order_latency_ms(&exchange, &symbol, &req.strategy, &req.leg, 5.0);
                METRICS.order_ack(&exchange, &symbol, &req.strategy, &req.leg);
                // Обновление статуса
                // (В полном коде сюда прилетают апдейты из WS user stream, тут синтетика)
                // Заполняем как Filled для демонстрации
                METRICS.order_filled(&exchange, &symbol, &req.strategy, &req.leg);
                break;
            } else {
                METRICS.order_reject(&exchange, &symbol, &req.strategy, &req.leg);
                if attempts >= max_attempts {
                    warn!("Order rejected after retries id={}", req.client_order_id);
                    break;
                }
                sleep(Duration::from_millis(150)).await;
            }
        }
    }
}