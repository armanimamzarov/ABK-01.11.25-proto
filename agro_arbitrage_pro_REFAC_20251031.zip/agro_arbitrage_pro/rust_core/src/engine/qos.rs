use std::collections::BinaryHeap;
use std::cmp::Ordering as Cmp;
use std::time::{Duration, Instant};

#[derive(Clone)]
pub struct Task {
    pub priority: u8,          // 0..255
    pub symbol: String,
    pub payload_size: usize,
    pub submitted_at: Instant,
}
impl PartialEq for Task { fn eq(&self, other:&Self)->bool{ self.priority==other.priority } }
impl Eq for Task {}
impl PartialOrd for Task {
    fn partial_cmp(&self, other: &Self) -> Option<Cmp> { Some(self.cmp(other)) }
}
impl Ord for Task {
    fn cmp(&self, other: &Self) -> Cmp {
        other.priority.cmp(&self.priority) // max-heap
            .then_with(|| self.submitted_at.cmp(&other.submitted_at))
    }
}

pub struct QoS {
    pub heap: BinaryHeap<Task>,
    pub max_bytes_per_sec: usize,
    pub sent_bytes: usize,
    pub last_reset: Instant,
}
impl QoS {
    pub fn new(max_bps: usize) -> Self {
        Self{ heap: BinaryHeap::new(), max_bytes_per_sec: max_bps, sent_bytes: 0, last_reset: Instant::now() }
    }
    pub fn submit(&mut self, t: Task){ self.heap.push(t); }
    pub fn poll(&mut self) -> Option<Task> {
        if self.last_reset.elapsed() > Duration::from_secs(1) {
            self.sent_bytes = 0; self.last_reset = Instant::now();
        }
        if let Some(t)= self.heap.peek() {
            if self.sent_bytes + t.payload_size > self.max_bytes_per_sec { return None; }
        }
        let t = self.heap.pop()?;
        self.sent_bytes += t.payload_size;
        Some(t)
    }
}
