use serde::{Serialize, Deserialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum OrderStatus {
    PendingNew,
    Ack,
    Partial,
    Filled,
    Cancelled,
    Rejected,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderRequest {
    pub client_order_id: Uuid,
    pub symbol: String,
    pub exchange: String,
    pub side: String,       // "buy" | "sell"
    pub qty: f64,
    pub price: Option<f64>, // limit or None for market
    pub strategy: String,
    pub leg: String,        // leg identifier
    pub ts: DateTime<Utc>,
    pub priority: u8,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderUpdate {
    pub client_order_id: Uuid,
    pub status: OrderStatus,
    pub filled_qty: f64,
    pub avg_price: Option<f64>,
    pub ts: DateTime<Utc>,
    pub reject_reason: Option<String>,
}