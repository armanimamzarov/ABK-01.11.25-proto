use anyhow::Result;
use sqlx::{Pool, Postgres};
use serde_json::Value;

#[derive(Debug)]
pub struct Repo { pub pool: Pool<Postgres> }

impl Repo {
    pub fn new(pool: Pool<Postgres>) -> Self { Self{ pool } }

    pub async fn insert_opportunity(&self, strategy: &str, symbol: &str, expected_profit_pct: f64, payload: &Value) -> Result<()> {
        sqlx::query!("INSERT INTO opportunity(strategy, symbol, expected_profit_pct, payload) VALUES ($1,$2,$3,$4)",
            strategy, symbol, expected_profit_pct, payload).execute(&self.pool).await?;
        Ok(())
    }

    pub async fn insert_execution(&self, strategy: &str, pnl_pct: f64, slippage_pct: f64, order_ids: &str, payload: &Value) -> Result<()> {
        sqlx::query!("INSERT INTO execution(strategy, pnl_pct, slippage_pct, order_ids, payload) VALUES ($1,$2,$3,$4,$5)",
            strategy, pnl_pct, slippage_pct, order_ids, payload).execute(&self.pool).await?;
        Ok(())
    }
}
