use anyhow::Result;
use sqlx::{Pool, Postgres};
use std::time::Duration;

#[derive(Clone)]
pub struct Db { pub pool: Pool<Postgres> }

impl Db {
    pub async fn connect(dsn: &str) -> Result<Self> {
        let pool = sqlx::postgres::PgPoolOptions::new()
            .max_connections(5)
            .acquire_timeout(Duration::from_secs(5))
            .connect(dsn).await?;
        Ok(Self{ pool })
    }
}
