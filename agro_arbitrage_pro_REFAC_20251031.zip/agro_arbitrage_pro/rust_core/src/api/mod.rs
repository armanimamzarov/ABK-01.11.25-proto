use axum::{routing::get, Router};
use std::net::SocketAddr;
use std::sync::Arc;
use crate::engine::ArbitrageEngine;
use tracing::info;

pub async fn start_rest_api(_engine: Arc<ArbitrageEngine>, port: u16) -> anyhow::Result<()> {
    let app = Router::new().route("/health", get(|| async { "ok" }));
    let addr = SocketAddr::from(([0, 0, 0, 0], port));
    info!("REST listening on {}", addr);
    axum::Server::bind(&addr).serve(app.into_make_service()).await?;
    Ok(())
}
