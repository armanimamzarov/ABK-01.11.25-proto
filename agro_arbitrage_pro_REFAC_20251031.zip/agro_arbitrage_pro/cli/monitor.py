
import time, json
from rich.live import Live
from rich.table import Table
from rich import box

def read_json(path):
    try: return json.loads(open(path,"r",encoding="utf-8").read())
    except Exception: return {}

def build_table():
    t = Table(title="Agro Arbitrage Live", box=box.ROUNDED)
    t.add_column("Metric"); t.add_column("Value")
    health = read_json("python_app/logs/tao/health.json")
    pids = read_json("python_app/logs/pids.json")
    t.add_row("Alive", str(health.get("alive")))
    t.add_row("Mem %", str(health.get("mem")))
    t.add_row("WS gaps", str(health.get("ws_gaps")))
    t.add_row("PIDs", ", ".join(f"{k}:{v}" for k,v in pids.items()))
    return t

def main():
    with Live(build_table(), refresh_per_second=2) as live:
        while True:
            time.sleep(1)
            live.update(build_table())

if __name__ == "__main__":
    main()
