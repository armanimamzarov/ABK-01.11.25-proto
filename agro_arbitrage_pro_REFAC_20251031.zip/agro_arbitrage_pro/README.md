# agro_arbitrage_pro — Production Upgrades (2025-10-31)

Эта версия добавляет ключевые блоки для реальной торговли:

1) **Execution Gateway**: очередь ордеров per symbol/exchange, идемпотентность `client_order_id`, детерминированные статусы и retry.
2) **Risk & Exposure Control**: лимиты `max_position_per_symbol`, `max_daily_loss`, `leverage_limit`, автоматический Kill Switch.
3) **Orderbook Sync / Snapshot Validation**: проверка timestamp/depth между источниками, авто-ресинхронизация при расхождении.
4) **Strategy Engine**: централизованный `configs/strategy_config.toml`, live-toggle без рестарта через HTTP API.
5) **Backtesting & Replay**: оффлайн-движок на исторических данных (CSV/Parquet), реплей квазиреалтайм.
6) **Metrics API / Prometheus**: метрики с лейблами `exchange`, `pair`, `strategy`, `leg`.
7) **PnL / Logging**: дневные PnL, drawdown, средний риск, отчёты в `reports/YYYY-MM-DD.csv`.

## Быстрый старт (dev)

```bash
# 1) Сконфигурируйте стратегии
cp configs/strategy_config.example.toml configs/strategy_config.toml

# 2) Поднимите метрики/дашборды (опционально)
docker compose up -d

# 3) Запустите Python-оркестрацию (реплей или лайв)
python -m python_app.replay --source sample_data/orderbooks.csv --speed 5.0
# или
python -m python_app.live --paper true
```

## Основные компоненты

- `rust_core/`
  - `engine/execution_gateway.rs` — очередь ордеров, идемпотентность и статусы.
  - `risk/risk_engine.rs` — лимиты и Kill Switch.
  - `market_data/orderbook_manager.rs` — снапшоты, валидация и ресинк.
  - `metrics/` — Prometheus-метрики.
- `python_app/`
  - `backtest_engine.py` — бэктест с визуализацией PnL/латентности.
  - `replay.py` — реплей исторических котировок в квазиреалтайме.
  - `live.py` — вход в лайв/пейпер режим с hot-reload конфигов.
  - `metrics.py`, `logging_setup.py` — метрики и логирование.
- `configs/strategy_config.toml` — централизованные параметры стратегий.
- `docker-compose.yml` — Prometheus+Grafana.
- `grafana/` и `prometheus/` — настройки дашбордов/скрейпа.
- `reports/` — дневные отчёты PnL.

## Примечание

Код хорошо типизирован и покрыт базовыми тестами (Rust/Python). В продакшене рекомендуем
добавить интеграционные тесты с "песочными" ключами бирж и тестовой средой.
---

## Merge Notes (2025-10-31)
Эта сборка объединяет **ready_production** и **updates**.
При конфликте приоритет отдан обновлённым файлам. Внесены правки совместимости (Cargo.toml, risk_engine).

### Quick check
```bash
# конфиг
cp configs/strategy_config.example.toml configs/strategy_config.toml

# метрики (локально)
docker compose up -d

# реплей
python -m python_app.replay --source sample_data/orderbooks.csv --speed 5

# бэктест
python -m python_app.backtest_engine --csv sample_data/orderbooks.csv --speed 10
```
