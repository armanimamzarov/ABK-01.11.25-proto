from fastapi import FastAPI
from fastapi.responses import Response
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from analytics.metrics import g_live, c_signals, c_fills, h_latency

app = FastAPI()

@app.get("/health")
def health(): return {"ok": True}

@app.get("/metrics")
def metrics(): return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

from .panel import router as panel_router
app.include_router(panel_router, prefix="/")


if __name__ == "__main__":
    import uvicorn, os
    port = int(os.environ.get("PY_HTTP_PORT","9101"))
    uvicorn.run(app, host="0.0.0.0", port=port)
