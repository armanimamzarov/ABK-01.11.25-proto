from fastapi import APIRouter
from fastapi.responses import HTMLResponse
router = APIRouter()

@router.get("/", response_class=HTMLResponse)
def home():
    return """
    <html><head><title>Agro Panel</title></head>
    <body>
      <h1>Agro Arbitrage Pro</h1>
      <ul>
        <li><a href="/health">Health</a></li>
        <li><a href="/metrics">Metrics</a></li>
      </ul>
    </body></html>
    """
