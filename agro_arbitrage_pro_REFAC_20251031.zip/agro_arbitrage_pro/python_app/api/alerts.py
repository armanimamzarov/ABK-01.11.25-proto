import os, json, aiohttp
from fastapi import APIRouter, Request
from utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
SLACK_WEBHOOK = os.getenv("SLACK_WEBHOOK_URL")

async def send_telegram(text: str):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID: return
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    async with aiohttp.ClientSession() as sess:
        await sess.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": text, "parse_mode":"Markdown"})

async def send_slack(text: str):
    if not SLACK_WEBHOOK: return
    async with aiohttp.ClientSession() as sess:
        await sess.post(SLACK_WEBHOOK, json={"text": text})

@router.post("/alert")
async def alert(req: Request):
    payload = await req.json()
    txt = f"⚠️ Alertmanager: {json.dumps(payload)[:500]}"
    await send_telegram(txt)
    await send_slack(txt)
    return {"ok": True}
