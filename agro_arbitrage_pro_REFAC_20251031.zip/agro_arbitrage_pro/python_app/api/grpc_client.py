"""gRPC Client for low-latency communication with Rust Core (with retries & circuit breaker)"""
import grpc
import asyncio, os, random, time
from typing import Optional, Dict, Any, AsyncIterator
from utils.logger import setup_logger
logger = setup_logger(__name__)
try:
    from api.protos import execution_pb2 as pb, execution_pb2_grpc as pb_grpc
    HAS_STUBS = True
except Exception as e:
    logger.warning(f"No protobuf stubs: {e}. Using mock mode."); pb = pb_grpc = None; HAS_STUBS = False
class CircuitBreaker:
    def __init__(self, fail_threshold:int=5, cooldown:float=5.0):
        self.fail_threshold = fail_threshold; self.cooldown = cooldown; self.failures = 0; self.open_until = 0.0
    def ok(self)->bool: return time.time() >= self.open_until
    def on_success(self): self.failures = 0
    def on_failure(self):
        self.failures += 1
        if self.failures >= self.fail_threshold:
            self.open_until = time.time() + self.cooldown; logger.error("gRPC circuit open"); self.failures = 0
class GrpcClient:
    def __init__(self, address: str):
        self.address = address; self.channel: Optional[grpc.aio.Channel] = None; self.stub=None; self.mock = not HAS_STUBS; self.cb = CircuitBreaker()
    async def connect(self):
        self.channel = grpc.aio.insecure_channel(self.address, options=[("grpc.keepalive_time_ms", 10000)])
        if HAS_STUBS: self.stub = pb_grpc.ExecutionStub(self.channel)
        logger.info(f"⚡ gRPC connected to {self.address} (mock={self.mock})")
    async def _retry(self, coro_factory, desc: str):
        if not self.cb.ok(): raise RuntimeError("Circuit open for gRPC requests")
        backoff = 0.05
        for attempt in range(5):
            try:
                res = await coro_factory(); self.cb.on_success(); return res
            except Exception as e:
                self.cb.on_failure()
                if attempt==4: logger.exception("gRPC %s failed: %s", desc, e); raise
                jitter = random.uniform(0, backoff); await asyncio.sleep(backoff + jitter); backoff = min(backoff*2, 1.0)
    async def execute_two_leg(self, a: Dict[str, Any], b: Dict[str, Any], meta: Dict[str, Any]) -> Dict[str, Any]:
        if self.mock or not self.stub: return {"success": True, "pnl_pct": 0.12, "slippage_pct": 0.02, "order_ids": ["mock1","mock2"], "execution_time_ms": 50}
        async def call():
            req = pb.TwoLegRequest(a=pb.Leg(**a), b=pb.Leg(**b), meta=pb.ExecMeta(**meta)); return await self.stub.ExecuteTwoLeg(req, timeout=2.0)
        resp = await self._retry(call, "ExecuteTwoLeg")
        return {"success": resp.success, "pnl_pct": resp.pnl_pct, "slippage_pct": resp.slippage_pct, "order_ids": list(resp.order_ids), "execution_time_ms": resp.execution_time_ms}
    async def execute_three_leg(self, a: Dict[str, Any], b: Dict[str, Any], c: Dict[str, Any], meta: Dict[str, Any]) -> Dict[str, Any]:
        if self.mock or not self.stub: return {"success": True, "pnl_pct": 0.18, "slippage_pct": 0.03, "order_ids": ["mock1","mock2","mock3"], "execution_time_ms": 75}
        async def call():
            req = pb.ThreeLegRequest(a=pb.Leg(**a), b=pb.Leg(**b), c=pb.Leg(**c), meta=pb.ExecMeta(**meta)); return await self.stub.ExecuteThreeLeg(req, timeout=3.0)
        resp = await self._retry(call, "ExecuteThreeLeg")
        return {"success": resp.success, "pnl_pct": resp.pnl_pct, "slippage_pct": resp.slippage_pct, "order_ids": list(resp.order_ids), "execution_time_ms": resp.execution_time_ms}
    async def get_health(self) -> Dict[str, Any]:
        if self.mock or not self.stub: return {"healthy": True, "status": "mock"}
        async def call(): return await self.stub.Health(pb.Empty(), timeout=1.0)
        resp = await self._retry(call, "Health"); return {"healthy": bool(resp.ok), "status": resp.status}
    async def stream_status(self):
        while True: yield {"ts": time.time(), "ok": True}; await asyncio.sleep(1.0)
    async def close(self):
        if self.channel: await self.channel.close(); logger.info("⚡ gRPC connection closed")
