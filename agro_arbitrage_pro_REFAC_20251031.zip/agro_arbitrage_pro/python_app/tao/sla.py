from utils.logger import setup_logger
log = setup_logger(__name__)

class WSSLAController:
    def __init__(self, max_gap_sec: float = 20.0, downgrade_limit: int = 3):
        self.max_gap = max_gap_sec
        self.breaches = 0
        self.limit = downgrade_limit
    def on_gap(self, gap_sec: float):
        if gap_sec > self.max_gap:
            self.breaches += 1
            log.warning("WSSLA breach: gap=%.2fs, count=%d", gap_sec, self.breaches)
            return (self.breaches >= self.limit)
        return False
