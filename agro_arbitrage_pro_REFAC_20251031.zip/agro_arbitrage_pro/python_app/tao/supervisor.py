import time, json, psutil, asyncio, aiohttp
from pathlib import Path
from utils.logger import setup_logger
from .ws_watchdog import gaps
from .sys_checks import disk_ok, dns_ok, clock_skew_ok
from .recovery import restart_process, downgrade_ws, upgrade_ws
logger = setup_logger(__name__)

class TAOSupervisor:
    def __init__(self, interval_sec=10, timeout_reactivate=5, api="http://localhost:8000"):
        self.interval_sec = interval_sec; self.timeout_reactivate = timeout_reactivate; self.api=api
        Path("logs/tao").mkdir(parents=True, exist_ok=True); self.health_path="logs/tao/health.json"
    async def _ping(self, path):
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3)) as s:
                async with s.get(f"{self.api}{path}") as r: return r.status==200
        except Exception: return False
    async def start(self):
        while True:
            alive = await self._ping("/health")
            mem = psutil.virtual_memory().percent
            bad_ws = gaps(20)
            sys_ok = disk_ok() and dns_ok() and clock_skew_ok()
            Path(self.health_path).write_text(json.dumps({"ts":time.time(),"alive":alive,"mem":mem,"ws_gaps":bad_ws,"sys_ok":sys_ok}, indent=2), encoding="utf-8")
            if (not alive) or bad_ws or (not sys_ok):
                if bad_ws and len(bad_ws) > 2:
                    downgrade_ws()
                logger.warning("health degraded: alive=%s ws=%s sys=%s -> recovery delay=%ss", alive, bool(bad_ws), sys_ok, self.timeout_reactivate)
                await asyncio.sleep(self.timeout_reactivate)
            await asyncio.sleep(self.interval_sec)

class AutoRecovery:
    async def recover_ws(self): pass
    async def recover_api(self): pass
    async def recover_process(self, name: str): pass
