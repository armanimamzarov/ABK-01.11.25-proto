import json, time
from pathlib import Path
from utils.logger import setup_logger
log = setup_logger(__name__)

HEALTH_FILE = "logs/market/last_ticks.json"

def heartbeat(exchange: str, symbol: str):
    Path(HEALTH_FILE).parent.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(Path(HEALTH_FILE).read_text(encoding="utf-8"))
    except Exception:
        data = {}
    data.setdefault(exchange, {})[symbol] = time.time()
    Path(HEALTH_FILE).write_text(json.dumps(data, indent=2), encoding="utf-8")

def gaps(timeout_sec=15):
    try:
        data = json.loads(Path(HEALTH_FILE).read_text(encoding="utf-8"))
    except Exception:
        return []
    now = time.time()
    bad = []
    for ex, mp in data.items():
        for sym, ts in mp.items():
            if now - float(ts) > timeout_sec:
                bad.append((ex, sym, now - float(ts)))
    if bad:
        log.warning("WS gaps detected: %s", bad)
    return bad
