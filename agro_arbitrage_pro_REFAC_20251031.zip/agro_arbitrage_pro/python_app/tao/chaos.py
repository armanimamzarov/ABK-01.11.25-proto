import os, random, time
from utils.logger import setup_logger
log = setup_logger(__name__)

def random_kill(pidfile: str, probability: float = 0.05):
    if random.random() > probability: return False
    try:
        import json, signal
        p = json.loads(open(pidfile,"r",encoding="utf-8").read())
        pick = random.choice(list(p.values()))
        os.kill(int(pick), signal.SIGTERM)
        log.warning("Chaos: killed pid=%s", pick)
        return True
    except Exception as e:
        log.warning("Chaos error: %s", e)
        return False
