import asyncio, subprocess, sys, time, os
from utils.logger import setup_logger
log = setup_logger(__name__)

PROCS = {
    "api": ["uvicorn","api.server:app","--host","0.0.0.0","--port","8000"],
    "telegram": [sys.executable,"-m","python_app.telegram.bot"],
}

async def _run(name, cmd):
    backoff = 1
    while True:
        try:
            log.info("start process %s: %s", name, cmd)
            p = await asyncio.create_subprocess_exec(*cmd)
            rc = await p.wait()
            log.warning("%s exited rc=%s", name, rc)
        except Exception as e:
            log.exception("proc %s crashed: %s", name, e)
        await asyncio.sleep(backoff)
        backoff = min(backoff*2, 60)

async def supervise_all():
    tasks = []
    for n,c in PROCS.items():
        tasks.append(asyncio.create_task(_run(n, c)))
    await asyncio.gather(*tasks)
