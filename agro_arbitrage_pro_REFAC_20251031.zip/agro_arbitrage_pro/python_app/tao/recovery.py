
import asyncio, os, json, time, signal, subprocess
from pathlib import Path
from utils.logger import setup_logger
log = setup_logger(__name__)

PIDFILE = Path("logs/pids.json")
ENVFILE = Path(".env")  # WS downgrade/upgrade by editing USE_WS

def _pids():
    if PIDFILE.exists():
        try: return json.loads(PIDFILE.read_text(encoding="utf-8"))
        except Exception: return {}
    return {}

async def restart_process(name: str, cmd: list, backoff: float = 1.0, limit: float = 60.0):
    """Kill if running; then start with exponential backoff retries."""
    pids = _pids()
    pid = pids.get(name)
    if pid:
        try: os.kill(int(pid), signal.SIGTERM)
        except Exception: pass
    await asyncio.sleep(0.5)
    delay = backoff
    while True:
        try:
            log.warning("AutoRecovery: starting %s: %s", name, cmd)
            p = await asyncio.create_subprocess_exec(*cmd)
            pids = _pids(); pids[name] = p.pid; PIDFILE.write_text(json.dumps(pids, indent=2), encoding="utf-8")
            return True
        except Exception as e:
            log.exception("restart %s failed: %s", name, e)
            await asyncio.sleep(delay)
            delay = min(delay * 2.0, limit)

def _env_set(key: str, value: str):
    if not ENVFILE.exists(): return False
    lines = ENVFILE.read_text(encoding="utf-8").splitlines()
    changed = False
    out = []
    for ln in lines:
        if ln.startswith(key+"="):
            out.append(f"{key}={value}"); changed=True
        else:
            out.append(ln)
    if not changed:
        out.append(f"{key}={value}")
    ENVFILE.write_text("\n".join(out)+"\n", encoding="utf-8")
    return True

def downgrade_ws():
    log.warning("TAO: Downgrading WS → REST (USE_WS=false) due to sustained gaps")
    _env_set("USE_WS", "false")

def upgrade_ws():
    log.warning("TAO: Upgrading REST → WS (USE_WS=true) after recovery")
    _env_set("USE_WS", "true")
