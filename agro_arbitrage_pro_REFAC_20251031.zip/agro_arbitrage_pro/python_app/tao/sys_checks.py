import shutil, socket, time
def disk_ok(threshold_pct=90):
    total, used, free = shutil.disk_usage("."); return (used/total*100) < threshold_pct
def dns_ok(host="api.binance.com", timeout=2):
    try:
        socket.getaddrinfo(host, None, timeout=timeout); return True
    except Exception: return False
def clock_skew_ok(max_skew_sec=2.0):
    # placeholder; in prod compare with NTP
    return True
