import pandas as pd
import argparse, time
from .logging_setup import setup
from .metrics import serve
import logging
logger = logging.getLogger(__name__)

def main(source: str, speed: float):
    setup()
    serve()
    df = pd.read_csv(source, parse_dates=["ts"]).sort_values("ts")
    start = df["ts"].iloc[0]
    for _, row in df.iterrows():
        # Здесь можно пробрасывать котировки в Rust через FFI/IPC
        time.sleep(max(0.0, 0.01 / speed))
logger.info("Replay done.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--speed", type=float, default=1.0)
    args = ap.parse_args()
    main(args.source, args.speed)