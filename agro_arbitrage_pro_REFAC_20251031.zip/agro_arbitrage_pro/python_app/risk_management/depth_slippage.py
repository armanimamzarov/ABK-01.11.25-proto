from typing import List, Tuple

def vwap_price(levels: List[Tuple[float, float]], amount: float) -> float:
    """Compute VWAP to fill `amount` across depth levels (price, qty)."""
    if amount <= 0: return 0.0
    filled, cost = 0.0, 0.0
    for price, qty in levels:
        take = min(qty, amount - filled)
        if take <= 0: break
        cost += take * price
        filled += take
        if filled >= amount: break
    return (cost / filled) if filled > 0 else 0.0

def est_slippage_pct(side: str, best_px: float, vwap_px: float) -> float:
    if best_px <= 0 or vwap_px <= 0: return 0.0
    if side.lower() == "buy":
        return (vwap_px - best_px) / best_px * 100.0
    else:
        return (best_px - vwap_px) / best_px * 100.0
