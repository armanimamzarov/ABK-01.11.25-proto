import time
from typing import Dict

class KillSwitch:
    def __init__(self, max_outage_ms: int = 5_000):
        self.max_outage_ms = max_outage_ms
        self.last_ok: Dict[str, int] = {}

    def heartbeat(self, exchange: str, ts_ms: int):
        self.last_ok[exchange] = ts_ms

    def should_kill(self) -> bool:
        now = int(time.time()*1000)
        bad = [ex for ex, ts in self.last_ok.items() if (now - ts) > self.max_outage_ms]
        # if majority of tracked exchanges are down — kill
        return len(bad) >= max(1, len(self.last_ok)//2)
