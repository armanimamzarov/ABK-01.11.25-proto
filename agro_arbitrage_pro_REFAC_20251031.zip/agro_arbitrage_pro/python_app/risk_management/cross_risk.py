from typing import Dict

def risk_correlation_matrix() -> Dict[str, Dict[str, float]]:
    """Static example; extend to dynamic estimator.
    Returns correlation coefficients between strategies ([-1,1])."""
    return {
        "triangular": {"cross": 0.4, "spread": 0.2},
        "cross": {"triangular": 0.4, "spread": 0.3},
        "spread": {"triangular": 0.2, "cross": 0.3},
    }
