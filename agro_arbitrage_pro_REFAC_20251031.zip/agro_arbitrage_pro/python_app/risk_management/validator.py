import json, os
from typing import Dict, Any

def load_and_validate(path: str) -> Dict[str, Any]:
    if not os.path.exists(path): return {"limits": {}}
    with open(path,"r",encoding="utf-8") as f: cfg=json.load(f)
    for ex,lim in cfg.get("limits",{}).items():
        mnu=float(lim.get("max_notional_usd",0)); assert mnu>=0, f"max_notional_usd >=0 for {ex}"
    return cfg
