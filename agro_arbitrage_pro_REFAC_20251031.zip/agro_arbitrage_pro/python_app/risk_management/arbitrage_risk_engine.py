import os, json, time, random, asyncio
from pathlib import Path
from typing import Dict, Any, Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)

def _now_utc_day():
    return time.strftime("%Y-%m-%d", time.gmtime())

class RiskEngine:
    def __init__(self, cfg: Dict[str, Any], audit_path: str="logs/risk_engine/risk_audit.json"):
        self.cfg = cfg or {}
        Path("logs/risk_engine").mkdir(parents=True, exist_ok=True)
        self.audit_path = audit_path
        self.daily_loss = 0.0
        self.equity_peak = 0.0
        self.open_positions = 0
        self.last_day = _now_utc_day()
        self.consec_wins = 0
        self.consec_losses = 0
        self.paused_until = 0.0
        self.mode = cfg.get("mode","auto")

    def _append_audit(self, rec: Dict[str, Any]):
        rec["ts"] = time.time()
        with open(self.audit_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False)+"\n")

    def daily_reset_if_needed(self):
        d = _now_utc_day()
        if d != self.last_day:
            self.daily_loss = 0.0
            self.open_positions = 0
            self.consec_wins = 0
            self.consec_losses = 0
            self.last_day = d
            self._append_audit({"event":"daily_reset", "day":d})

    def can_trade_now(self) -> bool:
        return time.time() >= self.paused_until

    def pause(self, seconds: int, reason: str):
        self.paused_until = max(self.paused_until, time.time() + seconds)
        self._append_audit({"event":"pause","reason":reason,"seconds":seconds})

    def check_signal(self, expected_profit: float, expected_risk: float, equity: float) -> Dict[str, Any]:
        self.daily_reset_if_needed()
        if not self.can_trade_now():
            return {"ok": False, "reason": "cooldown"}
        # drawdown
        if self.equity_peak == 0.0:
            self.equity_peak = equity
        self.equity_peak = max(self.equity_peak, equity)
        dd_pct = max(0.0, (self.equity_peak - equity) / max(self.equity_peak,1e-9) * 100.0)
        if dd_pct > float(self.cfg.get("max_drawdown_pct", 10.0)):
            self.pause(self.cfg.get("cooldown_time_sec",[15,30])[0], "drawdown_limit")
            return {"ok": False, "reason": "max_drawdown"}
        # daily loss
        if self.daily_loss + expected_risk > float(self.cfg.get("daily_loss_limit", 5.0)):
            self.pause(self.cfg.get("auto_recover_minutes",5)*60, "daily_loss_limit")
            return {"ok": False, "reason": "daily_loss"}
        # open positions
        if self.open_positions >= int(self.cfg.get("max_open_positions",3)):
            return {"ok": False, "reason": "max_open_positions"}

        # scale factor by streaks
        scale = 1.0
        if self.consec_wins >= 3:
            scale *= 1.10
        if self.consec_losses >= 2:
            scale *= 0.80
        # clamp scale
        rng = self.cfg.get("risk_scale_factor",[1.0,1.5])
        scale = max(rng[0], min(rng[1], scale))
        return {"ok": True, "scale": scale}

    def on_fill(self, pnl_usd: float):
        # update streaks + daily loss
        if pnl_usd >= 0:
            self.consec_wins += 1; self.consec_losses = 0
        else:
            self.consec_losses += 1; self.consec_wins = 0
            self.daily_loss += abs(pnl_usd)
            # cooldown on stop event
            cd_rng = self.cfg.get("cooldown_time_sec",[15,30])
            self.pause(cd_rng[0], "loss_cooldown")

        self._append_audit({"event":"fill","pnl":pnl_usd,"wins":self.consec_wins,"losses":self.consec_losses,"daily_loss":self.daily_loss})

    def on_stop_loss(self):
        cd_rng = self.cfg.get("cooldown_time_sec",[15,30])
        self.pause(cd_rng[0], "stop_loss")

    def on_take_profit(self):
        self._append_audit({"event":"take_profit"})

    def set_mode(self, mode: str):
        assert mode in ("auto","manual")
        self.mode = mode
        self._append_audit({"event":"mode","value":mode})
