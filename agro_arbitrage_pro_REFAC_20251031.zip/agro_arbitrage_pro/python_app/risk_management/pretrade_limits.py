from typing import Dict, Any, Tuple, DefaultDict
from collections import defaultdict

class PreTradeLimits:
    def __init__(self, per_exchange: float=50000, per_symbol: float=25000, per_strategy: float=30000):
        self.per_exchange = per_exchange
        self.per_symbol = per_symbol
        self.per_strategy = per_strategy
        self.exposure_ex: DefaultDict[str, float] = defaultdict(float)
        self.exposure_sym: DefaultDict[str, float] = defaultdict(float)
        self.exposure_str: DefaultDict[str, float] = defaultdict(float)

    def allow(self, exchange: str, symbol: str, strategy: str, notional: float) -> bool:
        return (self.exposure_ex[exchange] + notional <= self.per_exchange and
                self.exposure_sym[symbol] + notional <= self.per_symbol and
                self.exposure_str[strategy] + notional <= self.per_strategy)

    def book(self, exchange: str, symbol: str, strategy: str, notional: float):
        self.exposure_ex[exchange] += notional
        self.exposure_sym[symbol] += notional
        self.exposure_str[strategy] += notional

    def release(self, exchange: str, symbol: str, strategy: str, notional: float):
        self.exposure_ex[exchange] -= notional
        self.exposure_sym[symbol] -= notional
        self.exposure_str[strategy] -= notional
