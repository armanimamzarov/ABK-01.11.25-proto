from typing import Dict, Any

class LiquidityChecker:
    def __init__(self, min_liquidity_usd: float = 10000.0):
        self.min_liquidity_usd = min_liquidity_usd

    def enough(self, opp: Dict[str, Any]) -> bool:
        notional = 0.0
        for l in opp.get("legs", []):
            px = l.get("price") or 0.0
            amt = l.get("amount") or 0.0
            notional += px * amt
        return notional >= self.min_liquidity_usd
