class SlippageController:
    def __init__(self, max_slippage_pct: float = 0.35):
        self.max_slippage_pct = max_slippage_pct
    def ok(self, est_slippage_pct: float) -> bool:
        return est_slippage_pct <= self.max_slippage_pct
