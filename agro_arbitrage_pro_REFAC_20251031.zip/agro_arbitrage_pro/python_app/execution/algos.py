import asyncio, time
from typing import Dict, Any, List

async def twap(ex, symbol: str, side: str, total: float, price: float, slices: int=5, delay: float=0.5, params=None):
    params = params or {}
    per = total / slices
    results = []
    for _ in range(slices):
        r = await ex.create_order(symbol, side, per, price, "limit", params=params)
        results.append(r); await asyncio.sleep(delay)
    return results

async def hvwap(ex, symbol: str, side: str, target_prices: List[float], amounts: List[float], params=None):
    # amounts must sum to total; prices are levels (VWAP-target curve)
    params = params or {}
    results = []
    for px, amt in zip(target_prices, amounts):
        r = await ex.create_order(symbol, side, amt, px, "limit", params=params)
        results.append(r)
    return results
