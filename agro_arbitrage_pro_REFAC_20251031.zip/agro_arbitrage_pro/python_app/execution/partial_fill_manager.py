from typing import Dict, Any

class PartialFillManager:
    def __init__(self, min_fill_ratio: float=0.7):
        self.min_fill_ratio = min_fill_ratio

    def acceptable(self, filled: float, requested: float) -> bool:
        if requested <= 0: return False
        return (filled / requested) >= self.min_fill_ratio
