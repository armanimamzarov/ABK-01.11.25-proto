def realized_pnl_pct(expected_pct: float, taker_fee: float, maker_fee: float, maker_share: float=0.0) -> float:
    # weighted fees
    eff_fee = taker_fee*(1-maker_share) + maker_fee*maker_share
    return expected_pct - eff_fee*100.0
