import asyncio, os
import pytest
from api.grpc_client import GrpcClient

@pytest.mark.asyncio
async def test_grpc_client_mock():
    c = GrpcClient(os.environ.get("GRPC_ADDRESS","localhost:8080"))
    await c.connect()
    r = await c.execute_two_leg(
        dict(exchange="binance", symbol="BTC/USDT", qty=0.01, price=60000.0, side="BUY"),
        dict(exchange="bybit", symbol="BTC/USDT", qty=0.01, price=60010.0, side="SELL"),
        dict(strategy="test", correlation_id="t1", max_slippage_pct=0.01, fee_pct=0.001),
    )
    assert "success" in r and "execution_time_ms" in r
    await c.close()
