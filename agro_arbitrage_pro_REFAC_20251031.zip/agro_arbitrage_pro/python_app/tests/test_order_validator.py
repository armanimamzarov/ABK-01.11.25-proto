from core.order_validator import OrderValidator
def test_validator_notional():
    v=OrderValidator({"x": {"min_notional_usd": 10}})
    assert v.validate("x","BTC/USDT",100,0.1)
    assert not v.validate("x","BTC/USDT",100,0.05)
