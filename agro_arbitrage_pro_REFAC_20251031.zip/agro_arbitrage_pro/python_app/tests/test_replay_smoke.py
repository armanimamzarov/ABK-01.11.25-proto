
import os, subprocess, sys, time

def test_replay_smoke():
    # run replay with small speedup; expect graceful finish
    env=os.environ.copy(); env["REPLAY_X"]="10"
    p = subprocess.Popen([sys.executable, "replay/run_replay.py"], env=env)
    time.sleep(1.0)
    p.terminate()
    assert True
