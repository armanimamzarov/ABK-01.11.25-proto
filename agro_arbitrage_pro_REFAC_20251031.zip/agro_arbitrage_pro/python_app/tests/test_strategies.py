import pytest
import asyncio
from strategies.spot_arbitrage import SpotArbitrage

@pytest.mark.asyncio
async def test_spot_scan_generates_opportunity():
    s = SpotArbitrage({"min_profit_percentage":0.01})
    market = {"orderbooks": {"binance:BTC/USDT": {"symbol":"BTC/USDT","best_bid":{"price":101},"best_ask":{"price":100}}}}
    opps = await s.scan(market)
    assert len(opps) >= 1
    assert opps[0]["expected_profit_pct"] > 0
