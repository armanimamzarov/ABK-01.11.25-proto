
import os
from config.config_loader import load_all
from pathlib import Path

def test_load_all_reads_configs(tmp_path):
    base = str(Path(__file__).resolve().parents[2])
    cfg = load_all(base + "/agro_arbitrage_pro")
    assert "system" in cfg and "exchanges" in cfg
    assert isinstance(cfg["risk"], dict)
