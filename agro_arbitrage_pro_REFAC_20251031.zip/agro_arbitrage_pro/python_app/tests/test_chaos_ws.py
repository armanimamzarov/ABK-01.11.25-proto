import pytest, asyncio
from core.market_monitor import MarketMonitor

@pytest.mark.asyncio
async def test_ws_drop_recovery(monkeypatch):
    class Ex:
        async def fetch_orderbook(self, s): return {"symbol":s, "best_bid":{"price":100,"qty":1},"best_ask":{"price":101,"qty":1},"bids":[[100,1]],"asks":[[101,1]]}
        async def watch_orderbook(self, s): raise Exception("WS drop")
    mm = MarketMonitor({"binance":Ex()}, ["BTC/USDT"])
    await mm.start()
    await asyncio.sleep(0.3)
    snap = mm.get_snapshot()
    assert "binance:BTC/USDT" in snap["orderbooks"]
