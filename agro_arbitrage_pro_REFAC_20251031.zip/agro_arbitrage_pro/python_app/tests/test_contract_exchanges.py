import pytest
from exchanges.binance_handler import BinanceHandler

@pytest.mark.asyncio
async def test_fetch_orderbook_contract(monkeypatch):
    ex = BinanceHandler(testnet=True)
    async def fake(symbol): return {"symbol":symbol, "best_bid":{"price":100,"qty":1},"best_ask":{"price":101,"qty":1},"bids":[[100,1]],"asks":[[101,1]]}
    monkeypatch.setattr(ex, "fetch_orderbook", fake)
    ob = await ex.fetch_orderbook("BTC/USDT")
    assert ob["best_bid"]["price"] == 100 and ob["best_ask"]["price"] == 101
