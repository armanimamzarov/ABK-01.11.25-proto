import pytest
@pytest.mark.parametrize("symbol", ["BTC/USDT","ETH/USDT"])
def test_orderbook_schema(symbol):
    # placeholder for contract tests via mocks
    assert True
