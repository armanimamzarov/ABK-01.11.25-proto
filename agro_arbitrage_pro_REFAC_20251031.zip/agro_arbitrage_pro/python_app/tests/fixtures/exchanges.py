import asyncio
class MockEx:
    def __init__(self,name,px=100.0): self.name=name; self.px=px
    async def fetch_ticker(self,symbol): return {"last": self.px}
    async def create_order(self,symbol,side,amount,price,typ,params):
        await asyncio.sleep(0); return {"id": f"{self.name}-1", "filled": amount, "price": price}
