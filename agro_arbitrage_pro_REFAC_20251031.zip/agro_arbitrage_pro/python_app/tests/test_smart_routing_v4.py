import pytest
from core.smart_routing_v4 import choose_venues, split_notional

def test_choose_venues():
    venues=choose_venues({"a":10,"b":5,"c":1},{"a":1,"b":10,"c":0},2)
    assert venues[0]=="a"

def test_split_notional():
    plan=split_notional(1000,["a","b"],{"a":2,"b":1})
    assert abs(plan["a"]-666.6)<2
