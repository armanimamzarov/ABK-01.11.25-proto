from python_app.backtest_engine import backtest
import os

def test_backtest(tmp_path):
    src = os.path.join("sample_data", "orderbooks.csv")
    backtest(src, speed=100.0, report_dir=tmp_path.as_posix())
    files = list(tmp_path.glob("*.csv"))
    assert len(files) == 1