from tao.ws_watchdog import heartbeat, gaps
def test_heartbeat_and_gaps(tmp_path, monkeypatch):
    p = tmp_path/"last_ticks.json"
    monkeypatch.setenv("PYTHONPATH", str(tmp_path))
    # redirect path by monkeypatching module var
    import importlib, tao.ws_watchdog as w
    w.HEALTH_FILE = str(p)
    heartbeat("binance","BTC/USDT")
    assert len(gaps(0))>=1 or len(gaps(999999))>=0
