from core.smart_routing import split_by_depth

def test_split_by_depth():
    books = [
        ("binance", {"bids":[[101,0.2],[100,0.5]], "asks":[[102,0.3],[103,0.5]]}),
        ("bybit", {"bids":[[100.5,0.4]], "asks":[[101.8,0.3]]}),
    ]
    plan = split_by_depth("buy", 0.5, books)
    assert sum(a for _,_,a in plan) >= 0.5
