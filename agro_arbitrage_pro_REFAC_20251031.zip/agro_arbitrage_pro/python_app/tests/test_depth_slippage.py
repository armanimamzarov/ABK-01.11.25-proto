import pytest
from risk_management.depth_slippage import vwap_price, est_slippage_pct

def test_vwap_price():
    levels = [(100, 0.5), (101, 0.5), (102, 1.0)]
    px = vwap_price(levels, 0.6)  # 0.5@100 + 0.1@101 = (50 + 10.1)/0.6
    assert abs(px - ((50 + 10.1)/0.6)) < 1e-6

def test_slippage_buy():
    s = est_slippage_pct("buy", 100, 101)
    assert s == 1.0
