
def test_contract_shape():
    sample = {"symbol":"BTC/USDT","side":"buy","amount":0.01,"filled":0.01,"price":60000,"status":"closed"}
    assert set(sample.keys()) >= {"symbol","side","amount","filled","price","status"}
