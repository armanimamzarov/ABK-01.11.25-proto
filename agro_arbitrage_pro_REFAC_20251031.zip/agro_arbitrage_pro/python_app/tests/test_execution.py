import pytest
import asyncio
from core.execution_coordinator import ExecutionCoordinator

@pytest.mark.asyncio
async def test_two_leg_execution():
    exec = ExecutionCoordinator({}, None, None, None, grpc_client=None)
    meta = {"strategy":"test","expected_profit_pct":0.1}
    res = await exec.atomic_two_leg({"side":"buy","price":100,"amount":1,"symbol":"BTC/USDT","exchange":"binance","type":"limit"},
                                    {"side":"sell","price":101,"amount":1,"symbol":"BTC/USDT","exchange":"bybit","type":"limit"},
                                    meta)
    assert res["success"] is True
