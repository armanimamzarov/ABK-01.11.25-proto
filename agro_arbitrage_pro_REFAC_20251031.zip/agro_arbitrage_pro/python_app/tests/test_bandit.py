from ml.bandits import UCBBandit
def test_ucb_select_and_update(tmp_path, monkeypatch):
    b = UCBBandit(["a","b","c"], state_file=str(tmp_path/"state.json"))
    arm, score = b.select(1)
    assert arm in {"a","b","c"}
    b.update(arm, 1.0)
    arm2, score2 = b.select(2)
    assert arm2 in {"a","b","c"}
