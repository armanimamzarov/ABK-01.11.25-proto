from core.order_validator import OrderValidator

def test_round_and_validate():
    v = OrderValidator({"binance": {"price_step": 0.1, "amount_step": 0.001, "min_notional_usd": 10}})
    adj = v.adjust("binance", 100.06, 0.00094)
    assert abs(adj["price"] - 100.1) < 1e-9
    assert abs(adj["amount"] - 0.001) < 1e-9
    assert v.validate("binance", "BTC/USDT", adj["price"], adj["amount"]) is True
