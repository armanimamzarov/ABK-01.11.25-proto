from prometheus_client import start_http_server, Counter, Histogram

arb_profit_total = Counter("arb_profit_total", "Total arbitrage profit", ["exchange","pair","strategy","leg"])
order_latency_ms = Histogram("order_latency_ms", "Order latency (ms)", ["exchange","pair","strategy","leg"])
order_reject_count = Counter("order_reject_count", "Order rejects", ["exchange","pair","strategy","leg"])

def serve(port: int = 9101):
    start_http_server(port)