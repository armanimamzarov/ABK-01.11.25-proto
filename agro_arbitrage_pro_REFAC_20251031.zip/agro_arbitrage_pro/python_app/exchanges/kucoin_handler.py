from .ccxt_compat import ccxtpro as ccxt
import os
from typing import Any, Dict
import ccxt.async_support as ccxt
try:
    import ccxt.pro as ccxtpro
except Exception:
    ccxtpro = None

from .base_exchange import BaseExchange

USE_WS = os.getenv("USE_WS","false").lower()=="true"

class KucoinHandler(BaseExchange):
    def __init__(self, api_key: str=None, secret: str=None, password: str=None, testnet: bool=False):
        self.ex = ccxt.kucoin()
        if api_key:
            self.ex.apiKey = api_key
            self.ex.secret = secret or ""
        if password and hasattr(self.ex, 'password'):
            self.ex.password = password
        if testnet and hasattr(self.ex, 'set_sandbox_mode'):
            try: self.ex.set_sandbox_mode(True)
            except Exception: pass
        self.ws = None
        if USE_WS and ccxtpro is not None and hasattr(ccxtpro, 'kucoin'):
            self.ws = getattr(ccxtpro, 'kucoin')()

    def _normalize_ob(self, symbol: str, ob: Dict[str, Any]) -> Dict[str, Any]:
        bids = ob.get('bids') or []
        asks = ob.get('asks') or []
        best_bid = bids[0] if bids else [None, None]
        best_ask = asks[0] if asks else [None, None]
        # Keep top 20 levels for depth-based VWAP/slippage calculation
        bids20 = bids[:20]
        asks20 = asks[:20]
        return {"symbol": symbol, "best_bid": {"price": best_bid[0], "qty": best_bid[1]}, "best_ask": {"price": best_ask[0], "qty": best_ask[1]}, "bids": bids20, "asks": asks20}

    async def fetch_orderbook(self, symbol: str) -> Dict[str, Any]:
        ob = await self.ex.fetch_order_book(symbol, limit=50)
        return self._normalize_ob(symbol, ob)

    async def watch_orderbook(self, symbol: str) -> Dict[str, Any]:
        if self.ws is None:
            return await self.fetch_orderbook(symbol)
        ob = await self.ws.watch_order_book(symbol, limit=50)
        return self._normalize_ob(symbol, ob)

    async def create_order(self, symbol: str, side: str, amount: float, price: float=None, type_: str="limit", params: Dict[str, Any]=None) -> Dict[str, Any]:
        params = params or {}
        order = await self.ex.create_order(symbol, type_, side, amount, price, params)
        return order

    async def balance(self) -> Dict[str, float]:
        bal = await self.ex.fetch_balance()
        return {k: v.get('free', 0) for k, v in bal.get('total',{}).items()}

    async def snapshot_orderbook(self, sym, limit=100):
        ob = await self.fetch_orderbook(sym, limit=limit)
        return ob

    def apply_diff(self, book, diff):
        if not book: return diff
        levels = 50
        by_side = {"bids": {}, "asks": {}}
        for side in ("bids","asks"):
            for px,qty in book.get(side,[])[:levels]:
                by_side[side][float(px)] = float(qty)
            for px,qty in diff.get(side,[]):
                if float(qty) <= 0.0:
                    by_side[side].pop(float(px), None)
                else:
                    by_side[side][float(px)] = float(qty)
            if side == "bids":
                book[side] = sorted([[p,q] for p,q in by_side[side].items()], key=lambda x: -x[0])[:levels]
            else:
                book[side] = sorted([[p,q] for p,q in by_side[side].items()], key=lambda x: x[0])[:levels]
        if book.get("bids"):
            book["best_bid"]={"price":book["bids"][0][0], "qty":book["bids"][0][1]}
        if book.get("asks"):
            book["best_ask"]={"price":book["asks"][0][0], "qty":book["asks"][0][1]}
        return book

    async def watch_orderbook_snapshot_diff(self, sym):
        try:
            if not hasattr(self, "ws") or not self.ws:
                return await self.fetch_orderbook(sym)
            snap = await self.snapshot_orderbook(sym, limit=100)
            for _ in range(100):
                d = await self.ws.watch_order_book(sym, limit=10)
                diff = {"bids": d.get("bids",[]), "asks": d.get("asks",[])}
                snap = self.apply_diff(snap, diff)
            return self._norm(sym, snap)
        except Exception:
            try:
                await self._recreate_ws()
            except Exception:
                pass
            return await self.fetch_orderbook(sym)
