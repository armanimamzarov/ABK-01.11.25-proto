PARAMS_MAP = {
  "binance": {
    "postOnly": "postOnly",
    "timeInForce": "timeInForce",
    "reduceOnly": "reduceOnly",
    "cancelOnDisconnect": "cancelOnDisconnect",
    "defaultType": "spot"
  },
  "bybit": {
    "postOnly": "postOnly",
    "timeInForce": "timeInForce",
    "reduceOnly": "reduceOnly",
    "cancelOnDisconnect": "closeOnTrigger",
    "defaultType": "linear"
  },
  "okx": {
    "postOnly": "postOnly",
    "timeInForce": "tdMode",
    "reduceOnly": "reduceOnly",
    "cancelOnDisconnect": "attachAlgoClOrdId",
    "defaultType": "swap"
  },
  "kucoin": {
    "postOnly": "postOnly",
    "timeInForce": "timeInForce",
    "reduceOnly": "reduceOnly",
    "defaultType": "spot"
  },
  "gate": {
    "postOnly": "postOnly",
    "timeInForce": "timeInForce",
    "reduceOnly": "reduceOnly",
    "defaultType": "spot"
  },
  "mexc": {
    "postOnly": "postOnly",
    "timeInForce": "timeInForce",
    "reduceOnly": "reduceOnly",
    "defaultType": "spot"
  },
  "bingx": {
    "postOnly": "postOnly",
    "timeInForce": "timeInForce",
    "reduceOnly": "reduceOnly",
    "defaultType": "spot"
  },
  "bitget": {
    "postOnly": "postOnly",
    "timeInForce": "timeInForce",
    "reduceOnly": "reduceOnly",
    "defaultType": "swap"
  }
}