from abc import ABC, abstractmethod
from typing import Any, Dict

class BaseExchange(ABC):
    @abstractmethod
    async def fetch_orderbook(self, symbol: str) -> Dict[str, Any]:
        ...
    @abstractmethod
    async def watch_orderbook(self, symbol: str) -> Dict[str, Any]:
        ...
    @abstractmethod
    async def create_order(self, symbol: str, side: str, amount: float, price: float=None, type_: str="limit", params: Dict[str, Any]=None) -> Dict[str, Any]:
        ...
    @abstractmethod
    async def balance(self) -> Dict[str, float]:
        ...
