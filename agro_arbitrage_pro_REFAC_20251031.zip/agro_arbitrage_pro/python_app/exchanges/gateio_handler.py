import os
from typing import Any, Dict
import ccxt.async_support as ccxt
try:
    import ccxt.pro as ccxtpro
except Exception:
    ccxtpro = None

from .base_exchange import BaseExchange

USE_WS = os.getenv("USE_WS","false").lower()=="true"

class GateioHandler(BaseExchange):
    def __init__(self, api_key: str=None, secret: str=None, password: str=None, testnet: bool=False):
        self.ex = ccxt.gateio()
        if api_key:
            self.ex.apiKey = api_key
            self.ex.secret = secret or ""
        if password and hasattr(self.ex, 'password'):
            self.ex.password = password
        if testnet and hasattr(self.ex, 'set_sandbox_mode'):
            try: self.ex.set_sandbox_mode(True)
            except Exception: pass
        self.ws = None
        if USE_WS and ccxtpro is not None and hasattr(ccxtpro, 'gateio'):
            self.ws = getattr(ccxtpro, 'gateio')()

    def _normalize_ob(self, symbol: str, ob: Dict[str, Any]) -> Dict[str, Any]:
        bids = ob.get('bids') or []
        asks = ob.get('asks') or []
        bb = bids[0] if bids else [None, None]
        ba = asks[0] if asks else [None, None]
        return {"symbol": symbol,
                 "best_bid": {"price": bb[0], "qty": bb[1]},
                 "best_ask": {"price": ba[0], "qty": ba[1]},
                 "bids": bids[:20], "asks": asks[:20]}

    async def fetch_orderbook(self, symbol: str) -> Dict[str, Any]:
        ob = await self.ex.fetch_order_book(symbol, limit=50)
        return self._normalize_ob(symbol, ob)

    async def watch_orderbook(self, symbol: str) -> Dict[str, Any]:
        if self.ws is None:
            return await self.fetch_orderbook(symbol)
        ob = await self.ws.watch_order_book(symbol, limit=50)
        return self._normalize_ob(symbol, ob)

    async def create_order(self, symbol: str, side: str, amount: float, price: float=None, type_: str="limit", params: Dict[str, Any]=None) -> Dict[str, Any]:
        params = params or {}
        order = await self.ex.create_order(symbol, type_, side, amount, price, params)
        return order

    async def balance(self) -> Dict[str, float]:
        bal = await self.ex.fetch_balance()
        return {k: v.get('free', 0) for k, v in bal.get('total',{}).items()}
