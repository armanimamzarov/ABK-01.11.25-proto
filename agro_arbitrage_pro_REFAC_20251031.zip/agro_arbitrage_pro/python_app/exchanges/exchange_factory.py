from .binance_handler import BinanceHandler
from .bybit_handler import BybitHandler
from .okx_handler import OkxHandler
from .kucoin_handler import KucoinHandler
from .gateio_handler import GateioHandler
from .mexc_handler import MexcHandler
from .bingx_handler import BingxHandler

def create_exchange(name: str, api_key: str=None, secret: str=None, password: str=None, testnet: bool=False):
    name = (name or "").lower()
    if name == "binance": return BinanceHandler(api_key, secret, password, testnet)
    if name == "bybit": return BybitHandler(api_key, secret, password, testnet)
    if name == "okx": return OkxHandler(api_key, secret, password, testnet)
    if name == "kucoin": return KucoinHandler(api_key, secret, password, testnet)
    if name == "gateio": return GateioHandler(api_key, secret, password, testnet)
    if name == "mexc": return MexcHandler(api_key, secret, password, testnet)
    if name == "bingx": return BingxHandler(api_key, secret, password, testnet)
    raise ValueError(f"Unknown exchange: {name}")
