"""CCXT WebSocket compat: ccxt.pro is merged into ccxt 1.95+.
Use: from exchanges.ccxt_compat import ccxtpro
"""
try:
    import ccxt.pro as ccxtpro
except Exception:  # fallback to REST-only ccxt (no watch_* methods)
    import ccxt as ccxtpro  # type: ignore
ccxt = ccxtpro  # alias for convenience
