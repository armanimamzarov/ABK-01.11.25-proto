import asyncio, random, time
from utils.logger import setup_logger
log = setup_logger(__name__)

async def resilient_ws(connect_coro, on_msg, heartbeat_sec=5.0):
    backoff = 0.1
    while True:
        try:
            ws = await connect_coro()
            last = time.time()
            async for msg in ws:
                await on_msg(msg); last = time.time()
                if (time.time()-last) > heartbeat_sec: await ws.ping()
        except Exception as e:
            log.warning("ws reconnect: %s", e)
            await asyncio.sleep(backoff + random.uniform(0, backoff))
            backoff = min(backoff*2, 5.0)
