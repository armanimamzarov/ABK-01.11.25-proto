import time
class TokenBucket:
    def __init__(self, rps: float, burst: int):
        self.rate = rps; self.capacity = burst; self.tokens = burst; self.ts = time.time()
    def allow(self) -> bool:
        now = time.time(); delta = now - self.ts; self.ts = now
        self.tokens = min(self.capacity, self.tokens + delta * self.rate)
        if self.tokens >= 1.0: self.tokens -= 1.0; return True
        return False
