import argparse, time, tomllib, os
from .logging_setup import setup
from .metrics import serve
import logging
logger = logging.getLogger(__name__)

def main(paper: bool):
    setup()
    serve()
    cfg_path = os.path.join("configs", "strategy_config.toml")
    with open(cfg_path, "rb") as f:
        cfg = tomllib.load(f)
    mode = cfg.get("global", {}).get("execution_mode", "paper")
logger.info(f"Live starting in mode={mode}, paper_flag={paper}")
    # TODO: подключение к биржам, запуск стратегий, hot-reload на изменение файла
    while True:
        time.sleep(1.0)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--paper", default=True, type=bool)
    args = ap.parse_args()
    main(args.paper)