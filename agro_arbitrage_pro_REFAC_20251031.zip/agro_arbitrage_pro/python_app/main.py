import asyncio, os, signal, sys, uvicorn
from rich.console import Console
from rich.panel import Panel
from dotenv import load_dotenv
from utils.logger import setup_logger
from core.arbitrage_engine import ArbitrageEngine
from config.config_loader import load_all
from core.portfolio_allocator import PortfolioAllocator
from exchanges.exchange_factory import create as create_exchange
from api.grpc_client import GrpcClient
from core.market_monitor import MarketMonitor
from core.opportunity_scanner import OpportunityScanner
from strategies.triangular_arb import TriangularArbitrage
from strategies.cash_and_carry import CashAndCarry
from strategies.spot_arbitrage import SpotArbitrage
from strategies.spread_scalping import SpreadScalping
from strategies.cross_exchange_arb import CrossExchangeArb
from strategies.synthetic_arb import SyntheticArb
from strategies.stable_spread_arb import StableSpreadArb
from strategies.volatility_rebalance import VolatilityRebalance
import logging
logger = logging.getLogger(__name__)
from analytics.opportunity_analyzer import MLFilter
from core.strategy_state import StrategyState
from database.arbitrage_repository import ArbitrageRepository
from core.execution_coordinator import ExecutionCoordinator
from api.server import app as fastapi_app, _state_ref

console = Console()
logger = setup_logger("main")
load_dotenv()

class Application:
    def __init__(self):
        self.grpc_client = None
        self.monitor = None
        self.scanner = None
        self.ml = MLFilter()
        self.repo = ArbitrageRepository(os.getenv("POSTGRES_URL","sqlite+aiosqlite:///agro.db"))
        self.strategies = [
            TriangularArbitrage({"min_profit_percentage":0.08}),
            CashAndCarry({"min_profit_percentage":0.10}),
            SpotArbitrage({"min_profit_percentage":0.05}),
            SpreadScalping({"min_profit_percentage":0.03}),
            CrossExchangeArb({"min_profit_percentage":0.09}),
            SyntheticArb({"min_profit_percentage":0.07}),
            StableSpreadArb({"min_profit_percentage":0.02}),
            VolatilityRebalance({"min_profit_percentage":0.06}),
        ]
        self.exec = None
        self.running = True

    async def initialize(self):
        console.print(Panel.fit("🚀 [bold green]Agro Arbitrage Pro v2.0[/bold green]", border_style="green"))
        await self.repo.init()
        use_grpc = os.getenv("USE_GRPC","true").lower()=="true"
        if use_grpc:
            port = int(os.getenv("RUST_GRPC_PORT","50051"))
            self.grpc_client = GrpcClient(f"localhost:{port}")
            await self.grpc_client.connect()
        cfg = load_all(os.getcwd())
        # Build exchanges from config + env keys
        connectors = {}
        for ex in cfg['exchanges']['exchanges']:
            if not ex.get('enabled'): continue
            name = ex['name']
            keys = cfg['exchanges']['keys_env'].get(name, {})
            api_key = os.getenv(keys.get('key',''))
            secret = os.getenv(keys.get('secret',''))
            password = os.getenv(keys.get('password',''))
            connectors[name] = create_exchange(name, api_key=api_key, secret=secret, password=password, testnet=ex.get('testnet', False))
        self.monitor = MarketMonitor(connectors=connectors, symbols=ex['symbols'] if connectors else None)
        await self.monitor.start()
        self.scanner = OpportunityScanner(self.strategies)
        self.state = StrategyState(self.strategies)
        _state_ref['state']=self.state
        categories = {s['name']: s.get('category','aggressive') for s in cfg['strategies']['strategies']}
        allocator = PortfolioAllocator(connectors, cfg['system']['allocation'], categories, perf_repo=None)
        self.exec = ExecutionCoordinator({}, None, self.repo, None, grpc_client=self.grpc_client)

    async def strategy_loop(self):
        while self.running:
            snapshot = self.monitor.get_snapshot()
            opps = await self.scanner.scan(snapshot)
            for opp in opps[:3]:
                if not self.state.is_enabled(opp['strategy']):
                    continue
                if self.ml.predict_ok(opp):
                    meta = {"strategy": opp["strategy"], "expected_profit_pct": opp["expected_profit_pct"], "confidence": opp.get("confidence",0.5)}
                    legs = opp["legs"]
                    if len(legs)==2:
                        res = await self.exec.atomic_two_leg(legs[0], legs[1], meta)
                        self.state.add_pnl(opp['strategy'], float(res.get('pnl_pct',0)))
                    elif len(legs)==3:
                        res = await self.exec.atomic_three_leg(legs[0], legs[1], legs[2], meta)
                        self.state.add_pnl(opp['strategy'], float(res.get('pnl_pct',0)))
            await asyncio.sleep(0.5)

async def main():
    app = Application()
    await app.initialize()
    # Run FastAPI as background task
    port = int(os.getenv("PYTHON_REST_PORT","8000"))
    config = uvicorn.Config("api.server:app", host="0.0.0.0", port=port, log_level="info")
    server = uvicorn.Server(config)
    api_task = asyncio.create_task(server.serve())
    strat_task = asyncio.create_task(app.strategy_loop())
    await asyncio.gather(api_task, strat_task)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)