def normalize(symbol: str) -> str:
    return symbol.upper().replace('-', '/')
