def round_to_step(value: float, step: float) -> float:
    if step <= 0: return value
    return round(round(value / step) * step, 12)

def notional(price: float, amount: float) -> float:
    return (price or 0) * (amount or 0)
