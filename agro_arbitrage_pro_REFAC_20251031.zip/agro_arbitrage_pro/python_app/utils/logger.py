import logging, json, re, os
from rich.logging import RichHandler

SENSITIVE_PATTERNS = [re.compile(r"(api|secret|key|token|password)\s*[:=]\s*([A-Za-z0-9_\-]{6,})", re.I)]

class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        msg = str(record.getMessage())
        for pat in SENSITIVE_PATTERNS:
            msg = pat.sub(lambda m: f"{m.group(1)}:***REDACTED***", msg)
        record.msg = msg
        return True

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {"timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),"level": record.levelname,"service": os.environ.get("SERVICE_NAME","python_app"),"logger": record.name,"message": record.getMessage(), "strategy": getattr(record, "strategy", None), "pair": getattr(record, "pair", None)}
        if hasattr(record, "correlation_id"): payload["correlation_id"]=getattr(record,"correlation_id")
        return json.dumps(payload, ensure_ascii=False)

def setup_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers: return logger
    logger.setLevel(level)
    ch = RichHandler(rich_tracebacks=True, show_time=True, show_path=False)
    ch.setFormatter(JsonFormatter()); ch.addFilter(RedactingFilter())
    logger.addHandler(ch); return logger
