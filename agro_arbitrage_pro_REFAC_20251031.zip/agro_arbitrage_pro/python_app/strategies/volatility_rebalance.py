from .base_arbitrage import BaseArbitrage
from ml.bandits import get_global as get_bandit
from analytics.metrics import c_signals

class VolatilityRebalance(BaseArbitrage):
    name="volatility_rebalance"
    async def analyze_market(self, ctx):
        syms = ["BTC/USDT","ETH/USDT","SOL/USDT"]
        spreads = []
        for s in syms:
            try:
                ob = await self.mm.orderbook(s)
                if not ob: continue
                bb = ob['best_bid']['price']; ba = ob['best_ask']['price']
                if bb and ba:
                    spreads.append((ba-bb)/ba*100)
            except Exception:
                pass
        sigma = sum(spreads)/len(spreads) if spreads else 0.0
        b = get_bandit()
        if b:
            reward = max(0.0, sigma-0.05)
            b.update("spot_arbitrage", reward*0.5)
            b.update("cross_exchange_arb", reward*0.5)
        return {"sigma": sigma}
    async def execute_signal(self, signal):
        c_signals.labels(strategy=self.name).inc()
        return {"ok": True, "sigma": signal.get("sigma",0.0)}
