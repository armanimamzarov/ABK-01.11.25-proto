from analytics.metrics import c_signals

from typing import List, Dict, Any
from .base_arbitrage import BaseArbitrage

class StableSpreadArb(BaseArbitrage):
    name = "StableSpreadArb"

    async def scan(self, market: Dict[str, Any]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        books = market.get("orderbooks", {})
        for key, book in books.items():
            bid = book.get("best_bid")
            ask = book.get("best_ask")
            if bid and ask and ask['price']:
                spread = (bid['price'] - ask['price']) / ask['price'] * 100
                if spread >= self.config.get("min_profit_percentage", 0.05):
                    legs = [
                        {"exchange":"binance","symbol":book['symbol'],"side":"buy","amount":0.01,"price":ask['price'],"type":"limit"},
                        {"exchange":"bybit","symbol":book['symbol'],"side":"sell","amount":0.01,"price":bid['price'],"type":"limit"}
                    ]

                    out.append({"strategy": self.name, "legs": legs, "expected_profit_pct": spread, "confidence": 0.6})
        return out

    async def build(self, opp: Dict[str, Any]) -> Dict[str, Any]:
        c_signals.labels(strategy=self.name).inc(); return {"plan": {"strategy": self.name, "legs": opp["legs"]}, "meta": {"expected_profit_pct": opp["expected_profit_pct"], "ml_approved": True}}
