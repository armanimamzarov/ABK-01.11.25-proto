from abc import ABC, abstractmethod
import time
from analytics.metrics import h_exec, c_fills, g_fee_spike
from utils.logger import setup_logger
log = setup_logger(__name__)

class BaseArbitrage(ABC):
    name = "base"
    @abstractmethod
    async def step(self, coordinator): ...

    async def _record_exec(self, path: str, latency_ms: int, pnl_pct: float, fee_bps: float, exchange: str):
        try:
            h_exec.labels(path=path).observe(latency_ms/1000.0)
            c_fills.labels(strategy=self.name).inc()
            g_fee_spike.labels(exchange=exchange).set(fee_bps)
        except Exception:
            pass
        log.info("exec", extra={"strategy": self.name, "pair": path})
