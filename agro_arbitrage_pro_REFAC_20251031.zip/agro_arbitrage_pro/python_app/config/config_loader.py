import os, json
from pathlib import Path
from typing import Dict, Any

def deep_update(dst, src):
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            deep_update(dst[k], v)
        else:
            dst[k] = v
    return dst

def load_json(path: str) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))

def load_all(base: str) -> Dict[str, Any]:
    cfg = {}
    cfg["system"] = load_json(f"{base}/configs/system.json")["system"]
    cfg["exchanges"] = load_json(f"{base}/configs/exchanges.json")
    cfg["strategies"] = load_json(f"{base}/configs/arbitrage_strategies.json")
    cfg["risk"] = load_json(f"{base}/configs/risk_management.json")
    cfg["tg"] = load_json(f"{base}/configs/telegram.json")
    # Optional global overrides
    gpath = Path(f"{base}/configs/global_config.json")
    if gpath.exists():
        overrides = load_json(str(gpath))
        cfg = deep_update(cfg, overrides)
    return cfg