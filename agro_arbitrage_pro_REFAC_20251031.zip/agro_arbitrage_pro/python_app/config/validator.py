def validate_exchanges(cfg):
    assert "exchanges" in cfg and isinstance(cfg["exchanges"], list)
    for ex in cfg["exchanges"]:
        assert "name" in ex and "enabled" in ex
