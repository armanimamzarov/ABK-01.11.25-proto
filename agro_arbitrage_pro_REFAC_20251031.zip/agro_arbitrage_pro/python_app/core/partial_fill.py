from utils.logger import setup_logger
log = setup_logger(__name__)
def adjust_params_by_volatility(params: dict, sigma: float):
    p = dict(params or {})
    if sigma > 2.0:
        p["aggressiveness"] = "high"
    else:
        p["aggressiveness"] = "normal"
    return p
