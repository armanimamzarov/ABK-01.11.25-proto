from typing import List, Dict, Any, Tuple
from utils.logger import setup_logger
from risk_management.depth_slippage import vwap_price
logger = setup_logger(__name__)

def last_look_ok(book: Dict[str, Any], side: str, price: float) -> bool:
    # basic last look reject if spread widens unexpectedly
    bb = book.get("best_bid",{}).get("price")
    ba = book.get("best_ask",{}).get("price")
    if not bb or not ba: return False
    if side=='buy' and price > ba*1.002: return False
    if side=='sell' and price < bb*0.998: return False
    return True

def dynamic_vwap_target(book: Dict[str, Any], side: str, amount: float, max_slip_pct: float) -> float:
    levels = book.get('asks') if side=='buy' else book.get('bids')
    if not levels: return 0.0
    best = book['best_ask']['price'] if side=='buy' else book['best_bid']['price']
    vwap = vwap_price(levels, amount)
    # cap target by slip
    limit = best * (1 + max_slip_pct/100.0) if side=='buy' else best * (1 - max_slip_pct/100.0)
    return min(vwap, limit) if side=='buy' else max(vwap, limit)
