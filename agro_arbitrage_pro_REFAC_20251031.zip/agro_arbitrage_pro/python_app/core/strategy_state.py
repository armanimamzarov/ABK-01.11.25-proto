from typing import Dict, Any
from collections import defaultdict

class StrategyState:
    def __init__(self, strategies):
        self.enabled: Dict[str, bool] = {s.name: True for s in strategies}
        self.pnl: Dict[str, float] = defaultdict(float)

    def enable(self, name: str):
        self.enabled[name] = True

    def disable(self, name: str):
        self.enabled[name] = False

    def is_enabled(self, name: str) -> bool:
        return self.enabled.get(name, False)

    def add_pnl(self, name: str, v: float):
        self.pnl[name] += v

    def report(self) -> Dict[str, Any]:
        return {"enabled": dict(self.enabled), "pnl": dict(self.pnl)}
