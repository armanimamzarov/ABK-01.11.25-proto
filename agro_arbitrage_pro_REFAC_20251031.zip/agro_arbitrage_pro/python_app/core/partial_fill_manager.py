from typing import Dict, Any
from utils.logger import setup_logger
log = setup_logger(__name__)

def vwap_target(book) -> float:
    """Estimate a simple VWAP target from top-3 levels."""
    if not book: return 0.0
    bids = book.get('bids',[])[:3]; asks = book.get('asks',[])[:3]
    if not bids or not asks: return 0.0
    # for a buy, use asks; for a sell, use bids; here return mid-vwap proxy
    import math
    def _vwap(levels):
        tot=0.0; notional=0.0
        for px,qty in levels:
            tot += qty; notional += px*qty
        return (notional/tot) if tot else 0.0
    return (_vwap(bids)+_vwap(asks))/2.0

async def retry_remaining(executor, leg: Dict[str, Any], remaining: float, max_retries: int = 2):
    q = remaining
    for i in range(max_retries):
        l2 = dict(leg)
        l2['amount'] = q
        l2['time_in_force'] = "IOC"
        # become slightly more aggressive by allowing market order if price not set
        if not l2.get('price'):
            l2['type'] = 'market'
        r = await executor.submit_order(l2)
        if not r: break
        filled = float(r.get("filled",0.0))
        if filled >= q*0.99:  # mostly done
            break
        q = max(0.0, q - filled)
    return True
