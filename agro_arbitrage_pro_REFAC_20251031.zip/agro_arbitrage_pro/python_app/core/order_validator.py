from typing import Dict, Any
from utils.math_helpers import round_to_step, notional

class OrderValidator:
    def __init__(self, exch_presets: Dict[str, Any]):
        self.presets = exch_presets  # name -> {price_step, amount_step, min_notional_usd}

    def adjust(self, exchange: str, price: float, amount: float) -> Dict[str, float]:
        p = self.presets.get(exchange, {})
        price_step = float(p.get("price_step", 0))
        amount_step = float(p.get("amount_step", 0))
        price = round_to_step(price, price_step) if price else price
        amount = round_to_step(amount, amount_step) if amount else amount
        return {"price": price, "amount": amount}

    def validate(self, exchange: str, symbol: str, price: float, amount: float) -> bool:
        p = self.presets.get(exchange, {})
        min_notional = float(p.get("min_notional_usd", 0))
        return notional(price, amount) >= min_notional if min_notional > 0 else True
