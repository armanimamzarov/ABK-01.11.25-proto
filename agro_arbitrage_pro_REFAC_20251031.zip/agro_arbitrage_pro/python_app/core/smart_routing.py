
import time
from typing import List, Dict, Any
from utils.logger import setup_logger
log = setup_logger(__name__)

def last_look(spread_now: float, spread_prev: float, threshold_pct: float = 0.03) -> bool:
    return (spread_now >= (1.0 - threshold_pct) * spread_prev)

def split_order(notional_usd: float, venues: List[str]) -> Dict[str, float]:
    if not venues: return {}
    w = 1.0/len(venues)
    return {v: notional_usd*w for v in venues}

async def route(executors: Dict[str, Any], symbol: str, side: str, target_usd: float, px_hint: float = None):
    venues = list(executors.keys())[:3]
    plan = split_order(target_usd, venues)
    fills = []
    for v, usd in plan.items():
        ex = executors[v]
        amt = (usd/px_hint) if px_hint else None
        try:
            fills.append(await ex.create_order(symbol, side, amt, px_hint, "limit", {"timeInForce":"IOC"}))
        except Exception as e:
            log.warning("route: %s failed: %s", v, e)
    return fills
