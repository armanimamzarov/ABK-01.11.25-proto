from typing import Dict, Any, List
from core.balance_store import BalanceStore
from ml.performance_predictor import expected_return
from ml.signal_classifier import classify
from core.partial_fill import adjust_params_by_volatility
from core.partial_fill_manager import retry_remaining, vwap_target
from analytics.metrics import c_fills
from ml.bandits import get_global as get_bandit

class ExecutionCoordinator:
    def __init__(self, exchanges, risk_engine=None, allocator=None):
        self.exchanges=exchanges; self.risk=risk_engine; self.alloc=allocator; self.balance=BalanceStore()

    async def submit_order(self, leg: Dict[str, Any]) -> Dict[str, Any]:
        ex = self.exchanges.get(leg.get("exchange")) or next(iter(self.exchanges.values()))
        typ = leg.get("type") or ("limit" if leg.get("price") else "market")
        params = leg.get("params") or {}
        tif = leg.get("time_in_force")
        if tif: params["timeInForce"] = tif
        if leg.get("post_only"): params["postOnly"] = True
        if leg.get("reduce_only"): params["reduceOnly"] = True
        if leg.get("cancel_on_disconnect"): params["cancelOnDisconnect"] = True
        return await ex.create_order(leg.get("symbol","BTC/USDT"), leg.get("side","buy"), float(leg.get("amount",0.0)), leg.get("price"), typ, params)

    async def _size(self, legs: List[Dict[str, Any]], target_usd: float):
        ref_px = legs[0].get("price") or 0.0; amt = (target_usd/ref_px) if ref_px else 0.0
        for l in legs: l["amount"]=amt
        return legs

    async def atomic_two_leg(self, legs: List[Dict[str, Any]], meta: Dict[str, Any]):
        er = expected_return(meta.get('expected_profit_pct',0.0), fees_pct=0.08, slip_pct=0.05)
        decision, conf = classify(er, spread=0.05)
        if decision == 'hold': return {'success': False, 'reason': 'ml_reject', 'confidence': conf}

        sigma = meta.get("sigma", 1.0)
        for leg in legs:
            leg["params"] = adjust_params_by_volatility(leg.get("params"), sigma)

        legs = await self._size(legs, meta.get("target_usd",5.0))
        res=[]; notional=0.0
        for idx,l in enumerate(legs):
            if l.get("price") and l.get("amount"): notional+=float(l["price"])*float(l["amount"])
            if "time_in_force" not in l:
                l["time_in_force"] = "IOC" if idx==0 else "FOK"
            r = await self.submit_order(l)
            # VWAP hint (not enforced)
            _ = vwap_target(meta.get('book'))
            # partial fill hook (very simplified)
            if r and isinstance(r, dict) and r.get("status") in {"partial","partially_filled"}:
                remaining = float(l["amount"]) - float(r.get("filled",0.0))
                if remaining > 0:
                    await retry_remaining(self, l, remaining)
            res.append(r)

        pnl_usd = er/100.0 * max(0.0, notional)
        self.balance.apply_trade(pnl_usd, notional)
        if self.risk: self.risk.on_fill(pnl_usd)
        # metrics & bandit update
        strat = meta.get("strategy","unknown")
        try: c_fills.labels(strategy=strat).inc()
        except Exception: pass
        b = get_bandit()
        if b:
            reward = pnl_usd
            b.update(strat, reward)
        return {"success": True, "fills": res, "pnl_pct": er, "notional": notional, "confidence": conf}
