import asyncio, os, signal
from utils.logger import setup_logger
log = setup_logger(__name__)

class ArbitrageEngine:
    """Async arbitrage engine with graceful restart/stop."""
    def __init__(self, coordinator, strategies):
        self.coordinator = coordinator
        self.strategies = strategies
        self._stop = asyncio.Event()
        self._restart = asyncio.Event()

    async def run(self):
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGTERM, self.stop)
        loop.add_signal_handler(signal.SIGHUP, self.restart)
        log.info("engine: started")
        while not self._stop.is_set():
            if self._restart.is_set():
                log.info("engine: restarting..."); self._restart.clear()
            # iterate strategies
            tasks = [s.step(self.coordinator) for s in self.strategies]
            try:
                await asyncio.gather(*tasks, return_exceptions=False)
            except Exception as e:
                log.exception("engine: strategy error: %s", e)
                await asyncio.sleep(0.1)
        log.info("engine: stopped")

    def stop(self): self._stop.set()
    def restart(self): self._restart.set()
