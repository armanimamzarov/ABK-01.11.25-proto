import json
from pathlib import Path
class BalanceStore:
    def __init__(self, path: str = "configs/balance.json"):
        self.path=path; Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        if not Path(self.path).exists(): Path(self.path).write_text(json.dumps({"available_balance":100.0,"used_margin":0.0,"profit_today":0.0}, indent=2), encoding="utf-8")
    def load(self): import json; from pathlib import Path; return json.loads(Path(self.path).read_text(encoding="utf-8"))
    def save(self, data): from pathlib import Path, json as js; Path(self.path).write_text(js.dumps(data, indent=2), encoding="utf-8")
    def apply_trade(self, pnl_usd: float, notional: float):
        d=self.load(); d["profit_today"]=d.get("profit_today",0.0)+pnl_usd; self.save(d)
