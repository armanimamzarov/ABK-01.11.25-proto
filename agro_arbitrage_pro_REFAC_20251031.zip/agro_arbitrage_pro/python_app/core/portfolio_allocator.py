import asyncio, os
from typing import Dict, Any, List, Tuple
from utils.logger import setup_logger

logger = setup_logger(__name__)

class PortfolioAllocator:
    def __init__(self, connectors: Dict[str, Any], allocation_cfg: Dict[str, float], categories: Dict[str, str], perf_repo=None):
        self.exchanges = connectors
        self.allocation_cfg = allocation_cfg or {"stable":0.2, "aggressive":0.8}
        self.categories = categories
        self.perf_repo = perf_repo

    async def total_equity_usd(self) -> float:
        # naive: sum USDT + USD + (optionally convert BTC≈0 if no px); for production: use price feed/mark prices
        total = 0.0
        for name, ex in self.exchanges.items():
            try:
                bal = await ex.balance()
                total += float(bal.get("USDT",0) + bal.get("USD",0))
            except Exception as e:
                logger.warning("balance fetch failed %s: %s", name, e)
        return max(total, 0.0)

    async def rank_aggressive(self, strategies: List[str]) -> List[str]:
        if not self.perf_repo:
            return strategies
        # get recent pnl per strategy
        items = await self.perf_repo.recent_pnl_by_strategy(limit=100)
        scores = {s: 0.0 for s in strategies}
        for it in items:
            s = it.get("strategy"); scores[s] = scores.get(s,0.0) + float(it.get("pnl_pct",0.0))
        ranked = sorted(strategies, key=lambda s: scores.get(s,0.0), reverse=True)
        return ranked or strategies

    async def budget_for(self, strategy: str, price: float, desire_usd: float = None) -> float:
        equity = await self.total_equity_usd()
        cat = self.categories.get(strategy, "aggressive")
        cap = equity * float(self.allocation_cfg.get(cat, 0.0))
        if cat == "aggressive":
            # split cap among aggressive strategies by recent performance
            all_aggr = [k for k,v in self.categories.items() if v=="aggressive"]
            ranked = await self.rank_aggressive(all_aggr)
            # equal weight if no perf; else decreasing geometric weights
            n = len(ranked) or 1
            weights = [pow(0.8, i) for i in range(n)]
            s = sum(weights) or 1.0
            share_map = {ranked[i]: weights[i]/s for i in range(n)}
            share = share_map.get(strategy, 0.0)
            cap *= share
        # final desired
        if desire_usd is not None:
            return min(cap, desire_usd)
        return cap

    async def amount_for(self, strategy: str, symbol: str, price: float, desire_usd: float = None) -> float:
        usd = await self.budget_for(strategy, price, desire_usd)
        if price and usd>0:
            return usd / price
        return 0.0
