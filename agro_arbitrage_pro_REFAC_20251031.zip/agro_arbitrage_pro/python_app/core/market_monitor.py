import os
from tao.ws_watchdog import heartbeat
USE_WS = os.getenv("USE_WS","false").lower()=="true"
class MarketMonitor:
    def __init__(self, connectors): self.connectors = connectors
    async def orderbook(self, symbol: str):
        # pick first exchange by default
        ex_name, ex = next(iter(self.connectors.items()))
        if USE_WS and hasattr(ex, "watch_orderbook"):
            try: 
                ob = await ex.watch_orderbook(symbol); heartbeat(ex_name, symbol); return ob
            except Exception: 
                ob = await ex.fetch_orderbook(symbol); heartbeat(ex_name, symbol); return ob
        ob = await ex.fetch_orderbook(symbol); heartbeat(ex_name, symbol); return ob
    async def books_multi(self, symbols):
        out = {}
        for sym in symbols:
            out[sym] = {}
            for name, ex in self.connectors.items():
                try:
                    ob = await ex.fetch_orderbook(sym); ob["exchange"]=name; out[sym][name]=ob; heartbeat(name, sym)
                except Exception:
                    pass
        return out
