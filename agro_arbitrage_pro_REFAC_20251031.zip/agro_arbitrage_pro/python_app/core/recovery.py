import time, json, os
from typing import Dict, Any, List
class GapDetector:
    def __init__(self,max_gap_ms:int=2000): self.max_gap_ms=max_gap_ms; self.last_ts={}
    def ok(self,key:str,ts_ms:int)->bool:
        last=self.last_ts.get(key); self.last_ts[key]=ts_ms
        return True if last is None else (ts_ms-last)<=self.max_gap_ms
class RecoveryLog:
    def __init__(self,path:str="data/recovery.log"): self.path=path; os.makedirs(os.path.dirname(path),exist_ok=True)
    def append(self,event:Dict[str,Any]):
        with open(self.path,"a",encoding="utf-8") as f: f.write(json.dumps(event)+"\n")
    def replay(self)->List[Dict[str,Any]]:
        if not os.path.exists(self.path): return []
        return [json.loads(l) for l in open(self.path,"r",encoding="utf-8").read().splitlines() if l.strip()]
class Deduper:
    def __init__(self): self.seen=set()
    def first_time(self,key:str)->bool:
        if key in self.seen: return False
        self.seen.add(key); return True

class StrategyStateStore:
    def __init__(self, path: str = "data/strategy_state.json"):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)

    def load(self) -> Dict[str, Any]:
        if not os.path.exists(self.path): return {}
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save(self, state: Dict[str, Any]):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
