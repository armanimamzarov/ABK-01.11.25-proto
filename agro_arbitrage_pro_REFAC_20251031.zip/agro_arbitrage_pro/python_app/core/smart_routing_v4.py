from typing import Dict, Any, List
from utils.logger import setup_logger
import asyncio, random
log = setup_logger(__name__)

def choose_venues(liq_by_venue: Dict[str, float], fees_bps: Dict[str, float], top_n: int = 3) -> List[str]:
    scored = []
    for v, liq in liq_by_venue.items():
        fee = fees_bps.get(v, 5.0)
        score = max(0.0, liq - fee*0.01)
        scored.append((score, v))
    scored.sort(reverse=True)
    return [v for _,v in scored[:top_n]]

def split_notional(target_usd: float, venues: List[str], weights: Dict[str,float]) -> Dict[str,float]:
    if not venues: return {}
    total = sum(weights.get(v,1.0) for v in venues) or 1.0
    return {v: target_usd * (weights.get(v,1.0)/total) for v in venues}

async def route_and_execute(target_usd: float, symbol: str, side: str, executors: Dict[str, Any],
                            liq_by_venue: Dict[str, float], fees_bps: Dict[str, float]) -> List[Dict[str, Any]]:
    venues = choose_venues(liq_by_venue, fees_bps, top_n=3)
    weights = {v: liq_by_venue.get(v,1.0) for v in venues}
    plan = split_notional(target_usd, venues, weights)
    fills = []
    # primary pass
    for v, usd in plan.items():
        ex = executors.get(v)
        if not ex: continue
        try:
            px = (await ex.fetch_ticker(symbol)).get("last") if hasattr(ex, "fetch_ticker") else None
            amt = (usd/px) if px else None
            fills.append(await ex.create_order(symbol, side, amt, px, "limit", {"timeInForce":"IOC"}))
        except Exception as e:
            log.warning("route v4: primary %s failed: %s", v, e)
    # fallback: route remainder to best-available with market order
    rem = max(0.0, target_usd - sum(f.get("filled",0)* (f.get("price") or 0) for f in fills if f))
    if rem > 0:
        for v in venues:
            ex = executors.get(v)
            if not ex: continue
            try:
                px = (await ex.fetch_ticker(symbol)).get("last"); amt = rem/px
                fills.append(await ex.create_order(symbol, side, amt, None, "market", {})); rem = 0.0; break
            except Exception as e:
                log.warning("route v4: fallback %s failed: %s", v, e)
                await asyncio.sleep(0.05 + random.random()*0.05)
    return fills
