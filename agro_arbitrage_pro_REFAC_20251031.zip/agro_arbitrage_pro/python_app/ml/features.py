def features_from_book(book):
    bb = book.get('best_bid',{}).get('price') or 0
    ba = book.get('best_ask',{}).get('price') or 0
    spread = (ba - bb) / ba * 100 if ba else 0
    qty_b = book.get('best_bid',{}).get('qty') or 0
    qty_a = book.get('best_ask',{}).get('qty') or 0
    imbalance = (qty_b - qty_a) / max(qty_b + qty_a, 1e-9)
    return {"spread": spread, "imbalance": imbalance}
