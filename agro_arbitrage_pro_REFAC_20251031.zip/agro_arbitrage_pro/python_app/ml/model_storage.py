import json, time
from pathlib import Path
class ModelStorage:
    def __init__(self, root: str = "models"):
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
    def save_meta(self, name: str, meta: dict):
        meta = dict(meta); meta["saved_at"] = time.time()
        (self.root / f"{name}.meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    def load_meta(self, name: str):
        p = self.root / f"{name}.meta.json"
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
