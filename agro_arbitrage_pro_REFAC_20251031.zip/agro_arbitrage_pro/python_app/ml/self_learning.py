import asyncio, time, math
from collections import defaultdict
from typing import Dict, Any, List
from utils.logger import setup_logger

logger = setup_logger(__name__)

class SelfLearning:
    def __init__(self, state_ref, interval_weights_sec=600, interval_rebalance_sec=3600):
        self.state_ref = state_ref
        self.interval_weights_sec = interval_weights_sec
        self.interval_rebalance_sec = interval_rebalance_sec
        self.weights = defaultdict(lambda: 1.0)
        self.beta = 1.0

    async def start(self):
        asyncio.create_task(self._loop_weights())
        asyncio.create_task(self._loop_rebalance())

    async def _loop_weights(self):
        while True:
            await asyncio.sleep(self.interval_weights_sec)
            st = self.state_ref()
            if not st: continue
            pnl = st.pnl  # dict by strategy
            if not pnl: continue
            total = sum(abs(v) for v in pnl.values()) or 1.0
            for k,v in pnl.items():
                self.weights[k] = max(0.2, min(2.0, 1.0 + (v/total)))
            logger.info("ML weights updated: %s", dict(self.weights))

    async def _loop_rebalance(self):
        while True:
            await asyncio.sleep(self.interval_rebalance_sec)
            # simplistic volatility-based beta adjustment
            # (hook here to realized vol calc)
            self.beta = max(0.5, min(1.5, self.beta + 0.05))
            logger.info("Risk beta rebalanced: %.2f", self.beta)
