from .depth_delta import depth_delta, ofi as ofi_metric

_last_books = {}

def build_features(book):
    bb = (book or {}).get('best_bid',{}).get('price') or 0.0
    ba = (book or {}).get('best_ask',{}).get('price') or 0.0
    spread_abs = (ba - bb)
    spread_pct = (spread_abs/ba*100) if ba else 0.0
    qb = (book or {}).get('best_bid',{}).get('qty') or 0.0
    qa = (book or {}).get('best_ask',{}).get('qty') or 0.0
    imb = (qb-qa)/max(qb+qa,1e-9)
    mid = (bb+ba)/2 if (bb and ba) else None

    # OFI / depth-delta using normalized book structure (expects bids/asks arrays)
    sym = book.get('symbol',"UNKNOWN")
    prev = _last_books.get(sym)
    bd, ad = depth_delta(prev or {}, book) if prev else (0.0, 0.0)
    ofi_val = ofi_metric(((prev['best_bid']['price']+prev['best_ask']['price'])/2) if prev else None, mid, bd, ad)
    _last_books[sym] = book

    return {
        "spread_pct": spread_pct, "spread_abs": spread_abs,
        "imbalance": imb, "mid": mid or 0.0,
        "bid_delta": bd, "ask_delta": ad, "ofi": ofi_val
    }
