import math, random, time, json
from pathlib import Path

class UCBBandit:
    def __init__(self, arms, c=2.0, state_file="logs/ml/bandit_state.json"):
        self.arms = list(arms); self.c = c; self.state_file = state_file
        self.rewards = {a:0.0 for a in self.arms}
        self.counts = {a:0 for a in self.arms}
        Path(state_file).parent.mkdir(parents=True, exist_ok=True)
        self._load()

    def _load(self):
        p = Path(self.state_file)
        if p.exists():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                self.rewards.update(data.get("rewards",{}))
                self.counts.update(data.get("counts",{}))
            except Exception:
                pass

    def _save(self):
        Path(self.state_file).write_text(json.dumps({"rewards":self.rewards,"counts":self.counts}, indent=2), encoding="utf-8")

    def select(self, t):
        # ensure each arm tried at least once
        for a in self.arms:
            if self.counts[a]==0:
                return a, 1.0
        total = sum(self.counts.values()) or 1
        best = None; best_score = -1e9
        for a in self.arms:
            avg = self.rewards[a]/max(1,self.counts[a])
            bonus = self.c*math.sqrt(math.log(total)/self.counts[a])
            s = avg + bonus
            if s > best_score:
                best, best_score = a, s
        return best, best_score

    def update(self, arm, reward):
        self.counts[arm]+=1; self.rewards[arm]+=float(reward); self._save()
