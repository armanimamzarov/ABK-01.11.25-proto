def classify(edge_pct: float, spread: float, threshold: float = 0.6):
    conf = 0.5 + max(0.0, edge_pct - spread)/100.0
    if conf >= threshold: return "trade", conf
    return "hold", conf
