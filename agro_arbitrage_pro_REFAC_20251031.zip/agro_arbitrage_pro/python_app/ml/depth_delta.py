from typing import Dict, Any, Tuple

def depth_delta(prev: Dict[str, Any], cur: Dict[str, Any]) -> Tuple[float, float]:
    """Return (bid_delta, ask_delta) as sum of qty diffs top-10."""
    if not prev or not cur: return 0.0, 0.0
    pbids, pasks = prev.get('bids', []), prev.get('asks', [])
    cbids, casks = cur.get('bids', []), cur.get('asks', [])
    top = 10
    bd = sum((cbids[i][1] - pbids[i][1]) for i in range(min(top, len(pbids), len(cbids)))) if pbids and cbids else 0.0
    ad = sum((casks[i][1] - pasks[i][1]) for i in range(min(top, len(pasks), len(casks)))) if pasks and casks else 0.0
    return bd, ad

def ofi(prev_mid: float, cur_mid: float, bid_delta: float, ask_delta: float) -> float:
    """Basic Order Flow Imbalance proxy."""
    if prev_mid is None or cur_mid is None: return 0.0
    direction = 1.0 if cur_mid >= prev_mid else -1.0
    return direction * (bid_delta - ask_delta)
