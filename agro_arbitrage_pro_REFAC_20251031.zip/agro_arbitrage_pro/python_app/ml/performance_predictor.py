def expected_return(edge_pct: float, fees_pct: float, slip_pct: float) -> float:
    return max(0.0, edge_pct - fees_pct - slip_pct)
