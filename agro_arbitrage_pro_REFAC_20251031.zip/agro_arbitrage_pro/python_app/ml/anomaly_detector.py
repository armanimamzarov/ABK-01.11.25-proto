def anomaly_score(volatility: float, spread: float) -> float:
    return 0.5*volatility + 0.5*spread
def is_anomaly(score: float, limit: float = 2.5) -> bool:
    return score >= limit
