
import math
def psi(expected: list, actual: list, bins: int = 10) -> float:
    if not expected or not actual: return 0.0
    mn = min(min(expected), min(actual)); mx = max(max(expected), max(actual))
    if mn == mx: return 0.0
    step = (mx-mn)/bins
    e_counts = [0]*bins; a_counts = [0]*bins
    for x in expected:
        i = min(bins-1, int((x-mn)/step)); e_counts[i]+=1
    for x in actual:
        i = min(bins-1, int((x-mn)/step)); a_counts[i]+=1
    E = [c/max(1,sum(e_counts)) for c in e_counts]
    A = [c/max(1,sum(a_counts)) for c in a_counts]
    s=0.0
    for e,a in zip(E,A):
        e=max(e,1e-6); a=max(a,1e-6)
        s += (a-e)*math.log(a/e)
    return s
