ROLES = {
    "Admin": ["enable","disable","set_risk","pnl","restart"],
    "Trader": ["enable","disable","set_risk","pnl"],
    "Viewer": ["pnl"]
}
def can(role: str, action: str) -> bool:
    return action in ROLES.get(role, [])
