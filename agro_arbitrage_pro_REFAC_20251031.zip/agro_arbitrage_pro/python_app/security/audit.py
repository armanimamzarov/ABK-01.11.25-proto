import json, time
from pathlib import Path
LOG = Path("logs/audit.log")
def write(event: str, data: dict):
    LOG.parent.mkdir(parents=True, exist_ok=True)
    LOG.write_text(LOG.read_text(encoding="utf-8")+json.dumps({"ts":time.time(),"event":event,"data":data})+"\n" if LOG.exists() else json.dumps({"ts":time.time(),"event":event,"data":data})+"\n", encoding="utf-8")
