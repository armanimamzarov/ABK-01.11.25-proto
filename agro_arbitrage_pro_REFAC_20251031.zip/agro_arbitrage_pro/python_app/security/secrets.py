import os, json
from pathlib import Path

def get_secret(name: str, default: str = "") -> str:
    # Look in ENV, then local secrets file
    v = os.getenv(name)
    if v: return v
    p = Path("configs/secrets.local.json")
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8")).get(name, default)
        except Exception:
            return default
    return default
