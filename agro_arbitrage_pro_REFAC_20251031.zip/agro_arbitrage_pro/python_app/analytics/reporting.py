from datetime import datetime, timedelta
def pnl_by_period(repo, days: int = 7):
    end = datetime.utcnow(); start = end - timedelta(days=days)
    return repo.pnl_between(start, end)
