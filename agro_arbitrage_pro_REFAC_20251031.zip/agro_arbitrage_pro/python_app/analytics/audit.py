import json, time, os
from pathlib import Path

class Audit:
    def __init__(self, path: str = "logs/audit/audit.log"):
        Path(os.path.dirname(path)).mkdir(parents=True, exist_ok=True)
        self.path = path
    def write(self, event: dict):
        event["ts"] = time.time()
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False)+"\n")
