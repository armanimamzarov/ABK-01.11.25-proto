import pandas as pd
import numpy as np
import argparse, time, os
from datetime import datetime
from .metrics import arb_profit_total, order_latency_ms, order_reject_count, serve
import logging
logger = logging.getLogger(__name__)

def backtest(path: str, speed: float = 1.0, report_dir: str = "reports"):
    serve()
    df = pd.read_csv(path, parse_dates=["ts"])
    df = df.sort_values("ts")

    equity = 10_000.0
    daily_pnl = 0.0
    dd = 0.0
    peak = equity

    for _, row in df.iterrows():
        # Простейшая модель: если спред > threshold, считаем исполнение и прибыль
        spread = row.get("spread", 0.0)
        if spread > 0.0006:
            profit = spread * 100.0  # synthetic
            equity += profit
            daily_pnl += profit
            arb_profit_total.labels(row["exchange"], row["pair"], row.get("strategy","bt"), row.get("leg","1")).inc(profit)
            order_latency_ms.labels(row["exchange"], row["pair"], "bt", "1").observe(5.0)
        peak = max(peak, equity)
        dd = min(dd, equity - peak)

        time.sleep(max(0.0, 0.01 / speed))

    # Отчёт
    os.makedirs(report_dir, exist_ok=True)
    date = datetime.utcnow().strftime("%Y-%m-%d")
    out = os.path.join(report_dir, f"{date}.csv")
    pd.DataFrame([{
        "date": date,
        "equity": equity,
        "daily_pnl": daily_pnl,
        "max_drawdown": dd,
        "avg_risk": np.nan,
    }]).to_csv(out, index=False)
logger.info(f"Backtest report -> {out}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--speed", type=float, default=1.0)
    args = ap.parse_args()
    backtest(args.csv, args.speed)