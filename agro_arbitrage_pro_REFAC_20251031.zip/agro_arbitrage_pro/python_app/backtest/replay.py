import json, time
from typing import Iterable

def replay(file_path: str, speed: float = 1.0) -> Iterable[dict]:
    for line in open(file_path, 'r', encoding='utf-8'):
        ev = json.loads(line)
        time.sleep(max(ev.get('delay',0)/speed, 0))
        yield ev
