from typing import Any
import aiohttp, os
from utils.logger import setup_logger
logger = setup_logger(__name__)

API = os.getenv("BOT_API_URL","http://localhost:8000")

async def cmd_start(update, context):
    await update.message.reply_text("🚀 Bot online. /status /opps /report /start_strategy name /stop_strategy name /pnl")

async def cmd_status(update, context):
    await update.message.reply_text("✅ Status: running")

async def cmd_opps(update, context):
    await update.message.reply_text("📊 Opportunities stream active")

async def cmd_report(update, context):
    async with aiohttp.ClientSession() as s:
        async with s.get(f"{API}/pnl") as r:
            data = await r.json()
    await update.message.reply_text(f"🧾 Report: {data}")

async def cmd_start_strategy(update, context):
    args = context.args
    if not args: return await update.message.reply_text("Usage: /start_strategy STRATEGY_NAME")
    name = args[0]
    async with aiohttp.ClientSession() as s:
        async with s.post(f"{API}/strategy/enable/{name}") as r:
            await update.message.reply_text(f"▶️ Enabled {name} -> {r.status}")

async def cmd_stop_strategy(update, context):
    args = context.args
    if not args: return await update.message.reply_text("Usage: /stop_strategy STRATEGY_NAME")
    name = args[0]
    async with aiohttp.ClientSession() as s:
        async with s.post(f"{API}/strategy/disable/{name}") as r:
            await update.message.reply_text(f"⏹ Disabled {name} -> {r.status}")

async def cmd_pnl(update, context):
    async with aiohttp.ClientSession() as s:
        async with s.get(f"{API}/pnl") as r:
            data = await r.json()
    await update.message.reply_text(f"📈 PnL: {data}")
