from typing import Dict, Any
def format_status(stats: Dict[str, Any]) -> str:
    lines = ["*Agro Arbitrage — Realtime*", ""]
    for k,v in stats.items():
        lines.append(f"- {k}: {v}")
    return "\n".join(lines)
