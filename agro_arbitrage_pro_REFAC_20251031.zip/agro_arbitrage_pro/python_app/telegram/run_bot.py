import os, asyncio
from telegram.ext import ApplicationBuilder, CommandHandler
from utils.logger import setup_logger
from .commands_panel import start, status, balance, pause, resume, switch_mode, strategies, set_risk, reset_daily, logs, restart_tao

logger = setup_logger(__name__)

async def main():
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token: raise RuntimeError("TELEGRAM_BOT_TOKEN not set")
    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("pause", pause))
    app.add_handler(CommandHandler("resume", resume))
    app.add_handler(CommandHandler("switch_mode", switch_mode))
    app.add_handler(CommandHandler("strategies", strategies))
    app.add_handler(CommandHandler("set_risk", set_risk))
    app.add_handler(CommandHandler("reset_daily", reset_daily))
    app.add_handler(CommandHandler("logs", logs))
    app.add_handler(CommandHandler("restart_tao", restart_tao))
    logger.info("🤖 Telegram panel started")
    await app.initialize(); await app.start(); await app.updater.start_polling()
    await asyncio.Event().wait()

if __name__ == "__main__":
    asyncio.run(main())
