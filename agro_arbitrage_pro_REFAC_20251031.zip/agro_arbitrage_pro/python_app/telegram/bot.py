import os, asyncio, json
from telegram.ext import ApplicationBuilder, CommandHandler
from utils.logger import setup_logger
logger = setup_logger(__name__)

CFG_PATH = "configs/arbitrage_strategies.json"

async def start(update, ctx): await update.message.reply_text("🤖 Agro — /status /strategies /balance /enable /disable /set_risk /pnl")
async def status(update, ctx): await update.message.reply_text("✅ Online")

async def strategies(update, ctx):
    try:
        data = json.loads(open(CFG_PATH,"r",encoding="utf-8").read())
        names = [("🟢" if s.get("enabled") else "🔴")+ " "+ s["name"] for s in data.get("strategies",[])]
        await update.message.reply_text("\n".join(names) or "нет стратегий")
    except Exception as e:
        await update.message.reply_text(f"error: {e}")

async def balance(update, ctx):
    try:
        j = json.loads(open("configs/balance.json","r",encoding="utf-8").read())
        await update.message.reply_text(f"💰 balance today PnL: {j.get('profit_today',0)}")
    except Exception:
        await update.message.reply_text("нет данных")

def _toggle_strategy(name: str, enabled: bool):
    data = json.loads(open(CFG_PATH,"r",encoding="utf-8").read())
    changed=False
    for s in data.get("strategies",[]):
        if s.get("name")==name:
            s["enabled"]=enabled; changed=True
    if changed:
        open(CFG_PATH,"w",encoding="utf-8").write(json.dumps(data, indent=2, ensure_ascii=False))
    return changed

async def enable(update, ctx):
    if not ctx.args: return await update.message.reply_text("usage: /enable <strategy_name>")
    ok = _toggle_strategy(ctx.args[0], True)
    await update.message.reply_text("✅ enabled" if ok else "❌ not found")

async def disable(update, ctx):
    if not ctx.args: return await update.message.reply_text("usage: /disable <strategy_name>")
    ok = _toggle_strategy(ctx.args[0], False)
    await update.message.reply_text("✅ disabled" if ok else "❌ not found")

async def set_risk(update, ctx):
    if not ctx.args: return await update.message.reply_text("usage: /set_risk <0.5..2.0>")
    try:
        val=float(ctx.args[0])
        data=json.loads(open("configs/risk_management.json","r",encoding="utf-8").read())
        data["risk_scale_factor"]=[val,val]
        open("configs/risk_management.json","w",encoding="utf-8").write(json.dumps(data, indent=2, ensure_ascii=False))
        await update.message.reply_text(f"✅ risk_scale_factor={val}")
    except Exception as e:
        await update.message.reply_text(f"error: {e}")

async def pnl(update, ctx):
    try:
        from database.performance_repository import PerformanceRepository
        dsn = os.getenv("POSTGRES_DSN","postgresql+psycopg2://user:pass@localhost:5432/agro")
        rep = PerformanceRepository(dsn)
        rows = rep.daily_pnl()
        msg = "\n".join(f"{r[0]}: {r[1]:.2f} USDT" for r in rows) if rows else "нет данных"
        await update.message.reply_text("📈 PnL by day:\n"+msg)
    except Exception as e:
        await update.message.reply_text(f"db error: {e}")

async def main():
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token: raise RuntimeError("TELEGRAM_BOT_TOKEN not set")
    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("strategies", strategies))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("enable", enable))
    app.add_handler(CommandHandler("disable", disable))
    app.add_handler(CommandHandler("set_risk", set_risk))
    app.add_handler(CommandHandler("pnl", pnl))
    logger.info("Telegram bot started")
    await app.initialize(); await app.start(); await app.updater.start_polling()
    await asyncio.Event().wait()

if __name__ == "__main__":
    asyncio.run(main())
