import random, time
from typing import Dict, Any, List

class Simulator:
    def __init__(self, latency_ms=50, partial_fill_prob=0.3):
        self.latency_ms = latency_ms
        self.partial_fill_prob = partial_fill_prob

    async def execute(self, legs: List[Dict[str, Any]]) -> Dict[str, Any]:
        filled = []
        for leg in legs:
            await asyncio.sleep(self.latency_ms/1000.0)
            amt = leg['amount']
            if random.random() < self.partial_fill_prob:
                amt *= random.uniform(0.6, 1.0)
            filled.append({**leg, "filled": amt})
        return {"legs": filled}
