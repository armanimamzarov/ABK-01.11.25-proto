import os, json, urllib.request
def notify(text: str):
    url = os.getenv("SLACK_WEBHOOK_URL")
    if not url: return False
    data = json.dumps({"text": text}).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type":"application/json"})
    try:
        urllib.request.urlopen(req, timeout=5)
        return True
    except Exception:
        return False
