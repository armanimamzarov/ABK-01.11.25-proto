# Roadmap — MAX release (2025-10-30T09:11:32.078246Z)
- Strategies: funding, liquidity_pulse, stat_arb, mean_reversion_bands
- Smart Routing v4 (liquidity & fee aware)
- TAO v3 (AutoRecovery+, Chaos, SLA)
- Secrets manager stubs, RBAC, Audit
- Web Panel (FastAPI)
- Slack integration
- Reports & Attribution
- Terraform skeleton
