# Backup & Retention

## Postgres (logical dump)
Create dumps:
```bash
./scripts/management/backup_db.sh
```
Restore:
```bash
./scripts/management/restore_db.sh path/to/dump.sql.gz
```

## Logs
- Keep 14 days; rotate daily. See `scripts/management/logrotate.conf`.
