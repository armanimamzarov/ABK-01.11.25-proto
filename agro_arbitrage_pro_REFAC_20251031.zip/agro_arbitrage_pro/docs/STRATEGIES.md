VolatilityRebalance updates bandit weights based on market sigma.


- **Depth-Delta/OFI** фичи добавлены в `ml/feature_engineering.py` и используются ML-гейтом.
- **Snapshot+Diff Recovery** эталон на Binance: `exchanges/binance_handler.py#watch_orderbook_snapshot_diff`.
- **Partial-Fill Manager**: `core/partial_fill_manager.py` (ретраи + VWAP-подсказка).
