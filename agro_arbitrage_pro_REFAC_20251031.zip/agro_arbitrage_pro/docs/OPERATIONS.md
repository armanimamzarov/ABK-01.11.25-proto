Use Telegram commands /enable /disable /set_risk /pnl. TAO health in logs/tao/health.json


## CLI Monitor
Run: `python_app\venv\Scripts\activate && py cli\monitor.py`
