# Kubernetes Deployment (Helm)

```bash
helm install agro ./charts/agro   --set image.rust_core=agro/rust_core:latest   --set image.python_app=agro/python_app:latest
```

Expose services via Ingress / LoadBalancer по необходимости.
Секреты ключей – через Kubernetes Secrets и envFrom.
