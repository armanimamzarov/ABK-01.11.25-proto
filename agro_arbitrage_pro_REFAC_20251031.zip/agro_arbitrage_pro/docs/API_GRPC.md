# gRPC API (Execution v1)

Service: agro.execution.v1.Execution

Methods: ExecuteTwoLeg, ExecuteThreeLeg, Health, Version

Messages: Leg, ExecMeta, TwoLegRequest, ThreeLegRequest, ExecReply

Metrics: agro_execution_latency_seconds, agro_error_total, agro_fills_total, agro_ob_staleness_ms
