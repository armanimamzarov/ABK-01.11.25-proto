# RUNBOOK — AgroArbitrage

## Services & Ports
| Service      | Port | Endpoint                    | Health             |
|--------------|-----:|-----------------------------|--------------------|
| Rust gRPC    | 8080 | gRPC                        | Health() RPC       |
| Rust metrics | 9095 | /metrics                    | N/A                |
| Python API   | 8081 | /health, /metrics, /docs   | /health == 200 OK  |
| Prometheus   | 9090 | UI                          | N/A                |

## Env / Secrets (required)
- BINANCE_KEY / BINANCE_SECRET
- BYBIT_KEY / BYBIT_SECRET
- GRPC_ADDRESS (default rust_core:8080)
- RISK_CONFIG (default configs/risk_management.json)

## Start (local)
```bash
pip install -r python_app/requirements.txt grpcio grpcio-tools
bash scripts/build_proto_py.sh
docker compose up --build
```

## Health Checks
- Python: `GET /health` → `{"ok": true}`
- Rust: `Health(Empty)` gRPC → `ok: true`

## Manual checks
- Submit mock orders via Python coordinator in DRY_RUN
- Watch metrics at :9095/metrics and :8081/metrics

## Recovery / Rollback
- Recovery log: `data/recovery.log`
- Replay: load events → restore strategy state → re-run pending orders with dedupe
- Rollback: set `features.dry_run=true` and scale to 0 live traders
