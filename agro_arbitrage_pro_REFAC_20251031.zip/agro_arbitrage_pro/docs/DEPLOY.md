# Deploy

## GitHub Container Registry (GHCR) — Build & Push
1. Включи Actions в репо. На пуш в `main` образы соберутся и попадут в GHCR:
   - `ghcr.io/<owner>/agrorustcore:latest`
   - `ghcr.io/<owner>/agropythonapp:latest`

## VPS (Docker Compose)
```bash
cp .env.example .env
# заполни ключи / токены
docker compose up --build -d db rust_core python_app prometheus alertmanager grafana
```

## Kubernetes (Helm)
```bash
# Создай values-secrets.yaml и заполни ключи
helm install agro ./charts/agro   -f charts/agro/values-secrets.example.yaml   --set image.rust_core=ghcr.io/<owner>/agrorustcore:latest   --set image.python_app=ghcr.io/<owner>/agropythonapp:latest
```

## Telegram Bot
```bash
export TELEGRAM_BOT_TOKEN=... TELEGRAM_CHAT_ID=...
python -m python_app.telegram.run_bot
# Команды: /start /status /opps /report /pnl /start_strategy NAME /stop_strategy NAME
```
