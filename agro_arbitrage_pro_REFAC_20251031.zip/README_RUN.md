# Run Guide — Start All

## Windows
1) Заполни `.env` в корне (USE_WS=true/false и ключи бирж).
2) Запуск:
   ```bat
   scripts\Start_All.bat
   ```
   Это поднимет сразу:
   - API (`/health`, `/metrics`)
   - Core (стратегии)
   - Telegram-бот
   - TAO Supervisor

Остановить:
```bat
scripts\Stop_All.bat
```

## Примечания
- Если нет `ccxt.pro` — поставь `USE_WS=false`.
- Логи PID: `python_app/logs/pids.json`
