# AGRO Arbitrage PRO — Production Build

This package includes the Rust low-latency core, Python control panel (Telegram + HTTP), databases (PostgreSQL, ClickHouse, Redis), and observability (Prometheus, Grafana, Alertmanager).

## TL;DR (local, Docker)
```bash
cp .env.example .env   # fill exchange API keys and Telegram token
docker compose -f docker-compose.prod.yml up -d --build
# Grafana: http://localhost:3000 (admin/admin)
# Prometheus: http://localhost:9090
# Python panel metrics/health: http://localhost:9101/metrics  /health
```

## Highlights
- **Rust core** with Tokio runtime, metrics at `:9100/metrics`
- **Python panel** with aiogram v3 bot: `/latency`, `/drawdown`, `/pnl`, `/report`
- **Databases**: Postgres (balances, trades), ClickHouse (quotes), Redis (orderbooks)
- **Observability**: Prometheus & Grafana dashboard auto-provisioned

### Security
- Secrets from `.env` (consider Vault in production)
- Minimal exposed ports; internal network used by default


## ML / AutoML
- Тренировка и экспорт в ONNX: `python -m python_app.ml.automl_train` (берёт данные из ClickHouse, пишет `/models/risk.onnx`).
- Rust ядро автоматически **горячо** перечитает модель при изменении файла.
- Drift монитор: сервис `python_drift` (порт 9103) экспонирует метрику `agro_feature_drift`.

## Model Sync (S3/локально)
- Сервис `python_modelsync` синхронизирует модель в `/models/risk.onnx` с `AGRO_MODEL_SRC` (поддерживает `s3://bucket/key`).


## Risk Guard (VaR/ES + Stress + Halt)
- Сервис `python_risk_guard` (порт 9105) считает **VaR**, **ES** и **Drawdown**; при нарушении лимитов создаёт `/models/halt.flag` → Rust ядро мгновенно блокирует заявки.
- Настройки:
  - `AGRO_RISK_HALT_FILE=/models/halt.flag`
  - `AGRO_RISK_VAR_CONF=0.99`
  - `AGRO_RISK_VAR_LIMIT=0.03`  (3%)
  - `AGRO_RISK_DRAWDOWN_LIMIT=0.10` (10%)

## etcd-конфиг
- Сервис `etcd` + `python_configsync` (порт 9106) читает префикс `/agro/config/*` и применяет:
  - `trading_halt=1` → создаёт `/models/halt.flag` (снятие — удаляет флаг).
  - Пишет актуальные ключи в `/models/runtime_config.json` для аудита.
- Пример:
  ```bash
  docker exec -it $(docker ps -qf name=etcd) etcdctl put /agro/config/trading_halt 1
  ```

## CDC в ClickHouse
- SQL миграции: `db/pg_audit_cdc.sql` создаёт `audit_log` и триггеры на `orders`, `trades`.
- Сервис `python_cdc_poller` (порт 9107) читает `audit_log` и пишет в ClickHouse таблицу `audit_log`.


## Telegram RBAC & аудит
- Разрешённые пользователи: `TELEGRAM_ALLOWLIST=12345,67890` (ID через запятую).
- Любая команда бота логируется в таблицу `audit_telegram` (Postgres).

## Тюнинг моделей (Optuna/FLAML)
- Optuna: `python -m python_app.ml.tune_optuna` (ENV: `OPTUNA_TRIALS=30`).
- FLAML:  `python -m python_app.ml.tune_flaml` (ENV: `FLAML_TIME_BUDGET=300`).

## Портфельный VaR/ES и стресс
- `python_risk_guard` теперь учитывает позиции (из `positions` или восстановленные из `trades`) и считает VaR/ES портфеля, а также стресс-сценарий (шок цены + расширение спреда). Порог сравнивается с `AGRO_RISK_VAR_LIMIT`.


## Роли Telegram и команды админа
- Роли задаются JSON в `.env` через `TELEGRAM_ROLES`, например:
  ```
  TELEGRAM_ROLES={"12345":"admin","67890":"operator"}
  TELEGRAM_ALLOWLIST=12345,67890
  ```
- Команды:
  - `/halt_on` — остановить торговлю (admin)
  - `/halt_off` — возобновить (admin)
  - `/risk_report` — сгенерировать HTML-отчёт и получить путь к файлу



## Operational Runbook

### Local
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt  # if file exists
pre-commit install
make fmt lint
python -m python_app  # or your entrypoint
```

### Docker
```bash
cp .env.example .env
docker compose build
docker compose up -d
```

### CI
- GitHub Actions runs lint & build on PRs.
- Add secrets to repository settings for deployments.

### Notes
- Secrets MUST NOT be committed. Use `.env` locally and a secret manager in prod.
- `yaml.safe_load` enforced by transform.
- Bare `except:` normalized to `except Exception:`.


### Testing
```bash
pip install -r requirements-dev.txt
pytest
```

## Production quickstart
```bash
cp .env.example .env
make up-prod
# Grafana http://localhost:3000  | Prometheus http://localhost:9090
# App health http://localhost:9101/health  | Metrics http://localhost:9101/metrics
```
