# Contributing

1. Create a feature branch.
2. Install pre-commit: `pip install pre-commit && pre-commit install`.
3. Run linters: `ruff check . && black . && mypy .`.
4. Add/Update tests.
5. Open a PR with a clear description and checklist.
