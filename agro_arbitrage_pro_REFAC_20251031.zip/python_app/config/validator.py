
from __future__ import annotations
import json
from pathlib import Path
import logging
logger = logging.getLogger(__name__)

REQUIRED = {
  "configs/system.json": ["grpc_host","grpc_port","metrics_port","log_level","default_quote"],
  "configs/exchanges.json": ["binance","bybit","okx","kucoin","gateio","mexc"],
  "configs/arbitrage_strategies.json": ["active","params"],
  "configs/risk_management.json": ["live_trading","max_daily_drawdown_pct","max_position_usd","kill_switch_on_error","circuit_breaker_seconds"],
  "configs/telegram.json": ["bot_token","chat_id"]
}

def validate() -> list[str]:
    errors: list[str] = []
    for path, keys in REQUIRED.items():
        data = json.loads(Path(path).read_text())
        for k in keys:
            if k not in data:
                errors.append(f"{path}: missing key '{k}'")
    return errors

if __name__ == "__main__":
    errs = validate()
    if errs:
logger.info("\n".join(errs))
        raise SystemExit(1)
logger.info("OK")