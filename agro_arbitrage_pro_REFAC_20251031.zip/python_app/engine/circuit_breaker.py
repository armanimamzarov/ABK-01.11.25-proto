
from __future__ import annotations
import time

class CircuitBreaker:
    def __init__(self, redis, threshold: int, cooldown_sec: int):
        self.redis = redis
        self.threshold = threshold
        self.cooldown = cooldown_sec

    def is_open(self, venue: str, operation: str) -> bool:
        key = f"cb:{venue}:{operation}:opened_until"
        opened_until = self.redis.get(key)
        if not opened_until:
            return False
        try:
            return float(opened_until) > time.time()
        except Exception:
            return False

    def incr_failure(self, venue: str, operation: str) -> None:
        base = f"cb:{venue}:{operation}"
        count_key = base + ":count"
        newv = self.redis.incr(count_key)
        self.redis.expire(count_key, self.cooldown)
        if newv >= self.threshold:
            self.redis.set(base + ":opened_until", str(time.time() + self.cooldown), ex=self.cooldown)

    def reset(self, venue: str, operation: str) -> None:
        base = f"cb:{venue}:{operation}"
        self.redis.delete(base + ":count")
        self.redis.delete(base + ":opened_until")
