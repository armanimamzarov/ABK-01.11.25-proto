
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Optional

class OrderState(str, Enum):
    NEW = "New"
    PENDING_NEW = "PendingNew"
    ACK = "Ack"
    PARTIAL = "Partial"
    FILLED = "Filled"
    REJECTED = "Rejected"
    CANCELED = "Canceled"
    DEAD = "Dead"

_ALLOWED = {
    OrderState.NEW: {OrderState.PENDING_NEW, OrderState.REJECTED},
    OrderState.PENDING_NEW: {OrderState.ACK, OrderState.REJECTED, OrderState.CANCELED},
    OrderState.ACK: {OrderState.PARTIAL, OrderState.FILLED, OrderState.CANCELED},
    OrderState.PARTIAL: {OrderState.PARTIAL, OrderState.FILLED, OrderState.CANCELED},
    OrderState.REJECTED: set(),
    OrderState.CANCELED: set(),
    OrderState.FILLED: set(),
    OrderState.DEAD: set(),
}

@dataclass(frozen=True)
class Transition:
    client_order_id: str
    venue: str
    from_state: OrderState
    to_state: OrderState
    reason: Optional[str] = None

def can_transition(from_state: OrderState, to_state: OrderState) -> bool:
    return to_state in _ALLOWED.get(from_state, set())
