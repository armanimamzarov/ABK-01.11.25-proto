
from __future__ import annotations
import uuid
from typing import Optional

class RedisLike:
    def setnx(self, key: str, value: str, ex: int) -> bool: ...
    def delete(self, key: str) -> int: ...

class IdemGuard:
    def __init__(self, redis: RedisLike, ttl_seconds: int = 120):
        self.redis = redis
        self.ttl = ttl_seconds

    def acquire(self, venue: str, client_order_id: str, trace_id: Optional[str]=None) -> bool:
        token = trace_id or str(uuid.uuid4())
        key = f"idem:{venue}:{client_order_id}"
        ok = self.redis.setnx(key, token, ex=self.ttl)
        return bool(ok)

    def release(self, venue: str, client_order_id: str) -> None:
        key = f"idem:{venue}:{client_order_id}"
        try:
            self.redis.delete(key)
        except Exception:
            pass
