
from __future__ import annotations
import time, threading
from queue import PriorityQueue, Empty
from dataclasses import dataclass, field
from typing import Dict, Optional, List, Callable, Tuple
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from pydantic import BaseModel
from ..utils.idgen import order_uuid

class RetryableError(Exception): ...
class NonRetryableError(Exception): ...

class OrderState:
    PENDING_NEW="PendingNew"
    ACK="Ack"
    PARTIAL="Partial"
    FILLED="Fill"
    CANCELLED="Cancel"
    REJECT="Reject"

class ExecReport(BaseModel):
    client_order_id: str
    state: str
    filled_qty: float = 0.0
    avg_price: float = 0.0
    error: Optional[str] = None

@dataclass(order=True)
class QueueItem:
    priority: int
    ts_ns: int
    symbol: str = field(compare=False)
    exchange: str = field(compare=False)
    payload: dict = field(compare=False)

class InMemoryIdempotencyStore:
    def __init__(self):
        self._seen = {}
        self._lock = threading.Lock()
    def put_if_absent(self, key:str, value:dict)->bool:
        with self._lock:
            if key in self._seen:
                return False
            self._seen[key]=value
            return True
    def get(self, key:str):
        return self._seen.get(key)

class DummyExchange:
    """Simulates an exchange adapter. Replace with real venue handlers."""
    def __init__(self, reject_rate: float = 0.0):
        self.reject_rate = reject_rate
    def place_order(self, side:str, symbol:str, qty:float, price:Optional[float], ord_type:str, client_order_id:str)->ExecReport:
        # Simulate ack → fill
        return ExecReport(client_order_id=client_order_id, state=OrderState.FILLED, filled_qty=qty, avg_price=price or 100.0)

class ExecutionGateway:
    def __init__(self, exchanges:Dict[str, DummyExchange]):
        self.exchanges = exchanges
        self.queues: Dict[Tuple[str,str], PriorityQueue] = {}
        self.idem = InMemoryIdempotencyStore()
        self._stop = False
        self._threads: List[threading.Thread] = []

    def _queue_for(self, symbol:str, exchange:str)->PriorityQueue:
        key=(symbol, exchange)
        if key not in self.queues:
            self.queues[key]=PriorityQueue()
            t = threading.Thread(target=self._worker, args=(symbol, exchange), daemon=True)
            t.start()
            self._threads.append(t)
        return self.queues[key]

    def submit_order(self, *, exchange:str, symbol:str, side:str, qty:float, price:Optional[float], ord_type:str, priority:int=10, client_order_id:Optional[str]=None)->str:
        coid = client_order_id or order_uuid(f"{exchange}:{symbol}", 1)
        if not self.idem.put_if_absent(coid, {"exchange":exchange,"symbol":symbol,"side":side,"qty":qty,"price":price,"type":ord_type}):
            # Duplicate — idempotent success
            return coid
        qi = QueueItem(priority=priority, ts_ns=time.time_ns(), symbol=symbol, exchange=exchange, payload={"coid":coid,"side":side,"qty":qty,"price":price,"type":ord_type})
        self._queue_for(symbol, exchange).put(qi)
        return coid

    @retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=0.2, min=0.2, max=3), reraise=True, retry=retry_if_exception_type(RetryableError))
    def _send(self, ex:DummyExchange, payload:dict)->ExecReport:
        try:
            rep = ex.place_order(payload["side"], payload["symbol"], payload["qty"], payload["price"], payload["type"], payload["coid"])
            return rep
        except RetryableError:
            raise
        except Exception as e:
            # Assume non-retryable
            raise NonRetryableError(str(e))

    def _worker(self, symbol:str, exchange:str):
        ex = self.exchanges[exchange]
        q = self.queues[(symbol, exchange)]
        while not self._stop:
            try:
                item: QueueItem = q.get(timeout=0.5)
            except Empty:
                continue
            payload = item.payload
            payload["symbol"]=symbol
            try:
                rep = self._send(ex, payload)
                # In real system: publish ExecReport to bus
            except NonRetryableError as e:
                # mark reject
                pass
            finally:
                q.task_done()

    def stop(self):
        self._stop=True
        for t in self._threads:
            t.join(timeout=0.1)

    def two_leg_atomic(self, leg_a:dict, leg_b:dict)->Tuple[str,str]:
        """Submit legs atomically with simple saga: if B fails, try to cancel/hedge A."""
        a_id = self.submit_order(**leg_a)
        b_id = self.submit_order(**leg_b)
        return a_id, b_id
