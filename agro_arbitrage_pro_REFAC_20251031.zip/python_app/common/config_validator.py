from __future__ import annotations
import os
import re
from typing import Dict, Tuple, List

REQUIRED_ENV: Dict[str, str] = {
    "DB_URL": r"^postgresql://.+$",
    "REDIS_URL": r"^redis://.+$",
    "EXCHANGE_BINANCE_KEY": r"^.{20,}$",
    "EXCHANGE_BINANCE_SECRET": r"^.{20,}$",
    "PROMETHEUS_PUSHGATEWAY": r"^https?://.+$",
}

OPTIONAL_ENV: Dict[str, Tuple[str, str]] = {
    "LOG_LEVEL": ("INFO", r"^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$"),
    "ENVIRONMENT": ("dev", r"^(dev|staging|prod)$"),
}

class ConfigError(Exception):
    pass

def validate_env() -> None:
    errors: List[str] = []
    for key, pattern in REQUIRED_ENV.items():
        val = os.getenv(key, "")
        if not re.match(pattern, val or ""):
            errors.append(f"{key} is missing or invalid")
    for key, (default, pattern) in OPTIONAL_ENV.items():
        val = os.getenv(key, default)
        if not re.match(pattern, val or ""):
            errors.append(f"{key} value '{val}' invalid; expected {pattern}")
    if errors:
        raise ConfigError("Config validation failed:\n- " + "\n- ".join(errors))
