from __future__ import annotations
import json, math, random
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Tuple

@dataclass
class ArmState:
    # LinUCB parameters
    A: List[List[float]]  # dxd
    b: List[float]        # dx1
    pulls: int = 0

class LinUCB:
    def __init__(self, actions: List[str], d: int, alpha: float = 0.8, path: str = "db/tao_linucb.json"):
        self.actions = actions
        self.d = d
        self.alpha = alpha
        self.path = Path(path)
        self.state: Dict[str, ArmState] = {}
        for a in actions:
            A = [[0.0]*d for _ in range(d)]
            for i in range(d): A[i][i] = 1.0  # Identity
            b = [0.0]*d
            self.state[a] = ArmState(A=A, b=b, pulls=0)
        self._load()

    def _load(self):
        if self.path.exists():
            data = json.loads(self.path.read_text())
            for a, st in data.items():
                self.state[a] = ArmState(A=st["A"], b=st["b"], pulls=st.get("pulls",0))

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {a: asdict(st) for a, st in self.state.items()}
        self.path.write_text(json.dumps(data))

    @staticmethod
    def _mat_vec(A, x):
        return [sum(A[i][j]*x[j] for j in range(len(x))) for i in range(len(A))]

    @staticmethod
    def _mat_inv(A):
        # Simple Gauss-Jordan for small d
        n = len(A)
        M = [row[:] for row in A]
        I = [[1.0 if i==j else 0.0 for j in range(n)] for i in range(n)]
        for i in range(n):
            pivot = M[i][i] if M[i][i] != 0 else 1e-8
            r = 1.0/pivot
            for j in range(n):
                M[i][j] *= r
                I[i][j] *= r
            for k in range(n):
                if k==i: continue
                factor = M[k][i]
                for j in range(n):
                    M[k][j] -= factor*M[i][j]
                    I[k][j] -= factor*I[i][j]
        return I

    @staticmethod
    def _vec_add(a, b):
        return [a[i]+b[i] for i in range(len(a))]

    @staticmethod
    def _outer(x, y):
        n = len(x); m = len(y)
        return [[x[i]*y[j] for j in range(m)] for i in range(n)]

    def select(self, context: List[float]) -> str:
        # Compute ucb for each action
        best_a, best_ucb = None, -1e9
        for a, st in self.state.items():
            invA = self._mat_inv(st.A)
            theta = self._mat_vec(invA, st.b)
            # p = theta^T x + alpha * sqrt(x^T inv(A) x)
            mean = sum(theta[i]*context[i] for i in range(self.d))
            # variance
            Ax = self._mat_vec(invA, context)
            var = sum(context[i]*Ax[i] for i in range(self.d))
            ucb = mean + self.alpha*math.sqrt(max(var, 1e-9))
            if ucb > best_ucb:
                best_ucb = ucb; best_a = a
        return best_a or self.actions[0]

    def update(self, action: str, context: List[float], reward: float):
        st = self.state[action]
        # A <- A + x x^T ; b <- b + r x
        outer = self._outer(context, context)
        for i in range(self.d):
            for j in range(self.d):
                st.A[i][j] += outer[i][j]
        for i in range(self.d):
            st.b[i] += reward*context[i]
        st.pulls += 1
        self._save()


class TAOAgent:
    """ High-level wrapper for decision making.
    Actions: strategies or routes like ["sor-fast", "sor-cheap", "hedge-tight"]
    Context: [vol, spread_bps, book_speed, latency_ms, fee_bps, slip_est_bps, pnl_rolling_bps]
    Reward: realized_pnl_bps - penalty(latency/reject)
    """
    def __init__(self, actions: List[str]):
        self.d = 7
        self.actions = actions
        self.bandit = LinUCB(actions, d=self.d, alpha=0.8)

    def decide(self, context: Dict[str, float]) -> str:
        x = [context.get(k, 0.0) for k in [
            "vol", "spread_bps", "book_speed", "latency_ms", "fee_bps", "slip_est_bps", "pnl_rolling_bps"
        ]]
        return self.bandit.select(x)

    def feedback(self, action: str, context: Dict[str, float], pnl_bps: float, reject_penalty_bps: float=0.0):
        reward = pnl_bps - reject_penalty_bps
        x = [context.get(k, 0.0) for k in [
            "vol", "spread_bps", "book_speed", "latency_ms", "fee_bps", "slip_est_bps", "pnl_rolling_bps"
        ]]
        self.bandit.update(action, x, reward)
