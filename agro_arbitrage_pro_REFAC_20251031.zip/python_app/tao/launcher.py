import time
from loguru import logger
from python_app.tao.agent import TAOAgent
from python_app.core.sor import VenueQuote, choose
from python_app.core.adaptive_pricer import AdaptivePricer, BookTop
from python_app.core.hedge_dagger import OrphanHedge
from python_app.core.rate_limit_manager import RateLimiter
from python_app.core.fee_engine import FeeProfile, net_edge_bps
from python_app.core.md_quality_gate import MDQualityGate

ACTIONS = ["sor-fast","sor-cheap","hedge-tight"]

class TAOSupervisor:
    def __init__(self):
        self.agent = TAOAgent(ACTIONS)
        self.pricer = AdaptivePricer()
        self.hedge = OrphanHedge(sender=self)
        self.rl = RateLimiter()
        self.md_gate = MDQualityGate(max_seq_gap=2, max_stale_ms=800)

        # Example RL buckets
        self.rl.register("binance","/api/v3/order", capacity=10, refill=10)
        self.rl.register("okx","/api/v5/trade/order", capacity=8, refill=8)

    # placeholder close function for OrphanHedge
    def close_orphan(self, leg_state):
        logger.warning(f"Closing orphan leg: {leg_state}")

    def observe(self) -> dict:
        # In prod, replace with real metrics/MD snapshots
        obs = {
            "vol": 0.02, "spread_bps": 3.5, "book_speed": 15.0,
            "latency_ms": 12.0, "fee_bps": 2.0, "slip_est_bps": 1.0,
            "pnl_rolling_bps": 0.5
        }
        return obs

    def route(self, action: str, side: str, top: BookTop):
        # Build venue candidates
        venues = [
            VenueQuote("binance", bid=top.bid, ask=top.ask, latency_ms=12, taker_fee_bps=2.0, expected_slip_bps=1.0),
            VenueQuote("okx", bid=top.bid, ask=top.ask, latency_ms=9, taker_fee_bps=1.8, expected_slip_bps=1.1),
        ]
        edge_bps = (top.bid/top.ask - 1.0)*10_000.0 if side.upper()=="SELL" else (top.ask/top.bid - 1.0)*10_000.0
        if action == "sor-fast":
            venue = choose(venues, side, edge_bps + 0.5)  # favor low latency
        elif action == "sor-cheap":
            venue = choose(venues, side, edge_bps + 0.1)  # favor low fees
        else:
            venue = choose(venues, side, edge_bps)

        px = self.pricer.limit_price(side, top)
        return venue, px

    def loop_once(self):
        obs = self.observe()
        action = self.agent.decide(obs)

        # mock top-of-book
        top = BookTop(bid=100.0, ask=100.2, bid_qty=2.0, ask_qty=1.8, mid_volatility=obs["vol"], book_speed=obs["book_speed"])
        if not self.md_gate.on_delta(seq=1, ts_ms=int(time.time()*1000)):
            logger.warning("MD gate blocked entry")
            return

        side = "BUY"
        venue, price = self.route(action, side, top)

        # TODO: call execution gateway here; we simulate a result
        filled = True
        pnl_bps = 0.8
        reject_penalty = 0.0 if filled else 3.0

        self.agent.feedback(action, obs, pnl_bps, reject_penalty)
        logger.info(f"TAO action={action} venue={venue} price={price} pnl_bps={pnl_bps}")

    def run(self, steps=10, sleep_s=0.1):
        for _ in range(steps):
            self.loop_once()
            time.sleep(sleep_s)

if __name__ == "__main__":
    TAOSupervisor().run()
