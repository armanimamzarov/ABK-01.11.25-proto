
import uuid, time, hashlib, random

def order_uuid(prefix: str, legs:int=1)->str:
    base = f"{prefix}:{time.time_ns()}:{random.random()}:{legs}:{uuid.uuid4()}"
    return hashlib.sha256(base.encode()).hexdigest()[:24]
