from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional, List, Protocol
import time

@dataclass
class MarketSnapshot:
    bid: float
    bid_qty: float
    ask: float
    ask_qty: float
    ts_ms: int
    latency_ms: float

class MarketDataProvider(Protocol):
    def get_snapshot(self, venue: str, symbol: str) -> Optional[MarketSnapshot]: ...

class FeeProvider(Protocol):
    def taker_fee_bps(self, venue: str, symbol: str) -> float: ...
    def maker_fee_bps(self, venue: str, symbol: str) -> float: ...

class BackpressureProvider(Protocol):
    def backlog(self, venue: str, symbol: str) -> int: ...
    def rate_ok(self, venue: str) -> bool: ...

class BestVenueRouter:
    def __init__(self, cfg: dict, md: MarketDataProvider, fee: FeeProvider, bp: BackpressureProvider):
        rcfg = cfg.get("router", {})
        w = rcfg.get("weights", {})
        self.w_spread = float(w.get("spread_bps", 1.0))
        self.w_qty = float(w.get("top_qty", 0.5))
        self.w_fee = float(w.get("fee_bps", 0.7))
        self.w_lat = float(w.get("latency_ms", 0.3))
        self.candidates_default = list(rcfg.get("candidates", []))
        self.require_levels = int(rcfg.get("require_depth_levels", 1))
        self.fallback_backoff_ms = int(rcfg.get("fallback_on_rl_backoff_ms", 250))
        self.max_skew_ms = int(rcfg.get("max_skew_ms", 50))

        self.md = md
        self.fee = fee
        self.bp = bp

    def _score(self, venue: str, symbol: str, side: str, snap: MarketSnapshot) -> float:
        if snap.ask <= 0 or snap.bid <= 0 or snap.ask <= snap.bid:
            return float("-inf")
        spread_bps = (snap.ask - snap.bid) / ((snap.ask + snap.bid)/2.0) * 1e4
        top_qty = snap.ask_qty if side == "BUY" else snap.bid_qty
        fee_bps = self.fee.taker_fee_bps(venue, symbol)
        latency_ms = float(snap.latency_ms)

        score = - self.w_spread * spread_bps + self.w_qty * top_qty - self.w_fee * fee_bps - self.w_lat * latency_ms

        now_ms = int(time.time() * 1000)
        skew = abs(now_ms - snap.ts_ms)
        if skew > self.max_skew_ms:
            score -= 1e6
        backlog = self.bp.backlog(venue, symbol)
        score -= min(backlog, 1000) * 1.0
        return score

    def choose(self, symbol: str, side: str, candidates: Optional[List[str]] = None) -> str:
        venues = candidates or self.candidates_default or []
        best_v = None
        best_s = float("-inf")

        for v in venues:
            if not self.bp.rate_ok(v):
                continue
            snap = self.md.get_snapshot(v, symbol)
            if not snap:
                continue
            s = self._score(v, symbol, side, snap)
            if s > best_s:
                best_s, best_v = s, v

        if best_v is None:
            time.sleep(self.fallback_backoff_ms/1000.0)
            return venues[0] if venues else ""
        return best_v
