import aiohttp, asyncio, uuid, time
from ..config import load_config
from ..metrics import ORDERS_SENT

class GatewayClient:
    def __init__(self, base_url: str):
        self.base_url = base_url

    async def submit_order(self, exchange: str, symbol: str, side: str, qty: float, price: float | None):
        # Here we just simulate the send and increment metrics
        client_order_id = str(uuid.uuid4())
        ORDERS_SENT.inc()
        await asyncio.sleep(0.01)
        return {"client_order_id": client_order_id, "status": "submitted"}

async def demo():
    cfg = load_config()
    gw = GatewayClient("http://rust_core:8080")
    await gw.submit_order("MOCK","BTCUSDT","buy",1.0, None)

if __name__ == "__main__":
    asyncio.run(demo())
