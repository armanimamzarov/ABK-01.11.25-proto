import time
import threading
import queue
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, Optional, Tuple, Callable
from prometheus_client import Counter, Gauge, Histogram, start_http_server

class OrderState(Enum):
    PENDING_NEW = auto()
    ACK = auto()
    PARTIAL = auto()
    FILLED = auto()
    CANCELED = auto()
    REJECT = auto()

class Category(Enum):
    RATE_LIMIT = "RATE_LIMIT"
    INSUFF_MARGIN = "INSUFF_MARGIN"
    INVALID_PRICE_STEP = "INVALID_PRICE_STEP"
    DUPLICATE = "DUPLICATE"
    NETWORK = "NETWORK"
    UNKNOWN = "UNKNOWN"

REJECT_NORMALIZATION = {
    # exchange_code -> Category
    "TOO_MANY_REQUESTS": Category.RATE_LIMIT,
    "INSUFFICIENT_BALANCE": Category.INSUFF_MARGIN,
    "PRICE_FILTER": Category.INVALID_PRICE_STEP,
    "DUPLICATE_ORDER": Category.DUPLICATE,
    "NETWORK_ERROR": Category.NETWORK,
}

order_ack_ms = Histogram("order_ack_ms", "Milliseconds from submit to ack")
reject_total = Counter("order_reject_total", "Total rejects", ["code", "category"])
partial_hedge_total = Counter("partial_hedge_total", "Auto-hedge operations total")
orphan_leg_seconds = Histogram("orphan_leg_seconds", "Seconds of orphan legs before hedge")
latency_exec_ms = Histogram("latency_exec_ms", "End-to-end execution latency (ms)")

@dataclass(order=True)
class PrioritizedOrder:
    priority: int
    ts_ns: int
    client_id: str=field(compare=False)

@dataclass
class Order:
    client_id: str
    exchange: str
    symbol: str
    side: str
    qty: float
    price: float
    reduce_only: bool = False
    hedge: bool = False
    tif: str = "IOC"
    priority: int = 0
    state: OrderState = OrderState.PENDING_NEW
    created_ns: int = field(default_factory=lambda: time.time_ns())
    ack_ns: Optional[int] = None
    filled_qty: float = 0.0
    orphan_timer_s: float = 2.0

class IdempotencyStore:
    def __init__(self):
        self._seen: Dict[str, str] = {}
        self._lock = threading.Lock()
    def get_or_put(self, key: str) -> str:
        with self._lock:
            if key in self._seen:
                return self._seen[key]
            val = str(uuid.uuid4())
            self._seen[key] = val
            return val

class ExecutionGateway:
    def __init__(self, send_func: Callable[[Order], Tuple[bool, str, str]], metrics_port: int = 9200):
        self.idem = IdempotencyStore()
        self.queues: Dict[Tuple[str,str], "queue.PriorityQueue[PrioritizedOrder]"] = {}
        self.orders: Dict[str, Order] = {}
        self._locks: Dict[Tuple[str,str], threading.Lock] = {}
        self._send = send_func
        self._stop = False
        start_http_server(metrics_port)
    def _key(self, ex: str, sym: str): return (ex, sym)
    def _q(self, ex: str, sym: str):
        k = self._key(ex, sym)
        if k not in self.queues:
            self.queues[k] = queue.PriorityQueue()
            self._locks[k] = threading.Lock()
            t = threading.Thread(target=self._worker, args=k, daemon=True)
            t.start()
        return self.queues[k]
    def submit(self, order: Order) -> str:
        idem_key = f"{order.exchange}:{order.symbol}:{order.side}:{order.qty}:{order.price}"
        coid = self.idem.get_or_put(idem_key)
        order.client_id = coid
        self.orders[coid] = order
        q = self._q(order.exchange, order.symbol)
        q.put(PrioritizedOrder(order.priority, time.time_ns(), coid))
        return coid
    def cancel(self, client_id: str) -> None:
        # Soft-cancel by marking desired state; worker will enforce cancel-on-fail
        if client_id in self.orders:
            self.orders[client_id].state = OrderState.CANCELED
    def stop(self): self._stop = True
    def _normalize_reject(self, code: str) -> Category:
        return REJECT_NORMALIZATION.get(code, Category.UNKNOWN)
    def _worker(self, ex: str, sym: str):
        k = self._key(ex, sym)
        while not self._stop:
            try:
                item = self.queues[k].get(timeout=0.1)
            except queue.Empty:
                continue
            client_id = item.client_id
            order = self.orders.get(client_id)
            if not order:
                continue
            if order.state == OrderState.CANCELED:
                continue
            start = time.time()
            ok, rej_code, rej_text = self._send(order)
            if ok:
                order.ack_ns = time.time_ns()
                order.state = OrderState.ACK
                order_ack_ms.observe((order.ack_ns - order.created_ns)/1e6)
            else:
                cat = self._normalize_reject(rej_code)
                reject_total.labels(code=rej_code, category=cat.value).inc()
                # Retry rules (deterministic): RATE_LIMIT/NETWORK → up to 3 retries with backoff; others cancel
                if cat in (Category.RATE_LIMIT, Category.NETWORK):
                    for i in range(3):
                        time.sleep(0.05 * (i+1))
                        ok2, rc2, rt2 = self._send(order)
                        if ok2:
                            order.ack_ns = time.time_ns()
                            order.state = OrderState.ACK
                            order_ack_ms.observe((order.ack_ns - order.created_ns)/1e6)
                            break
                        else:
                            reject_total.labels(code=rc2, category=self._normalize_reject(rc2).value).inc()
                    else:
                        order.state = OrderState.CANCELED
                else:
                    order.state = OrderState.CANCELED
            # Orphan leg control
            if order.hedge and order.state in (OrderState.PARTIAL, OrderState.ACK):
                t0 = time.time()
                time.sleep(order.orphan_timer_s)
                age = time.time() - t0
                orphan_leg_seconds.observe(age)
                # Trigger auto-hedge (simulate as a metric bump)
                partial_hedge_total.inc()
            latency_exec_ms.observe((time.time()-start)*1000.0)
