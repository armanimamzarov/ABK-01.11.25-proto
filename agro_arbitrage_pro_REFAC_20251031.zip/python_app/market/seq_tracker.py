
from __future__ import annotations
from dataclasses import dataclass

@dataclass
class SeqTracker:
    last: int = -1
    skips: int = 0

    def ingest(self, seq: int) -> bool:
        if self.last == -1:
            self.last = seq
            return True
        expected = self.last + 1
        if seq != expected:
            self.skips += abs(seq - expected)
            self.last = seq
            return False
        self.last = seq
        return True
