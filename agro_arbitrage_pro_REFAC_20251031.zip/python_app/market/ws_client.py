
import asyncio, time
import websockets

class WSClient:
    def __init__(self, url, on_msg, on_snapshot, name="md", heartbeat_sec=3, timeout_sec=10, metrics=None, logger=None):
        self.url = url
        self.on_msg = on_msg
        self.on_snapshot = on_snapshot
        self.name = name
        self.heartbeat_sec = heartbeat_sec
        self.timeout_sec = timeout_sec
        self.metrics = metrics
        self.logger = logger

    async def run(self):
        while True:
            try:
                async with websockets.connect(self.url, ping_interval=self.heartbeat_sec, close_timeout=2) as ws:
                    last = time.time()
                    await self.on_snapshot()
                    async for raw in ws:
                        last = time.time()
                        await self.on_msg(raw)
                        if self.metrics:
                            self.metrics.observe_freshness(self.name, "venue", time.time()-last)
            except Exception as e:
                if self.logger: self.logger.warning("ws_reconnect: %s", e)
                await asyncio.sleep(1)
