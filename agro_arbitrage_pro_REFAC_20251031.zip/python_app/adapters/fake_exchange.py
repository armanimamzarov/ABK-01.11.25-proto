import random, time
from typing import Tuple
def send(order) -> Tuple[bool, str, str]:
    # Simulate rate limits and network
    r = random.random()
    if r < 0.05:
        return False, "TOO_MANY_REQUESTS", "rate limited"
    if r < 0.08:
        return False, "NETWORK_ERROR", "temporary network"
    # Accept otherwise
    time.sleep(0.01)
    return True, "", ""
