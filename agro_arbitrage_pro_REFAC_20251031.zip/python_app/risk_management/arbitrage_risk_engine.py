
import asyncio
import grpc
from dataclasses import dataclass
from python_app.risk_management import agro_pb2, agro_pb2_grpc

@dataclass
class RiskClient:
    host: str = "0.0.0.0"
    port: int = 50051
    channel: grpc.aio.Channel | None = None
    stub: agro_pb2_grpc.RiskServiceStub | None = None

    async def connect(self):
        self.channel = grpc.aio.insecure_channel(f"{self.host}:{self.port}")
        self.stub = agro_pb2_grpc.RiskServiceStub(self.channel)

    async def validate(self, strategy, exchange, symbol, side, qty, price, order_type):
        req = agro_pb2.OrderRequest(strategy=strategy, exchange=exchange, symbol=symbol, side=side, qty=qty, price=price, order_type=order_type)
        resp = await self.stub.ValidateOrder(req)
        return resp.allowed, resp.reason
