from __future__ import annotations
import math
import time
import asyncio
from dataclasses import dataclass
from typing import Optional, Dict, Any
from prometheus_client import Counter, Gauge

# === Error classes expected by gateway_v2 ===
class TemporaryError(Exception):
    def __init__(self, message: str, reason: str = "NetworkError"):
        super().__init__(message)
        self.reason = reason

class ValidationError(Exception):
    pass

# === Token bucket for per-endpoint rate limiting ===
class TokenBucket:
    def __init__(self, capacity: float, refill_per_sec: float):
        self.capacity = float(capacity)
        self.tokens = float(capacity)
        self.refill_rate = float(refill_per_sec)
        self.last = time.perf_counter()

    def allow(self, weight: float = 1.0) -> bool:
        now = time.perf_counter()
        elapsed = now - self.last
        self.tokens = min(self.capacity, self.tokens + elapsed * self.refill_rate)
        self.last = now
        if self.tokens >= weight:
            self.tokens -= weight
            return True
        return False

# === Symbol specification & validator ===
@dataclass
class SymbolSpec:
    symbol: str
    price_precision: int
    qty_precision: int
    tick_size: float
    step_size: float
    min_notional: float

    def round_price(self, price: float) -> float:
        if self.tick_size > 0:
            ticks = round(price / self.tick_size)
            return ticks * self.tick_size
        q = 10 ** self.price_precision
        return math.floor(price * q) / q

    def round_qty(self, qty: float) -> float:
        if self.step_size > 0:
            steps = math.floor(qty / self.step_size) * self.step_size
            return steps
        q = 10 ** self.qty_precision
        return math.floor(qty * q) / q

WS_HEARTBEAT_MISSED = Counter("ws_heartbeat_missed_total", "Missed WS heartbeat events", ["venue"])
WS_GAP_COUNTER = Counter("ws_gap_total", "Detected WS sequence gaps", ["venue","symbol"])
WS_RESUBSCRIBE = Counter("ws_resubscribe_total", "Resubscribe attempts", ["venue"])
WS_SNAPSHOT_FETCH = Counter("ws_snapshot_fetch_total", "REST snapshots fetched for gap-fill", ["venue","symbol"])

class BaseExchangeAdapter:
    GAP_MAX_AGE_MS = 250
    # Map venue-specific errors -> reason categories for retry policy
    ERROR_REASON_MAP = {
        "NETWORK": "NetworkError",
        "RATE_LIMIT": "RateLimit",
        "SERVICE_UNAVAILABLE": "ExchangeDown",
    }

    def __init__(self, venue: str, cfg: dict):
        self.venue = venue
        self.cfg = cfg
        vb = self._venue_budget()
        self.bucket = TokenBucket(capacity=vb, refill_per_sec=vb/60.0)
        self.symbols: Dict[str, SymbolSpec] = {}
        self._last_heartbeat = time.monotonic()

    def _venue_budget(self) -> int:
        venues = self.cfg.get("venues", [])
        for v in venues:
            if v.get("name") == self.venue:
                return int(v.get("weight_budget_per_min", 60000))
        return 60000

    async def sleep(self, seconds: float):
        await asyncio.sleep(seconds)

    def now(self) -> float:
        return time.monotonic()

    def update_heartbeat(self):
        # Called on every WS message receipt
        self._last_heartbeat = self.now()

    def heartbeat_stale(self) -> bool:
        # If stale, increment metric for visibility
        if (self.now() - self._last_heartbeat) > int(self.cfg.get('observability', {}).get('ws_heartbeat_sec', 10)):
            WS_HEARTBEAT_MISSED.labels(venue=self.venue).inc()
            return True
        return False

    def mark_missed_heartbeat(self):
        WS_HEARTBEAT_MISSED.labels(venue=self.venue).inc()

    # --- Symbol specification management ---
    def set_symbol_spec(self, spec: SymbolSpec):
        self.symbols[spec.symbol] = spec

    def get_symbol_spec(self, symbol: str) -> SymbolSpec:
        spec = self.symbols.get(symbol)
        if not spec:
            raise ValidationError(f"Unknown symbol: {symbol}")
        return spec

    # --- Validation & normalization ---
    def _validate_order(self, symbol: str, qty: float, price: Optional[float], ord_type: str, flags: list[str]):
        spec = self.get_symbol_spec(symbol)
        if ord_type == "LIMIT":
            if price is None:
                raise ValidationError("LIMIT requires price")
            price_r = spec.round_price(float(price))
            if abs(price_r - price) > 1e-12:
                raise ValidationError(f"Price not aligned to tickSize: {price} -> {price_r}")
            notional = float(price_r) * float(qty)
        else:
            notional = float(price or 0.0) * float(qty)

        qty_r = spec.round_qty(float(qty))
        if abs(qty_r - qty) > 1e-12:
            raise ValidationError(f"Qty not aligned to stepSize: {qty} -> {qty_r}")

        if notional < spec.min_notional:
            raise ValidationError(f"Notional too small: {notional} < {spec.min_notional}")

        if "post_only" in flags and ord_type != "LIMIT":
            raise ValidationError("post_only is only valid for LIMIT orders")

    # --- Public API expected by gateway_v2 ---
    async def send_order(self, client_order_id: str, **payload: Any) -> Dict[str, Any]:
        venue = payload["venue"]
        symbol = payload["symbol"]
        ord_type = payload["ord_type"]
        qty = payload["qty"]
        price = payload.get("price")
        flags = payload.get("flags", [])

        # Validation
        self._validate_order(symbol, qty, price, ord_type, flags)

        # Rate limit
        weight = 1.0  # could be endpoint-specific
        if not self.bucket.allow(weight):
            raise TemporaryError("Rate limit exceeded", reason="RateLimit")

        raise NotImplementedError

    async def bulk_cancel(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        if not self.bucket.allow(1.0):
            raise TemporaryError("Rate limit exceeded", reason="RateLimit")
        raise NotImplementedError

    # Helper to map raw exchange error to retry category
    def map_error_reason(self, raw_code: str) -> str:
        return self.ERROR_REASON_MAP.get(raw_code, 'NetworkError')

    async def notify_gap(self, symbol: str):
        WS_GAP_COUNTER.labels(venue=self.venue, symbol=symbol).inc()
        return

    async def gap_fill_snapshot(self, symbol: str):
        WS_SNAPSHOT_FETCH.labels(venue=self.venue, symbol=symbol).inc()
        raise NotImplementedError
