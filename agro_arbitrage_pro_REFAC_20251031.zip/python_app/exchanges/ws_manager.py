from __future__ import annotations
import asyncio
import time
from dataclasses import dataclass
from typing import Callable, Optional, Dict, Any
from loguru import logger

@dataclass
class WSConfig:
    url: str
    subscribe_payload: dict
    symbol: str
    gap_threshold: int = 1         # any missing seq triggers gap
    ping_interval: float = 10.0
    reconnect_backoff_ms: int = 500
    reconnect_backoff_max_ms: int = 5000

class WebSocketManager:
    """Generic WS manager with reconnect, ping, and sequence gap detection.
    adapter must provide:
      - update_heartbeat()
      - notify_gap(symbol)
      - gap_fill_snapshot(symbol)  # optional, called by user on gap
    """
    def __init__(self, adapter, ws_impl):
        self.adapter = adapter      # BaseExchangeAdapter subclass
        self.ws_impl = ws_impl      # object with connect(url), send(json), recv() -> dict, close()
        self._seq = None
        self._task = None
        self._stop = False

    def _gap(self, seq: int) -> bool:
        return self._seq is not None and seq != self._seq + 1

    async def run(self, cfg: WSConfig):
        backoff = cfg.reconnect_backoff_ms / 1000.0
        while not self._stop:
            try:
                await self.ws_impl.connect(cfg.url)
                await self.ws_impl.send(cfg.subscribe_payload)
                self.adapter.update_heartbeat()
                self._seq = None
                logger.info(f"[ws] connected {cfg.url}")
                # reader loop
                while not self._stop:
                    msg = await self.ws_impl.recv()
                    if msg is None:
                        await asyncio.sleep(0.01)
                        continue
                    self.adapter.update_heartbeat()
                    seq = msg.get("u") or msg.get("seq") or msg.get("E")  # venue-specific
                    if seq is not None:
                        try:
                            seq = int(seq)
                        except Exception:
                            seq = None
                    if seq is not None and self._gap(seq):
                        logger.warning(f"[ws] gap detected: expected {self._seq+1} got {seq}")
                        await self.adapter.notify_gap(cfg.symbol)
                    if seq is not None:
                        self._seq = seq
                    # user handler can be invoked here if needed
                await self.ws_impl.close()
            except Exception as e:
                logger.error(f"[ws] error: {e}")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, cfg.reconnect_backoff_max_ms / 1000.0)

    async def stop(self):
        self._stop = True
        try:
            await self.ws_impl.close()
        except Exception:
            pass
