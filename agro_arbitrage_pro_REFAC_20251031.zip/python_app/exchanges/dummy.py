
from ..engine.execution_gateway import DummyExchange
get = lambda: DummyExchange()
