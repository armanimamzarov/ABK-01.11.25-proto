from __future__ import annotations
import aiohttp
from typing import Optional, Dict, Any
from .base import BaseExchangeAdapter, TemporaryError, ValidationError, SymbolSpec, WS_RESUBSCRIBE
from .ws_manager import WebSocketManager, WSConfig

class BinanceAdapter(BaseExchangeAdapter):
    BASE_URL = "https://api.binance.com"
    WS_URL = "wss://stream.binance.com:9443/stream"

    def __init__(self, venue: str, cfg: dict):
        super().__init__(venue, cfg)
        self.ws = None

    async def _http_get(self, session: aiohttp.ClientSession, path: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
        url = self.BASE_URL + path
        try:
            async with session.get(url, params=params or {}, timeout=5) as resp:
                if resp.status == 429:
                    raise TemporaryError("HTTP 429", reason="RateLimit")
                if resp.status >= 500:
                    raise TemporaryError(f"HTTP {resp.status}", reason="ExchangeDown")
                return await resp.json()
        except aiohttp.ClientError as e:
            raise TemporaryError(str(e), reason="NetworkError") from e

    async def _http_post(self, session: aiohttp.ClientSession, path: str, data: Dict[str, Any]) -> Dict[str, Any]:
        url = self.BASE_URL + path
        try:
            async with session.post(url, json=data, timeout=5) as resp:
                if resp.status == 429:
                    raise TemporaryError("HTTP 429", reason="RateLimit")
                if resp.status >= 500:
                    raise TemporaryError(f"HTTP {resp.status}", reason="ExchangeDown")
                js = await resp.json()
                if "code" in js and js["code"] != 0:
                    code = str(js.get("code"))
                    if code in {"-1013","-1111","-1116","-1117"}:
                        raise ValidationError(str(js))
                    raise TemporaryError(str(js), reason=self.map_error_reason(code))
                return js
        except aiohttp.ClientError as e:
            raise TemporaryError(str(e), reason="NetworkError") from e

    async def send_order(self, client_order_id: str, **payload: Any) -> Dict[str, Any]:
        await super().send_order(client_order_id, **payload)  # validation + RL
        req = {
            "symbol": payload["symbol"],
            "side": payload["side"],
            "type": payload["ord_type"],
            "timeInForce": payload["tif"],
            "quantity": payload["qty"],
            "price": payload.get("price"),
            "newClientOrderId": client_order_id,
        }
        flags = payload.get("flags", [])
        if "post_only" in flags:
            # Note: actual post-only differs per market; example for illustration
            req["timeInForce"] = "GTX"
        if "reduce_only" in flags:
            req["reduceOnly"] = True

        async with aiohttp.ClientSession() as s:
            # Note: choose correct endpoint based on spot/margin/futures
            return await self._http_post(s, "/api/v3/order", req)

    async def bulk_cancel(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        sym = symbol or "ALL"
        async with aiohttp.ClientSession() as s:
            resp = await self._http_post(s, "/api/v3/openOrders/cancelAll", {"symbol": sym})
            return {"count": len(resp.get("orders", []))}

    # --- WS/GAP-FILL ---
    async def start_book_stream(self, symbol: str):
        """Start a single-symbol book stream with gap detection."""
        stream = f"{symbol.lower()}@bookTicker"
        payload = {"method":"SUBSCRIBE","params":[stream],"id":1}
        cfg = WSConfig(url=self.WS_URL, subscribe_payload=payload, symbol=symbol, gap_threshold=1)
        # ws_impl must be an object with connect/send/recv/close; provide your implementation
        self.ws = WebSocketManager(self, ws_impl=YourWSImpl())  # TODO: replace with real WS client
        await self.ws.run(cfg)

    async def notify_gap(self, symbol: str):
        await super().notify_gap(symbol)
        WS_RESUBSCRIBE.labels(venue=self.venue).inc()
        # simple strategy: fetch REST snapshot, then continue stream
        await self.gap_fill_snapshot(symbol)

    async def gap_fill_snapshot(self, symbol: str):
        await super().gap_fill_snapshot(symbol)
        # Fetch depth snapshot and realign your local book here
        # Example GET: /api/v3/depth?symbol=BTCUSDT&limit=1000
        # After snapshot, apply buffered WS updates if you store them
        return

# Placeholder WS implementation for illustration.
class YourWSImpl:
    async def connect(self, url: str): ...
    async def send(self, payload): ...
    async def recv(self) -> dict: ...
    async def close(self): ...
