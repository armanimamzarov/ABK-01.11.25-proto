
import time, hmac, hashlib, json, os
import httpx
from loguru import logger
from pathlib import Path

EX_CFG = json.loads(Path("configs/exchanges.json").read_text())

class BaseExchange:
    def __init__(self, name):
        self.name = name
        self.cfg = EX_CFG[name]
        self.client = httpx.AsyncClient(timeout=10)

    async def place_order(self, symbol, side, qty, price=None, order_type="LIMIT"):
        live = json.loads(Path("configs/risk_management.json").read_text())["live_trading"]
        if not live:
            oid = f"paper-{int(time.time()*1000)}"
            logger.info(f"[PAPER] {self.name} {symbol} {side} {qty} {order_type} @{price} -> {oid}")
            return {"status":"paper_filled","order_id":oid}
        raise NotImplementedError("Live trading not enabled. Set live_trading=true and implement signed REST for this exchange.")

    async def cancel_order(self, order_id, symbol):
        logger.info(f"Cancel {order_id} on {self.name}")
        return {"status":"canceled","order_id":order_id}

    async def fetch_balance(self):
        return {}

    async def subscribe_depth(self, symbol):
        return

class MEXCExchange(BaseExchange):
    def __init__(self):
        super().__init__('mexc')
