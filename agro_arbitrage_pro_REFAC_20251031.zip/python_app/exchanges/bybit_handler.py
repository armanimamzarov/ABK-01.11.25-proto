
import time, hmac, hashlib, json
import httpx
from loguru import logger
from pathlib import Path

EX_CFG = json.loads(Path("configs/exchanges.json").read_text())

class BybitExchange:
    def __init__(self):
        self.name = "bybit"
        self.cfg = EX_CFG[self.name]
        self.client = httpx.AsyncClient(timeout=15)

    def _headers(self, payload=""):
        ts = str(int(time.time() * 1000))
        sign_str = ts + self.cfg["api_key"] + payload
        sig = hmac.new(self.cfg["api_secret"].encode(), sign_str.encode(), hashlib.sha256).hexdigest()
        return {
            "X-BAPI-API-KEY": self.cfg["api_key"],
            "X-BAPI-TIMESTAMP": ts,
            "X-BAPI-SIGN": sig,
            "Content-Type": "application/json"
        }

    async def place_order(self, symbol, side, qty, price=None, order_type="LIMIT"):
        live = json.loads(Path("configs/risk_management.json").read_text())["live_trading"]
        if not live:
            oid = f"paper-{int(time.time()*1000)}"
            logger.info(f"[PAPER] bybit {symbol} {side} {qty} {order_type} @{price} -> {oid}")
            return {"status":"paper_filled","order_id":oid}

        url = f"{self.cfg['base_url']}/v5/order/create"
        body = {
            "category": "spot",
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
            "qty": f"{qty:.8f}",
        }
        if order_type == "LIMIT":
            body["price"] = f"{price:.8f}"
        headers = self._headers(json.dumps(body))
        r = await self.client.post(url, headers=headers, json=body)
        r.raise_for_status()
        data = r.json()
        return {"status":"NEW","order_id": data.get("result",{}).get("orderId")}

    async def cancel_order(self, order_id, symbol):
        url = f"{self.cfg['base_url']}/v5/order/cancel"
        body = {"category":"spot","symbol":symbol,"orderId":order_id}
        headers = self._headers(json.dumps(body))
        r = await self.client.post(url, headers=headers, json=body)
        r.raise_for_status()
        return {"status":"canceled","order_id":order_id}

    async def fetch_balance(self):
        url = f"{self.cfg['base_url']}/v5/account/wallet-balance"
        body = {"accountType":"UNIFIED"}
        headers = self._headers(json.dumps(body))
        r = await self.client.post(url, headers=headers, json=body)
        r.raise_for_status()
        return r.json()
