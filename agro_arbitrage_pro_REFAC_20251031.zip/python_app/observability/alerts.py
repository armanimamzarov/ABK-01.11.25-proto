
import asyncio, json, os
from pathlib import Path
import aiohttp
from loguru import logger

_cfg = json.loads(Path("configs/telegram.json").read_text())
TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", _cfg.get("bot_token",""))
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", _cfg.get("chat_id",""))

async def send(text: str):
    if not TOKEN or not CHAT_ID:
        return
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    async with aiohttp.ClientSession() as s:
        try:
            await s.post(url, json={"chat_id": CHAT_ID, "text": text})
        except Exception as e:
            logger.warning(f"Telegram send failed: {e}")
