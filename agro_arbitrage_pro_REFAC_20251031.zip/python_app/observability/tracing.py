
import logging
from loguru import logger
import logging
logger = logging.getLogger(__name__)

def setup_logging():
    logger.remove()
    logger.add(lambda msg: print(msg, end=""), level="INFO")