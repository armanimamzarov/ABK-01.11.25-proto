
from prometheus_client import Counter, Histogram, Gauge

order_rtt_ms = Histogram("order_rtt_ms", "Order round-trip time (ms)")
order_reject_total = Counter("order_reject_total", "Order rejects", ["venue"])
book_seq_skips_total = Counter("book_seq_skips_total", "Missed orderbook sequence numbers", ["name","venue"])
ws_freshness_seconds = Gauge("ws_freshness_seconds", "Age of last WS message", ["name","venue"])
md_latency_venue_to_ingest_ms = Histogram("md_latency_venue_to_ingest_ms", "Venue->ingest latency (ms)")
md_latency_ingest_to_strategy_ms = Histogram("md_latency_ingest_to_strategy_ms", "Ingest->strategy latency (ms)")

def observe_freshness(name, venue, seconds):
    ws_freshness_seconds.labels(name=name, venue=venue).set(seconds)
