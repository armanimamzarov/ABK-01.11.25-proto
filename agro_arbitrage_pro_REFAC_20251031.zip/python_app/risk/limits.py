from dataclasses import dataclass

@dataclass
class RiskCaps:
    max_net_notional_usd: float
    max_symbol_notional_usd: float
    max_open_orders: int
    max_order_rate_per_sec: int

def caps_from_cfg(cfg: dict) -> RiskCaps:
    r = cfg.get("risk", {})
    exec_cfg = cfg.get("execution", {})
    rate = exec_cfg.get("per_symbol_backpressure", {}).get("max_order_rate_per_sec", 20)
    return RiskCaps(
        max_net_notional_usd=float(r.get("max_net_notional_usd", 0.0)),
        max_symbol_notional_usd=float(r.get("max_symbol_notional_usd", 0.0)),
        max_open_orders=int(r.get("max_open_orders", 0)),
        max_order_rate_per_sec=int(rate),
    )
