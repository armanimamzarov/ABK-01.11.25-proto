from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional
import time
from prometheus_client import Counter, Gauge
from loguru import logger
from .limits import caps_from_cfg, RiskCaps

REJECT_BURST = Counter("risk_reject_burst_total", "Number of bursts where reject-rate exceeded window", [])
KILL_SWITCH = Counter("risk_kill_switch_total", "Kill switch activations", ["reason"])
ORDER_RATE = Gauge("risk_order_rate_per_sec", "Observed order rate", ["venue","symbol"])
OPEN_ORDERS = Gauge("risk_open_orders", "Open orders", ["venue","symbol"])

@dataclass
class Telemetry:
    reject_rate_pct: float
    ack_p99_ms: float
    ws_gaps: int
    intraday_dd_pct: float

class RiskGuard:
    """Hard caps & kill-switch supervisor.
    Requires portfolio object with: net_notional_usd(), symbol_notional_usd(symbol), open_orders(venue,symbol), order_rate(venue,symbol).
    """
    def __init__(self, cfg: dict, portfolio, kill_hook, degrade_hook):
        self.cfg = cfg
        self.caps: RiskCaps = caps_from_cfg(cfg)
        self.portfolio = portfolio
        self.kill_hook = kill_hook
        self.degrade_hook = degrade_hook
        self._last_kill = None

        kcfg = cfg.get("risk", {}).get("kill_switch", {})
        self.reject_rate_thresh = float(kcfg.get("reject_rate_pct_window", 2.0))
        self.ack_p99_ms_thresh = float(kcfg.get("ack_p99_ms", 1200))
        self.ws_gap_thresh = int(kcfg.get("ws_gap_threshold", 5))
        self.dd_thresh = float(kcfg.get("intraday_dd_pct", 3.0))

    def _viol(self, cond: bool, reason: str) -> None:
        if cond:
            logger.error(f"[RISK] violation: {reason}")
            self._kill(reason)

    def _kill(self, reason: str) -> None:
        KILL_SWITCH.labels(reason=reason).inc()
        try:
            self.kill_hook(reason)  # should flatten & cancel
        except Exception as e:
            logger.exception(f"Kill hook failed: {e}")

    def _degrade(self, reason: str) -> None:
        try:
            self.degrade_hook(reason)  # e.g., disable aggressive strats
        except Exception as e:
            logger.exception(f"Degrade hook failed: {e}")

    # --- Pre-trade checks ---
    def pre_order(self, venue: str, symbol: str, side: str, qty: float, price: float):
        notional = float(abs(qty) * price)
        net = self.portfolio.net_notional_usd()
        sym = self.portfolio.symbol_notional_usd(symbol)
        open_ord = self.portfolio.open_orders(venue, symbol)
        rate = self.portfolio.order_rate(venue, symbol)

        ORDER_RATE.labels(venue=venue, symbol=symbol).set(rate)
        OPEN_ORDERS.labels(venue=venue, symbol=symbol).set(open_ord)

        self._viol(net + notional > self.caps.max_net_notional_usd, f"net cap breached: {net + notional:.2f} > {self.caps.max_net_notional_usd}")
        self._viol(sym + notional > self.caps.max_symbol_notional_usd, f"symbol cap breached: {sym + notional:.2f} > {self.caps.max_symbol_notional_usd}")
        self._viol(open_ord + 1 > self.caps.max_open_orders, f"open orders cap breached: {open_ord + 1} > {self.caps.max_open_orders}")
        self._viol(rate + 1 > self.caps.max_order_rate_per_sec, f"order rate cap breached: {rate + 1} > {self.caps.max_order_rate_per_sec}")

    # --- Control loop (called periodically) ---
    def control_loop(self, tel: Telemetry):
        if tel.reject_rate_pct > self.reject_rate_thresh:
            REJECT_BURST.inc()
            self._degrade("reject_burst")
        if tel.ack_p99_ms > self.ack_p99_ms_thresh:
            self._degrade("latency")
        if tel.ws_gaps > self.ws_gap_thresh:
            self._kill("ws_gaps")
        if tel.intraday_dd_pct > self.dd_thresh:
            self._kill("drawdown")
