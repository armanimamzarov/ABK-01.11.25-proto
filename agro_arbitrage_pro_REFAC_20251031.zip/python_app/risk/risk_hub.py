
from __future__ import annotations
from dataclasses import dataclass
from typing import Set

@dataclass
class Caps:
    notional_max: float
    orders_per_sec: int
    banlist: Set[str]
    fat_finger_mult: float

class RiskHub:
    def __init__(self, caps: Caps, get_midprice):
        self.caps = caps
        self.get_midprice = get_midprice
        self._order_timestamps = []

    def pre_trade(self, venue: str, symbol: str, side: str, qty: float, price: float) -> bool:
        if symbol in self.caps.banlist:
            return False
        now = __import__('time').time()
        self._order_timestamps = [t for t in self._order_timestamps if now-t < 1.0]
        if len(self._order_timestamps) >= self.caps.orders_per_sec:
            return False
        self._order_timestamps.append(now)
        notional = qty * (price or self.get_midprice(symbol))
        if notional > self.caps.notional_max:
            return False
        mid = self.get_midprice(symbol)
        if price and (abs(price-mid) / mid) > self.caps.fat_finger_mult:
            return False
        return True
