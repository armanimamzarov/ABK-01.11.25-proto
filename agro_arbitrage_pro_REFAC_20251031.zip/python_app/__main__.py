from .metrics import serve_metrics
import asyncio

if __name__ == "__main__":
    asyncio.run(serve_metrics())
