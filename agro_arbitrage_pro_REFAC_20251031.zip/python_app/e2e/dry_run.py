import asyncio, random, uuid, time, logging
from ..execution.gateway_client import GatewayClient
from ..metrics import ORDERS_SENT
from ..config import load_config

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("e2e")

async def scenario_burst(gw: GatewayClient, n: int = 20):
    tasks = []
    for _ in range(n):
        side = random.choice(["buy","sell"])
        tasks.append(gw.submit_order("MOCK","BTCUSDT", side, random.uniform(0.01,0.1), None))
    res = await asyncio.gather(*tasks)
    log.info("burst completed: %d", len(res))

async def main():
    cfg = load_config()
    gw = GatewayClient("http://rust_core:8080")
    await scenario_burst(gw, 50)
    log.info("ORDERS_SENT=%s", ORDERS_SENT._value.get())

if __name__ == "__main__":
    asyncio.run(main())
