
import asyncio, json, os
from pathlib import Path
from loguru import logger
from python_telegram_bot import __version__ as ptb_version  # not used but ensures package present
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

cfg = json.loads(Path("configs/telegram.json").read_text())
TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "replace_me")
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "replace_me")

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("AGRO v6 alive")

async def pnl(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("PnL: not implemented in demo")

async def stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Stop signal sent")

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("pnl", pnl))
    app.add_handler(CommandHandler("stop", stop))
    app.run_polling()

if __name__ == "__main__":
    main()
