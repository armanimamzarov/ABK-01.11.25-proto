import asyncio, os, json, time
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import Message
import asyncpg
import aiohttp
from prometheus_client import CollectorRegistry, Gauge, generate_latest, CONTENT_TYPE_LATEST
from aiohttp import web

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
PG_DSN = f"postgresql://{os.getenv('POSTGRES_USER','agro')}:{os.getenv('POSTGRES_PASSWORD','secret')}@{os.getenv('POSTGRES_HOST','postgres')}:{os.getenv('POSTGRES_PORT','5432')}/{os.getenv('POSTGRES_DB','agro')}"

registry = CollectorRegistry()
g_latency = Gauge("agro_python_panel_latency_ms","Python panel computed latency", registry=registry)
g_drawdown = Gauge("agro_drawdown_pct","Current drawdown, %", registry=registry)
g_pnl = Gauge("agro_pnl_total","Total PnL", registry=registry)

routes = web.RouteTableDef()

@routes.get("/metrics")
async def metrics(_):
    return web.Response(body=generate_latest(registry), content_type=CONTENT_TYPE_LATEST)

@routes.get("/health")
async def health(_):
    return web.json_response({"status": "ok", "ts": time.time()})

async def compute_pnl(conn):
    row = await conn.fetchrow("SELECT COALESCE(SUM(pnl),0) AS pnl FROM pnl_history;")
    return float(row["pnl"])

async def compute_drawdown(conn):
    row = await conn.fetchrow("SELECT COALESCE(MAX(equity),0) AS peak, COALESCE(MIN(equity),0) AS trough FROM equity_curve;")
    peak, trough = float(row["peak"]), float(row["trough"])
    if peak <= 0: return 0.0
    return max(0.0, (peak - trough) / peak * 100.0)

async def pull_rust_latency():
    # scrape prometheus metrics from rust_core directly
    url = "http://rust_core:9100/metrics"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=2) as r:
                txt = await r.text()
        # parse order_roundtrip_seconds_sum/count for a rough mean
        import re
        sum_match = re.search(r'order_roundtrip_seconds_sum\s+(\d+\.\d+)', txt)
        cnt_match = re.search(r'order_roundtrip_seconds_count\s+(\d+)', txt)
        if sum_match and cnt_match and float(cnt_match.group(1))>0:
            mean_s = float(sum_match.group(1))/float(cnt_match.group(1))
            return mean_s*1000.0
    except Exception:
        return None
    return None

async def on_start():
    app = web.Application()
    app.add_routes(routes)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host="0.0.0.0", port=9101)
    await site.start()

ALLOWED_USERS = set([int(x) for x in os.getenv('TELEGRAM_ALLOWLIST','').split(',') if x.strip().isdigit()])
ROLES = json.loads(os.getenv('TELEGRAM_ROLES','{}'))  # {"12345":"admin","67890":"viewer"}

def role_of(uid:int):
    return ROLES.get(str(uid), 'viewer')

async def log_cmd(pool, user_id:int, chat_id:int, cmd:str, args:str):
    async with pool.acquire() as conn:
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_telegram(
            ts TIMESTAMPTZ DEFAULT now(),
            user_id BIGINT,
            chat_id BIGINT,
            command TEXT,
            args TEXT
        );
        """)
        await conn.execute("INSERT INTO audit_telegram(user_id,chat_id,command,args) VALUES($1,$2,$3,$4)", user_id, chat_id, cmd, args)

async def main():
    dp = Dispatcher()
    bot = Bot(TOKEN)
    pool = await asyncpg.create_pool(PG_DSN)

    @dp.message(Command("start"))
    async def start(m: Message):
        await m.answer("AGRO panel online. Commands: /latency /drawdown /pnl /report /halt_on /halt_off /risk_report")

    @dp.message(Command("latency"))
    async def latency(m: Message):
        if ALLOWED_USERS and m.from_user and m.from_user.id not in ALLOWED_USERS:
            await m.answer("Access denied")
            return
        await log_cmd(pool, m.from_user.id if m.from_user else 0, m.chat.id, 'latency', '')
        lat = await pull_rust_latency()
        if lat is not None:
            g_latency.set(lat)
            await m.answer(f"Mean order roundtrip: {lat:.2f} ms")
        else:
            await m.answer("Latency metric unavailable")

    @dp.message(Command("drawdown"))
    async def drawdown(m: Message):
        if ALLOWED_USERS and m.from_user and m.from_user.id not in ALLOWED_USERS:
            await m.answer("Access denied")
            return
        await log_cmd(pool, m.from_user.id if m.from_user else 0, m.chat.id, 'drawdown', '')
        async with pool.acquire() as conn:
            dd = await compute_drawdown(conn)
            g_drawdown.set(dd)
            await m.answer(f"Current drawdown: {dd:.2f}%")

    @dp.message(Command("pnl"))
    async def pnl(m: Message):
        if ALLOWED_USERS and m.from_user and m.from_user.id not in ALLOWED_USERS:
            await m.answer("Access denied")
            return
        await log_cmd(pool, m.from_user.id if m.from_user else 0, m.chat.id, 'pnl', '')
        async with pool.acquire() as conn:
            pnl = await compute_pnl(conn)
            g_pnl.set(pnl)
            await m.answer(f"PnL total: {pnl:.2f}")

    await on_start()

@dp.message(Command("halt_on"))
async def halt_on(m: Message):
    if ALLOWED_USERS and m.from_user and m.from_user.id not in ALLOWED_USERS:
        await m.answer("Access denied"); return
    if role_of(m.from_user.id) != "admin":
        await m.answer("Admin only"); return
    import pathlib, os
    path = os.getenv("AGRO_RISK_HALT_FILE","/models/halt.flag")
    pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(path).touch()
    await log_cmd(pool, m.from_user.id, m.chat.id, 'halt_on','')
    await m.answer("Trading HALTED")

@dp.message(Command("halt_off"))
async def halt_off(m: Message):
    if ALLOWED_USERS and m.from_user and m.from_user.id not in ALLOWED_USERS:
        await m.answer("Access denied"); return
    if role_of(m.from_user.id) != "admin":
        await m.answer("Admin only"); return
    import os, pathlib
    path = os.getenv("AGRO_RISK_HALT_FILE","/models/halt.flag")
    if pathlib.Path(path).exists():
        pathlib.Path(path).unlink()
    await log_cmd(pool, m.from_user.id, m.chat.id, 'halt_off','')
    await m.answer("Trading RESUMED")

@dp.message(Command("risk_report"))
async def risk_report(m: Message):
    if ALLOWED_USERS and m.from_user and m.from_user.id not in ALLOWED_USERS:
        await m.answer("Access denied"); return
    # call risk_guard /report
    import aiohttp, os
    url = os.getenv("RISK_GUARD_URL","http://python_risk_guard:9105/report")
    async with aiohttp.ClientSession() as s:
        async with s.post(url, json={}) as r:
            if r.status==200:
                j = await r.json()
                await log_cmd(pool, m.from_user.id, m.chat.id, 'risk_report','')
                await m.answer(f"Report saved: {j.get('path')}")
            else:
                await m.answer("Report failed")

    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
