from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Protocol
from loguru import logger

class Portfolio(Protocol):
    def size(self, symbol: str, px: float) -> float: ...
    def net_notional_usd(self) -> float: ...
    def symbol_notional_usd(self, symbol: str) -> float: ...
    def open_orders(self, venue: str, symbol: str) -> int: ...
    def order_rate(self, venue: str, symbol: str) -> float: ...

class Gateway(Protocol):
    async def place(self, strategy: str, venue: Optional[str], symbol: str, side: str,
                    qty: float, price: Optional[float], ord_type: str = "LIMIT",
                    tif: Optional[str] = None, flags: Optional[list[str]] = None,
                    coid: Optional[str] = None): ...

class Router(Protocol):
    def choose(self, symbol: str, side: str): ...

@dataclass
class Market:
    bid: float
    ask: float

def bps(a: float, b: float) -> float:
    return (abs(a - b) / ((a + b) / 2.0)) * 1e4

class BaseArbitrage:
    NAME = "base_arbitrage"

    def __init__(self, cfg: dict, portfolio: Portfolio, gateway: Gateway, router: Router, risk_guard):
        self.cfg = cfg
        self.portfolio = portfolio
        self.exec = gateway
        self.router = router
        self.risk = risk_guard

    def _max_slippage_bps(self) -> float:
        return float(self.cfg.get("execution", {}).get("max_slippage_bps", 5.0))

    def _safe_limit(self, side: str, m: Market, offset_bps: float = 0.0) -> float:
        """Return a passive limit price skimming the touch with small offset."""
        if side == "BUY":
            # aim between bid and ask, but below ask
            px = min(m.ask, m.bid * (1.0 + offset_bps/1e4))
        else:
            px = max(m.bid, m.ask * (1.0 - offset_bps/1e4))
        return px

    def _check_slippage(self, ref: float, exec_price: float):
        sl = bps(ref, exec_price)
        if sl > self._max_slippage_bps():
            raise ValueError(f"slippage {sl:.2f} bps exceeds max {self._max_slippage_bps():.2f} bps")

    async def place_limit_passive(self, symbol: str, side: str, qty: float, m: Market, offset_bps: float = 0.0):
        limit_px = self._safe_limit(side, m, offset_bps)
        venue = self.router.choose(symbol, side)
        # risk pre-checks
        self.risk.pre_order(venue, symbol, side, qty, limit_px)
        res = await self.exec.place(self.NAME, venue, symbol, side, qty, limit_px,
                                    "LIMIT", flags=["post_only"])
        return res

    async def place_market_careful(self, symbol: str, side: str, qty: float, ref_px: float, exec_px: float):
        # Only allow MARKET if slippage within max_slippage_bps
        self._check_slippage(ref_px, exec_px)
        venue = self.router.choose(symbol, side)
        self.risk.pre_order(venue, symbol, side, qty, exec_px)
        # Even for "market", many venues require limit; emulate with IOC around exec_px
        res = await self.exec.place(self.NAME, venue, symbol, side, qty, exec_px,
                                    "LIMIT", tif="IOC", flags=[])
        return res
