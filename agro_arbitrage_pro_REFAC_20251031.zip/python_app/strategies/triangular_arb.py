from __future__ import annotations
from typing import Dict, Any
from loguru import logger
from .base_arbitrage import BaseArbitrage, Market

class Strategy(BaseArbitrage):
    NAME = "triangular_arb"

    def __init__(self, cfg, portfolio, gateway, router, risk_guard, md_provider):
        super().__init__(cfg, portfolio, gateway, router, risk_guard)
        self.md = md_provider  # must provide get_snapshot(venue, symbol) with bid/ask

    async def trade_once(self) -> Dict[str, Any]:
        # Illustrative path: BTC/USDT, USDT/USD, BTC/USD (synthetic)
        base_symbol = "BTCUSDT"
        side = "BUY"  # example logic: detect opportunity externally

        # market snapshot from best venue (router considers spread/liquidity/latency)
        venue = self.router.choose(base_symbol, side)
        snap = self.md.get_snapshot(venue, base_symbol)
        if not snap or snap.ask <= 0 or snap.bid <= 0:
            return {"status": "skip", "reason": "no_market"}

        m = Market(bid=snap.bid, ask=snap.ask)
        # position sizing
        ref_px = snap.ask if side == "BUY" else snap.bid
        qty = self.portfolio.size(base_symbol, ref_px)
        if qty <= 0:
            return {"status": "skip", "reason": "zero_qty"}

        # Safe passive limit by default
        res = await self.place_limit_passive(base_symbol, side, qty, m, offset_bps=0.5)
        logger.info(f"triangular_arb passive order: {res}")
        return {"status": "placed", "details": res}
