
from python_app.strategies.base_arbitrage import BaseArbitrage
from loguru import logger

class Strategy(BaseArbitrage):
    NAME = "volatility_rebalance"
    async def trade_once(self):
        symbol = "BTCUSDT"
        side = "BUY"
        qty = self.portfolio.size(symbol, 100.0)
        ex = self.router.choose(symbol, side)
        res = await self.exec.place(self.NAME, ex, symbol, side, qty, 0.0, "MARKET")
        logger.info(f"volatility_rebalance trade result: {res}")
