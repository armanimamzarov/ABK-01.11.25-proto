
from python_app.strategies.base_arbitrage import BaseArbitrage
from loguru import logger

class Strategy(BaseArbitrage):
    NAME = "mean_reversion_bands"
    async def trade_once(self):
        symbol = "BNBUSDT"
        side = "BUY"
        qty = self.portfolio.size(symbol, 100.0)
        ex = self.router.choose(symbol, side)
        res = await self.exec.place(self.NAME, ex, symbol, side, qty, 0.0, "MARKET")
        logger.info(f"mean_reversion_bands trade result: {res}")
