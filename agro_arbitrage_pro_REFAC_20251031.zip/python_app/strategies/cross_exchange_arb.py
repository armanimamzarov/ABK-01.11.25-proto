
from python_app.strategies.base_arbitrage import BaseArbitrage
from loguru import logger

class Strategy(BaseArbitrage):
    NAME = "cross_exchange_arb"
    async def trade_once(self):
        symbol = "ETHUSDT"
        side = "BUY"
        qty = self.portfolio.size(symbol, 3000.0)
        ex = self.router.choose(symbol, side)
        res = await self.exec.place(self.NAME, ex, symbol, side, qty, 0.0, "MARKET")
        logger.info(f"Cross-ex result: {res}")
