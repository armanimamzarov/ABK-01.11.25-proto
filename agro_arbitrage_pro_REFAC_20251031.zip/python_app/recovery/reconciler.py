from __future__ import annotations
import time
from typing import Dict, Any, List
from .order_store import OrderStore, OrderRecord
from ..common.logging_json import setup_json_logging
import logging

logger = logging.getLogger(__name__)

class Reconciler:
    def __init__(self, exchange_adapters: Dict[str, Any], poll_interval: float = 2.0) -> None:
        self.exchange_adapters = exchange_adapters
        self.poll_interval = poll_interval
        self.store = OrderStore()

    def run_forever(self) -> None:
        setup_json_logging()
        logger.info("reconciler_started")
        while True:
            self._tick()
            time.sleep(self.poll_interval)

    def _tick(self) -> None:
        open_orders = self.store.list_unfinished()
        for rec in open_orders:
            adapter = self.exchange_adapters.get(rec.exchange)
            if not adapter:
                logger.error("adapter_missing", extra={"extra": {"exchange": rec.exchange}})
                continue
            try:
                status = adapter.query_order(rec.symbol, rec.client_order_id)
                rec.state = status.get("state", rec.state)  # type: ignore[assignment]
                if isinstance(status, dict):
                    rec.meta.update({"last_status": status})
                rec.updated_ts = time.time()
                self.store.upsert(rec)
                logger.info("order_status_updated", extra={"extra": {"id": rec.client_order_id, "state": rec.state}})
            except Exception:
                logger.exception("order_status_query_failed", extra={"extra": {"id": rec.client_order_id}})
