from __future__ import annotations
import sqlite3
from dataclasses import dataclass
from typing import Optional, List, Literal, Dict, Any
import time
import json
import os

OrderState = Literal["PendingNew","Ack","Partial","Filled","Cancelled","Rejected"]

@dataclass
class OrderRecord:
    client_order_id: str
    symbol: str
    side: Literal["buy","sell"]
    qty: float
    price: float
    state: OrderState
    exchange: str
    created_ts: float
    updated_ts: float
    meta: Dict[str, Any]

class OrderStore:
    def __init__(self, path: str | None = None) -> None:
        self.path = path or os.getenv("ORDER_STORE_SQLITE", "db/order_store.sqlite3")
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS orders (
                client_order_id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                qty REAL NOT NULL,
                price REAL NOT NULL,
                state TEXT NOT NULL,
                exchange TEXT NOT NULL,
                created_ts REAL NOT NULL,
                updated_ts REAL NOT NULL,
                meta TEXT NOT NULL
            );"""
        )
        self.conn.commit()

    def upsert(self, rec: OrderRecord) -> None:
        self.conn.execute(
            """INSERT INTO orders
            (client_order_id,symbol,side,qty,price,state,exchange,created_ts,updated_ts,meta)
            VALUES (?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(client_order_id) DO UPDATE SET
              state=excluded.state,
              updated_ts=excluded.updated_ts,
              meta=excluded.meta""" ,
            (
                rec.client_order_id, rec.symbol, rec.side, rec.qty, rec.price, rec.state,
                rec.exchange, rec.created_ts, rec.updated_ts, json.dumps(rec.meta, ensure_ascii=False),
            ),
        )
        self.conn.commit()

    def get(self, client_order_id: str) -> Optional[OrderRecord]:
        cur = self.conn.execute("SELECT * FROM orders WHERE client_order_id = ?", (client_order_id,))
        row = cur.fetchone()
        return self._row_to_record(row) if row else None

    def list_unfinished(self) -> List[OrderRecord]:
        cur = self.conn.execute("SELECT * FROM orders WHERE state NOT IN ('Filled','Cancelled','Rejected')")
        return [self._row_to_record(r) for r in cur.fetchall()]

    def _row_to_record(self, row: tuple) -> OrderRecord:
        return OrderRecord(
            client_order_id=row[0], symbol=row[1], side=row[2], qty=row[3], price=row[4],
            state=row[5], exchange=row[6], created_ts=row[7], updated_ts=row[8],
            meta=json.loads(row[9]),
        )
