
from prometheus_client import start_http_server, Counter, Gauge, Histogram
import time

ORDERS_TOTAL = Counter("orders_total", "Orders submitted", ["venue","symbol","side"])
ORDER_LATENCY = Histogram("order_latency_seconds","Order RTT", buckets=(0.05,0.1,0.2,0.5,1,2,5))
WS_GAPS = Counter("ws_sequence_gaps_total","Detected WS gaps", ["symbol","venue"])
EXPOSURE_USD = Gauge("exposure_usd","Per-symbol exposure", ["symbol"])

def serve_metrics(port:int):
    start_http_server(port)
    while True:
        time.sleep(1)
