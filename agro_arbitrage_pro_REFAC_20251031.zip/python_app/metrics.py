from aiohttp import web
from prometheus_client import CollectorRegistry, CONTENT_TYPE_LATEST, generate_latest, Counter

REGISTRY = CollectorRegistry()
ORDERS_SENT = Counter("py_orders_sent_total", "Orders sent from python", registry=REGISTRY)

async def handle_metrics(request):
    data = generate_latest(REGISTRY)
    return web.Response(body=data, content_type=CONTENT_TYPE_LATEST)

async def serve_metrics():
    app = web.Application()
    app.router.add_get('/metrics', handle_metrics)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 9101)
    await site.start()
    while True:
        await asyncio.sleep(3600)

import asyncio
