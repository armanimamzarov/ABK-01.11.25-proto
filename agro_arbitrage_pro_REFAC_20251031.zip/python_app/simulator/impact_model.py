from dataclasses import dataclass

@dataclass
class DepthLevel:
    price: float
    qty: float

def estimate_slippage(side: str, qty: float, bids, asks):
    # linear walk through depth
    consumed = 0.0
    cost = 0.0
    book = asks if side.upper()=="BUY" else bids
    for lvl in book:
        take = min(qty - consumed, lvl.qty)
        if take <= 0: break
        consumed += take
        cost += take * lvl.price
    if consumed < qty:
        return None  # not enough liquidity
    avg_px = cost/qty
    top = (asks[0].price if side.upper()=="BUY" else bids[0].price)
    slip_bps = (abs(avg_px - top)/top)*10000.0
    return avg_px, slip_bps
