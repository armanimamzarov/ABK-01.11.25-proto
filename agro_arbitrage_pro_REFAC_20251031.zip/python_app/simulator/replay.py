import time, random, math
from typing import List, Tuple, Dict, Callable
from prometheus_client import Counter, Gauge, Histogram, start_http_server

fill_ratio = Gauge("fill_ratio", "Fill ratio (fills/orders)")
adverse_selection_bps = Histogram("adverse_selection_bps", "Adverse selection (bps)")
pnl_net = Gauge("pnl_net", "Net PnL")
latency_exec_ms = Histogram("latency_exec_ms", "Execution latency (ms)")

class ReplayEngine:
    def __init__(self, latency_ms: float = 5.0, slippage_bps: float = 1.0, fee_bps: float = 2.0, metrics_port: int=9300):
        self.latency_ms = latency_ms
        self.slippage_bps = slippage_bps
        self.fee_bps = fee_bps
        self.orders = 0
        self.fills = 0
        self.pnl = 0.0
        start_http_server(metrics_port)
    def submit(self, price: float, qty: float, side: str) -> Tuple[bool, float]:
        self.orders += 1
        start = time.time()
        time.sleep(self.latency_ms/1000.0)
        slip = price * (self.slippage_bps/10000.0) * (1.0 if side.upper()=="BUY" else -1.0)
        fee = price * (self.fee_bps/10000.0)
        fill_price = price + slip + fee
        self.fills += 1
        fill_ratio.set(self.fills/max(1,self.orders))
        latency_exec_ms.observe((time.time()-start)*1000.0)
        return True, fill_price
    def on_close(self, entry: float, exit: float, qty: float, side: str):
        if side.upper()=="BUY":
            pnl = (exit-entry)*qty
        else:
            pnl = (entry-exit)*qty
        bps = (max(exit,1e-9)-max(entry,1e-9))/max(entry,1e-9)*10000.0
        adverse_selection_bps.observe(bps)
        self.pnl += pnl
        pnl_net.set(self.pnl)
