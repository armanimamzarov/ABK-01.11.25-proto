import time
from typing import Dict, List, Tuple, Optional
from prometheus_client import Counter, Gauge, Histogram

ws_gap_total = Counter("ws_gap_total", "Number of WS gaps detected")
ws_resync_total = Counter("ws_resync_total", "Number of WS resync operations")
stale_book_seconds = Histogram("stale_book_seconds", "Seconds book was stale")
book_seq_skips = Counter("book_seq_skips", "Sequence id skips detected")

class OrderBook:
    def __init__(self):
        self.bids: Dict[float,float] = {}
        self.asks: Dict[float,float] = {}
        self.last_update_id: Optional[int] = None
        self.last_ts: float = time.time()
    def apply_snapshot(self, last_update_id: int, bids: List[Tuple[float,float]], asks: List[Tuple[float,float]]):
        self.bids = {p:q for p,q in bids if q>0}
        self.asks = {p:q for p,q in asks if q>0}
        self.last_update_id = last_update_id
        self.last_ts = time.time()
    def apply_diff(self, first_id: int, last_id: int, bids: List[Tuple[float,float]], asks: List[Tuple[float,float]]):
        if self.last_update_id is None:
            return False
        if last_id <= self.last_update_id:
            return True
        if first_id != self.last_update_id + 1:
            book_seq_skips.inc()
            ws_gap_total.inc()
            return False
        for p,q in bids:
            if q == 0:
                self.bids.pop(p, None)
            else:
                self.bids[p] = q
        for p,q in asks:
            if q == 0:
                self.asks.pop(p, None)
            else:
                self.asks[p] = q
        self.last_update_id = last_id
        self.last_ts = time.time()
        return True
    def is_stale(self, threshold_s: float = 2.0) -> bool:
        age = time.time() - self.last_ts
        if age > threshold_s:
            stale_book_seconds.observe(age)
            return True
        return False

class RecoveryManager:
    def __init__(self):
        self.books: Dict[Tuple[str,str], OrderBook] = {}
    def key(self, ex: str, sym: str): return (ex, sym)
    def book(self, ex: str, sym: str) -> OrderBook:
        k = self.key(ex, sym)
        if k not in self.books: self.books[k] = OrderBook()
        return self.books[k]
    def on_snapshot(self, ex: str, sym: str, last_update_id: int, bids, asks):
        self.book(ex, sym).apply_snapshot(last_update_id, bids, asks)
    def on_diff(self, ex: str, sym: str, first_id: int, last_id: int, bids, asks) -> bool:
        ok = self.book(ex, sym).apply_diff(first_id, last_id, bids, asks)
        if not ok:
            self.resubscribe_and_resync(ex, sym)
        return ok
    def resubscribe_and_resync(self, ex: str, sym: str):
        ws_resync_total.inc()
        # The actual adapter should handle WS unsubscribe/subscribe and REST snapshot refresh.
        # Here we just reset last_update_id to force a snapshot.
        self.book(ex, sym).last_update_id = None
