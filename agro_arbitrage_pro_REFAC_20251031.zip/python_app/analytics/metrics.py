from prometheus_client import Gauge, Counter, Histogram

g_live = Gauge('agro_live_ok','Live OK flag')
c_signals = Counter('agro_signals_total','Signals processed', ['strategy'])
c_fills = Counter('agro_fills_total','Trades filled', ['strategy'])
h_latency = Histogram('agro_loop_latency_seconds','Strategy loop latency')
g_live.set(1)
