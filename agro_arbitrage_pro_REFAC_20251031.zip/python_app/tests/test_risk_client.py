
import asyncio, pytest
from python_app.risk_management.arbitrage_risk_engine import RiskClient

@pytest.mark.asyncio
async def test_risk_validate_smoke():
    c = RiskClient()
    await c.connect()
    allowed, reason = await c.validate("test","binance","BTCUSDT","BUY",0.001,1.0,"LIMIT")
    assert isinstance(allowed, bool)
    assert isinstance(reason, str)
