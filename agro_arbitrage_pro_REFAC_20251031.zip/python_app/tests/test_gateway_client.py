import pytest, asyncio
from python_app.execution.gateway_client import GatewayClient

@pytest.mark.asyncio
async def test_submit():
    gw = GatewayClient("http://localhost")
    r = await gw.submit_order("MOCK","BTCUSDT","buy",1.0, None)
    assert "client_order_id" in r
