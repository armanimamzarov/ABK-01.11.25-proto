
import asyncio
import pytest
from python_app.core.execution_coordinator import ExecutionCoordinator
from python_app.risk_management.arbitrage_risk_engine import RiskClient

@pytest.mark.asyncio
async def test_place_paper():
    rc = RiskClient()
    await rc.connect()
    ex = ExecutionCoordinator(rc)
    res = await ex.place("test","binance","BTCUSDT","BUY",0.001,0.0,"MARKET")
    assert "status" in res
