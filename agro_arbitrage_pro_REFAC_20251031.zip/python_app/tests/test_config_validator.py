
from python_app.config.validator import validate

def test_configs_ok():
    errs = validate()
    assert errs == []
