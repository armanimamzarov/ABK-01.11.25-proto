import asyncio, os
import ccxtpro
import logging
logger = logging.getLogger(__name__)

SYMBOL = os.getenv("SYMBOL","BTC/USDT")
TF = os.getenv("TF","1m")

async def main():
    ex = ccxtpro.gateio({'enableRateLimit': True})
logger.info(f"📡 {ex.id} OHLCV {SYMBOL} {TF}")
    while True:
        try:
            ohlcv = await ex.watch_ohlcv(SYMBOL, TF)
            if ohlcv:
                ts, o, h, l, c, v = ohlcv[-1]
logger.info(f"{SYMBOL} {TF} close={c} vol={v}")
        except Exception as e:
logger.info('⚠️', type(e).__name__, e)
            await asyncio.sleep(3)

asyncio.run(main())