import asyncio, os
import ccxtpro
import logging
logger = logging.getLogger(__name__)

SYMBOL = os.getenv("SYMBOL","BTC/USDT")

async def main():
    exchange = ccxtpro.binance({'enableRateLimit': True, 'options': {'defaultType': 'spot'}})
logger.info(f"📡 Connecting to {exchange.id} WS for {SYMBOL} ...")
    while True:
        try:
            ob = await exchange.watch_order_book(SYMBOL, limit=5)
            bid = ob['bids'][0][0] if ob['bids'] else None
            ask = ob['asks'][0][0] if ob['asks'] else None
logger.info(f"🟢 {SYMBOL} BID: {bid} | ASK: {ask}")
        except Exception as e:
logger.info('⚠️', type(e).__name__, e)
            await asyncio.sleep(3)

asyncio.run(main())