import asyncio, os
import ccxtpro
import logging
logger = logging.getLogger(__name__)

async def main():
    ex = ccxtpro.kucoin({
        'apiKey': os.getenv('KUCOIN_KEY',''),
        'secret': os.getenv('KUCOIN_SECRET',''),
        'password': os.getenv('KUCOIN_PASSWORD',''),
        'enableRateLimit': True
    })
logger.info(f"📡 {ex.id} balance WS")
    while True:
        try:
            bal = await ex.watch_balance()
            total = bal.get('total') or {}
            spot = {k:v for k,v in total.items() if (v or 0)>0}
logger.info("💰 balances:", spot)
        except Exception as e:
logger.info('⚠️', type(e).__name__, e)
            await asyncio.sleep(5)

asyncio.run(main())