import asyncio, os
import ccxtpro
import logging
logger = logging.getLogger(__name__)

SYMBOL = os.getenv("SYMBOL","BTC/USDT")

async def main():
    ex = ccxtpro.okx({'enableRateLimit': True})
logger.info(f"📡 {ex.id} ticker stream for {SYMBOL}")
    while True:
        try:
            t = await ex.watch_ticker(SYMBOL)
logger.info(f"{SYMBOL} last={t.get('last')} bid={t.get('bid')} ask={t.get('ask')}")
        except Exception as e:
logger.info('⚠️', type(e).__name__, e)
            await asyncio.sleep(2)

asyncio.run(main())