import asyncio, os, datetime as dt
import ccxtpro
import logging
logger = logging.getLogger(__name__)

SYMBOL = os.getenv("SYMBOL","BTC/USDT")

async def main():
    ex = ccxtpro.bybit({'enableRateLimit': True})
logger.info(f"📡 {ex.id} trades stream for {SYMBOL}")
    while True:
        try:
            trades = await ex.watch_trades(SYMBOL)
            for t in trades[-5:]:
                ts = dt.datetime.utcfromtimestamp(t['timestamp']/1000).strftime('%H:%M:%S')
logger.info(f"{ts} {SYMBOL} px={t['price']} qty={t['amount']} side={t.get('side')}")
        except Exception as e:
logger.info('⚠️', type(e).__name__, e)
            await asyncio.sleep(3)

asyncio.run(main())