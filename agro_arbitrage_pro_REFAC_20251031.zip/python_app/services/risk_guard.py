
import os, time, asyncio
import numpy as np
import pandas as pd
import asyncpg
import clickhouse_connect
from aiohttp import web
from prometheus_client import CollectorRegistry, Gauge, generate_latest, CONTENT_TYPE_LATEST

PG_DSN = f"postgresql://{os.getenv('POSTGRES_USER','agro')}:{os.getenv('POSTGRES_PASSWORD','secret')}@{os.getenv('POSTGRES_HOST','postgres')}:{os.getenv('POSTGRES_PORT','5432')}/{os.getenv('POSTGRES_DB','agro')}"
CH_HOST = os.getenv("CLICKHOUSE_HOST","clickhouse")
CH_PORT = int(os.getenv("CLICKHOUSE_PORT","8123"))
CH_USER = os.getenv("CLICKHOUSE_USER","agro")
CH_PASS = os.getenv("CLICKHOUSE_PASSWORD","secret")
CH_DB   = os.getenv("CLICKHOUSE_DB","agro")

HALT_FILE = os.getenv("AGRO_RISK_HALT_FILE","/models/halt.flag")
VAR_CONF  = float(os.getenv("AGRO_RISK_VAR_CONF","0.99"))   # 99% VaR
VAR_LIMIT = float(os.getenv("AGRO_RISK_VAR_LIMIT","0.03"))  # 3% equity
DD_LIMIT  = float(os.getenv("AGRO_RISK_DRAWDOWN_LIMIT","0.10"))  # 10%

registry = CollectorRegistry()
MARGIN_REQS = json.loads(os.getenv('AGRO_MARGIN_REQS', '{}'))  # {"binance":0.02, ...}
g_var = Gauge("agro_var","Parametric or historical VaR (fraction of equity)", registry=registry)
g_es  = Gauge("agro_es","Expected Shortfall (fraction of equity)", registry=registry)
g_dd  = Gauge("agro_drawdown_pct","Drawdown %", registry=registry)  # reused by panel too
g_halt= Gauge("agro_trading_halt","Trading halted (0/1)", registry=registry)
 g_stress = Gauge("agro_stress_loss","Stress scenario loss fraction", registry=registry)

routes = web.RouteTableDef()

@routes.get("/metrics")
async def metrics(_):
    return web.Response(body=generate_latest(registry), content_type=CONTENT_TYPE_LATEST)

@routes.get("/health")
async def health(_):
    return web.json_response({"status":"ok"})


@routes.post("/report")
async def report(req: web.Request):
    # Generate HTML risk report and store under /models/reports
    from jinja2 import Template
    body = await req.json() if req.can_read_body else {}
    now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    # pull last computed metrics from gauges (best-effort: recompute quickly)
    var, es = compute_var_es_from_quotes()
    dd = 0.0
    try:
        pg = await asyncpg.connect(PG_DSN); dd = await compute_drawdown(pg); await pg.close()
    except Exception:
        pass
    # positions snapshot for stress & margins
    pos = {}
    try:
        pg = await asyncpg.connect(PG_DSN); pos = await compute_positions(pg); await pg.close()
    except Exception:
        pass
    stress = run_stress(pos)
    # margin check aggregate (exchanges from positions naming or body)
    margin_breaches = []
    for ex, reqm in MARGIN_REQS.items():
        # assume equity & used margin stored somewhere; placeholder computes 0 usage
        used = 0.0
        if used > reqm: margin_breaches.append(ex)
    # Render simple HTML
    tpl = Template("""<!DOCTYPE html><html><head><meta charset='utf-8'><title>AGRO Risk Report</title>
<style>body{font-family:Arial,Helvetica,sans-serif;margin:24px;} h1{margin:0 0 12px} .k{font-weight:bold}</style>
</head><body>
<h1>AGRO Risk Report</h1>
<p><span class="k">Generated:</span> {{ now }}</p>
<h2>Metrics</h2>
<ul>
<li>VaR ({{ conf*100 }}%): <b>{{ var|round(5) }}</b></li>
<li>ES: <b>{{ es|round(5) }}</b></li>
<li>Drawdown: <b>{{ dd|round(2) }} %</b></li>
<li>Stress Loss: <b>{{ stress|round(5) }}</b></li>
</ul>
<h2>Positions (top 20)</h2>
<ol>
{% for s,q in pos.items()|list()[:20] %}<li>{{ s }}: {{ q }}</li>{% endfor %}
</ol>
<h2>Margin Requirements</h2>
<p>Configured: {{ margins }}</p>
<p>Breaches: {{ breaches }}</p>
</body></html>
""")
    html = tpl.render(now=now, var=var, es=es, dd=dd, stress=stress, pos=pos, margins=MARGIN_REQS, breaches=margin_breaches, conf=VAR_CONF)
    out_dir = pathlib.Path(os.getenv("AGRO_REPORT_DIR","/models/reports"))
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    out_path = out_dir / f"risk_report_{ts}.html"
    out_path.write_text(html)
    return web.json_response({"ok": True, "path": str(out_path)})


def ch_client():
    return clickhouse_connect.get_client(host=CH_HOST, port=CH_PORT, username=CH_USER, password=CH_PASS, database=CH_DB)

async def compute_drawdown(pg):
    row = await pg.fetchrow("SELECT COALESCE(MAX(equity),0) AS peak, COALESCE(MIN(equity),0) AS trough FROM equity_curve;")
    peak, trough = float(row["peak"]), float(row["trough"])
    if peak <= 0: return 0.0
    return max(0.0, (peak - trough) / peak * 100.0)

def compute_positions(pg):
    # Try positions table; else synthesize from trades
    async def have_table(name):
        row = await pg.fetchrow("SELECT to_regclass($1) AS t", name)
        return row and row["t"] is not None
    # Positions as {symbol: qty}
    pos = {}
    # Try positions
    try:
        if await have_table("positions"):
            rows = await pg.fetch("SELECT symbol, SUM(qty) AS qty FROM positions GROUP BY symbol")
            for r in rows:
                pos[r["symbol"]] = float(r["qty"] or 0.0)
        else:
            # Build from trades (buy +, sell -)
            rows = await pg.fetch("SELECT symbol, side, qty FROM trades")
            for r in rows:
                s = r["symbol"]; q = float(r["qty"] or 0.0)
                if r["side"].lower().startswith("b"):
                    pos[s] = pos.get(s, 0.0) + q
                else:
                    pos[s] = pos.get(s, 0.0) - q
    except Exception:
        pass
    return pos

def compute_var_es_from_quotes(limit=200_000, pos=None):
    # If positions provided, compute portfolio VaR/ES; else fallback to market VaR
    c = ch_client()
    df = c.query_df(f"SELECT ts, symbol, (ask+bid)/2 AS mid FROM quotes ORDER BY ts DESC LIMIT {limit}")
    if df.empty:
        return 0.0, 0.0
    df = df.sort_values(["symbol","ts"])
    # Build returns per symbol
    df["ret1"] = df.groupby("symbol")["mid"].pct_change()
    df = df.dropna(subset=["ret1"])
    if pos and any(abs(v) > 0 for v in pos.values()):
        # Weight by dollar exposure
        # Take last mid per symbol for exposure
        last_mid = df.groupby("symbol")["mid"].last().to_dict()
        expos = {s: pos.get(s,0.0)*last_mid.get(s,0.0) for s in last_mid.keys()}
        total = sum(abs(v) for v in expos.values()) or 1.0
        weights = {s: (expos.get(s,0.0)/total) for s in last_mid.keys()}
        # Compose portfolio return series by aligned pivot
        piv = df.pivot_table(index="ts", columns="symbol", values="ret1").fillna(0.0)
        wvec = np.array([weights.get(s,0.0) for s in piv.columns], dtype=float)
        port_ret = (piv.values @ wvec).ravel()
        if len(port_ret) < 1000:
            return 0.0, 0.0
        q = np.quantile(port_ret, 1.0 - VAR_CONF)
        var = abs(min(0.0, q))
        tail = port_ret[port_ret <= q]
        es = abs(tail.mean()) if len(tail)>0 else var
        return var, es
    # Fallback: unweighted market VaR
    rets = df["ret1"].values
    if len(rets) < 1000:
        return 0.0, 0.0
    q = np.quantile(rets, 1.0 - VAR_CONF)
    var = abs(min(0.0, q))
    tail = rets[rets <= q]
    es = abs(tail.mean()) if len(tail)>0 else var
    return var, es

def run_stress(pos, shock=-0.05, spread_widen=2.0):
    # Simple stress: uniform price shock (e.g., -5%) and spread widening factor
    # Return fractional loss on equity proxy
    if not pos: 
        return 0.0
    c = ch_client()
    # last quote per symbol
    df = c.query_df("SELECT symbol, anyLast(bid) AS bid, anyLast(ask) AS ask FROM quotes GROUP BY symbol")
    last_mid = {r["symbol"]: (float(r["bid"])+float(r["ask"])) / 2.0 for _, r in df.iterrows()} if not df.empty else {}
    equity_proxy = 0.0
    loss = 0.0
    for s, qty in pos.items():
        m = last_mid.get(s, 0.0)
        expos = abs(qty*m)
        equity_proxy += expos
        # price shock
        loss += expos * abs(shock)
        # spread widening cost (slippage)
        loss += expos * (0.0001 * spread_widen)  # 1bp * factor
    return (loss / equity_proxy) if equity_proxy>0 else 0.0


def set_halt(on: bool):
    try:
        if on:
            os.makedirs(os.path.dirname(HALT_FILE), exist_ok=True)
            open(HALT_FILE, "a").close()
            g_halt.set(1.0)
        else:
            if os.path.exists(HALT_FILE):
                os.remove(HALT_FILE)
            g_halt.set(0.0)
    except Exception:
        pass

async def loop_task():
    pg = await asyncpg.connect(PG_DSN)
    try:
        while True:
            try:
pos = await compute_positions(pg)
var, es = compute_var_es_from_quotes(pos=pos)
g_var.set(float(var))
g_es.set(float(es))
dd = await compute_drawdown(pg)
g_dd.set(dd)
stress = run_stress(pos)
# Halt logic (any breach)
breach = (var >= VAR_LIMIT) or (dd/100.0 >= DD_LIMIT) or (stress >= VAR_LIMIT)
set_halt(breach)

            except Exception:
                pass
            await asyncio.sleep(int(os.getenv("RISK_EVAL_INTERVAL_SEC","10")))
    finally:
        await pg.close()

def create_app():
    app = web.Application()
    app.add_routes(routes)
    app.on_startup.append(lambda app: asyncio.create_task(loop_task()))
    return app

if __name__ == "__main__":
    web.run_app(create_app(), host="0.0.0.0", port=9105)
