
import os, time
import numpy as np
import pandas as pd
from aiohttp import web
from prometheus_client import CollectorRegistry, Gauge, generate_latest, CONTENT_TYPE_LATEST
from python_app.ml.feature_store import load_quotes_symbols, build_features

try:
    from evidently.report import Report
    from evidently.metric_preset import DataDriftPreset
    EVIDENTLY_AVAILABLE = True
except Exception:
    EVIDENTLY_AVAILABLE = False

registry = CollectorRegistry()
g_drift = Gauge("agro_feature_drift","Feature drift share (0..1)", registry=registry)

routes = web.RouteTableDef()

@routes.get("/metrics")
async def metrics(_):
    return web.Response(body=generate_latest(registry), content_type=CONTENT_TYPE_LATEST)

@routes.get("/health")
async def health(_):
    return web.json_response({"status":"ok"})

async def compute_drift():
    df = load_quotes_symbols(limit=200_000)
    feats = build_features(df)
    # naive split: older as reference, newer as current
    mid = len(feats)//2
    ref = feats.iloc[:mid].drop(columns=["y"], errors="ignore")
    cur = feats.iloc[mid:].drop(columns=["y"], errors="ignore")
    if EVIDENTLY_AVAILABLE and len(ref)>1000 and len(cur)>1000:
        rep = Report(metrics=[DataDriftPreset()])
        rep.run(reference_data=ref, current_data=cur)
        share = rep.as_dict()["metrics"][0]["result"]["dataset_drift"]
        g_drift.set(float(share))
    else:
        # Fallback: KS-test proxy (very simplified)
        if len(ref)>1000 and len(cur)>1000:
            import scipy.stats as st
            cols = [c for c in ref.columns if ref[c].dtype.kind in "fc"]
            scores = []
            for c in cols:
                try:
                    stat, p = st.ks_2samp(ref[c].values, cur[c].values)
                    scores.append(p < 0.05)
                except Exception:
                    pass
            share = (np.mean(scores) if scores else 0.0)
            g_drift.set(float(share))
        else:
            g_drift.set(0.0)

async def loop_task():
    while True:
        try:
            await compute_drift()
        except Exception:
            pass
        await asyncio.sleep(int(os.getenv("DRIFT_INTERVAL_SEC","300")))

import asyncio
def create_app():
    app = web.Application()
    app.add_routes(routes)
    app.on_startup.append(lambda app: asyncio.create_task(loop_task()))
    return app

if __name__ == "__main__":
    web.run_app(create_app(), host="0.0.0.0", port=9103)
