
import os, time, asyncio, urllib.parse, shutil, pathlib
from aiohttp import web
from prometheus_client import CollectorRegistry, Gauge, generate_latest, CONTENT_TYPE_LATEST

registry = CollectorRegistry()
g_sync = Gauge("agro_model_sync_success","Last sync success (0/1)", registry=registry)

routes = web.RouteTableDef()

@routes.get("/metrics")
async def metrics(_):
    return web.Response(body=generate_latest(registry), content_type=CONTENT_TYPE_LATEST)

def s3_download(s3_url: str, out_path: str):
    import boto3
    p = urllib.parse.urlparse(s3_url)
    bucket = p.netloc
    key = p.path.lstrip("/")
    s3 = boto3.client("s3",
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
        region_name=os.getenv("AWS_REGION"))
    pathlib.Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    s3.download_file(bucket, key, out_path)

async def sync_once():
    src = os.getenv("AGRO_MODEL_SRC","")
    dst = os.getenv("AGRO_ML_ONNX_PATH","/models/risk.onnx")
    try:
        if src.startswith("s3://"):
            s3_download(src, dst)
        else:
            if src and os.path.exists(src):
                pathlib.Path(dst).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        g_sync.set(1.0)
    except Exception:
        g_sync.set(0.0)

async def loop_task():
    while True:
        await sync_once()
        await asyncio.sleep(int(os.getenv("MODEL_SYNC_INTERVAL_SEC","600")))

def create_app():
    app = web.Application()
    app.add_routes(routes)
    app.on_startup.append(lambda app: asyncio.create_task(loop_task()))
    return app

if __name__ == "__main__":
    web.run_app(create_app(), host="0.0.0.0", port=9104)
