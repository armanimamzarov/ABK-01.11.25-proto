import asyncio, datetime as dt
from ..config import load_config

class ReconWorker:
    def __init__(self):
        self.cfg = load_config()

    async def run_once(self):
        # simulate reconciliation work
        await asyncio.sleep(0.05)
        return {"fixed": 0, "checked": 10}

async def main():
    r = ReconWorker()
    while True:
        await r.run_once()
        await asyncio.sleep(5)

if __name__ == "__main__":
    asyncio.run(main())
