
import os, asyncio, json, pathlib
from aiohttp import web
from prometheus_client import CollectorRegistry, Gauge, generate_latest, CONTENT_TYPE_LATEST

ETCD_ENDPOINT = os.getenv("ETCD_ENDPOINT","http://etcd:2379")
HALT_FILE = os.getenv("AGRO_RISK_HALT_FILE","/models/halt.flag")
RUNTIME_CFG = os.getenv("AGRO_RUNTIME_CONFIG","/models/runtime_config.json")

registry = CollectorRegistry()
g_updates = Gauge("agro_config_updates_total","Total config updates applied", registry=registry)

routes = web.RouteTableDef()

@routes.get("/metrics")
async def metrics(_):
    return web.Response(body=generate_latest(registry), content_type=CONTENT_TYPE_LATEST)

async def loop_task():
    import etcd3
    cli = etcd3.client(host=os.getenv("ETCD_HOST","etcd"), port=int(os.getenv("ETCD_PORT","2379")))
    prefix = "/agro/config/"
    while True:
        try:
            # Simple poll (watch stream may block in some envs). Poll keys by prefix.
            data = {}
            for v,k in cli.get_prefix(prefix):
                key = k.key.decode("utf-8").replace(prefix,"")
                data[key] = v.decode("utf-8")
            # Apply HALT
            halt = data.get("trading_halt","0") in ("1","true","True")
            if halt:
                pathlib.Path(HALT_FILE).parent.mkdir(parents=True, exist_ok=True)
                pathlib.Path(HALT_FILE).touch()
            else:
                if pathlib.Path(HALT_FILE).exists():
                    pathlib.Path(HALT_FILE).unlink()
            # Persist runtime config for operators
            pathlib.Path(RUNTIME_CFG).write_text(json.dumps(data, indent=2))
            g_updates.inc()
        except Exception:
            pass
        await asyncio.sleep(int(os.getenv("CONFIG_POLL_INTERVAL_SEC","5")))

def create_app():
    app = web.Application()
    app.add_routes(routes)
    app.on_startup.append(lambda app: asyncio.create_task(loop_task()))
    return app

if __name__ == "__main__":
    web.run_app(create_app(), host="0.0.0.0", port=9106)
