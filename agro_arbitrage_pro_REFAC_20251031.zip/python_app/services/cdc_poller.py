
import os, asyncio, json
import asyncpg
import clickhouse_connect
from aiohttp import web
from prometheus_client import CollectorRegistry, Counter, generate_latest, CONTENT_TYPE_LATEST

PG_DSN = f"postgresql://{os.getenv('POSTGRES_USER','agro')}:{os.getenv('POSTGRES_PASSWORD','secret')}@{os.getenv('POSTGRES_HOST','postgres')}:{os.getenv('POSTGRES_PORT','5432')}/{os.getenv('POSTGRES_DB','agro')}"
CH_HOST = os.getenv("CLICKHOUSE_HOST","clickhouse")
CH_PORT = int(os.getenv("CLICKHOUSE_PORT","8123"))
CH_USER = os.getenv("CLICKHOUSE_USER","agro")
CH_PASS = os.getenv("CLICKHOUSE_PASSWORD","secret")
CH_DB   = os.getenv("CLICKHOUSE_DB","agro")

registry = CollectorRegistry()
c_rows = Counter("agro_cdc_rows","CDC rows shipped to ClickHouse", registry=registry)

routes = web.RouteTableDef()

@routes.get("/metrics")
async def metrics(_):
    return web.Response(body=generate_latest(registry), content_type=CONTENT_TYPE_LATEST)

async def pump():
    pg = await asyncpg.connect(PG_DSN)
    ch = clickhouse_connect.get_client(host=CH_HOST, port=CH_PORT, username=CH_USER, password=CH_PASS, database=CH_DB)
    last_id = 0
    while True:
        try:
            rows = await pg.fetch("SELECT id, ts, table_name, op, row_data FROM audit_log WHERE id > $1 ORDER BY id ASC LIMIT 1000", last_id)
            if rows:
                # Route to CH tables (example: send orders/trades to a generic log table)
                batch = [[r["ts"], r["table_name"], r["op"], json.dumps(dict(r["row_data"]))] for r in rows]
                ch.command("CREATE TABLE IF NOT EXISTS audit_log (ts DateTime, table_name String, op String, row_data String) ENGINE=MergeTree ORDER BY ts")
                ch.insert("audit_log", batch, column_names=["ts","table_name","op","row_data"])
                last_id = rows[-1]["id"]
                c_rows.inc(len(rows))
        except Exception:
            pass
        await asyncio.sleep(float(os.getenv("CDC_POLL_INTERVAL_SEC","1.0")))

def create_app():
    app = web.Application()
    app.add_routes(routes)
    app.on_startup.append(lambda app: asyncio.create_task(pump()))
    return app

if __name__ == "__main__":
    web.run_app(create_app(), host="0.0.0.0", port=9107)
