from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any
from datetime import datetime, timezone
from loguru import logger

@dataclass
class ExecFill:
    exec_id: str
    venue: str
    symbol: str
    side: str
    qty: float
    price: float
    fee: float
    fee_asset: str
    ts_exchange: datetime

class ReconWorkerV2:
    """Reconciliation & snapshots.
    Expects db with methods:
      - insert_recon_trade(...)
      - snapshot_position(...)
      - load_local_trades(venue) -> Dict[exec_id, row]
      - load_exchange_trades(venue) -> List[ExecFill]
      - load_positions_balances(venue) -> iterable
    """
    def __init__(self, db):
        self.db = db

    def write_snapshot(self, venue: str):
        rows = list(self.db.load_positions_balances(venue))
        now = datetime.now(timezone.utc)
        for r in rows:
            self.db.snapshot_position(
                venue=venue, asset=r["asset"], symbol=r["symbol"],
                position_qty=r["position_qty"], balance_free=r["balance_free"],
                balance_locked=r["balance_locked"], ts=now
            )
        logger.info(f"[recon] snapshot written: venue={venue}, count={len(rows)}")

    def reconcile(self, venue: str) -> Dict[str, int]:
        ex_trades: List[ExecFill] = list(self.db.load_exchange_trades(venue))
        local: Dict[str, Any] = dict(self.db.load_local_trades(venue))

        ex_ids = {t.exec_id for t in ex_trades}
        loc_ids = set(local.keys())

        missing = [t for t in ex_trades if t.exec_id not in loc_ids]
        extras = [eid for eid in loc_ids if eid not in ex_ids]

        for t in missing:
            self.db.insert_recon_trade(
                venue=t.venue, symbol=t.symbol, exec_id=t.exec_id,
                side=t.side, qty=t.qty, price=t.price,
                fee=t.fee, fee_asset=t.fee_asset,
                ts_exchange=t.ts_exchange
            )

        if missing or extras:
            logger.warning(f"[recon] mismatch venue={venue}: missing={len(missing)} extras={len(extras)}")
        else:
            logger.info(f"[recon] OK venue={venue}")

        return {"missing": len(missing), "extras": len(extras)}
