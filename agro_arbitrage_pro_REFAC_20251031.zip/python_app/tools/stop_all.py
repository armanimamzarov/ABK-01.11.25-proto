import json, os, signal, time
from pathlib import Path
from utils.logger import setup_logger
log = setup_logger(__name__)
PIDFILE = Path("logs/pids.json")
if not PIDFILE.exists():
    log.warning("pidfile not found: %s", PIDFILE)
    raise SystemExit(0)
pids = json.loads(PIDFILE.read_text(encoding="utf-8"))
for name, pid in pids.items():
    try:
        log.info("Killing %s pid=%s", name, pid)
        os.kill(int(pid), signal.SIGTERM)
    except Exception as e:
        log.warning("Could not kill %s: %s", name, e)
time.sleep(1)
try:
    PIDFILE.unlink()
except Exception:
    pass
log.info("All stop signals sent.")
