
import asyncio
from python_app.core.arbitrage_engine import ArbitrageEngine
from python_app.core.market_monitor import MarketMonitor
from python_app.core.execution_coordinator import ExecutionCoordinator
from python_app.observability.tracing import setup_logging
from python_app.core.recovery import RecoveryManager

async def main():
    setup_logging()
    engine = ArbitrageEngine()
    coord = ExecutionCoordinator(engine.risk_client)
    monitor = MarketMonitor()

    await engine.initialize()
    await monitor.start()  # starts background market data tasks
    await coord.start()
    await engine.run()

if __name__ == "__main__":
    asyncio.run(main())
