
import os, time, json, pathlib
import pandas as pd
import clickhouse_connect

CH_HOST = os.getenv("CLICKHOUSE_HOST","clickhouse")
CH_PORT = int(os.getenv("CLICKHOUSE_PORT","8123"))
CH_USER = os.getenv("CLICKHOUSE_USER","agro")
CH_PASS = os.getenv("CLICKHOUSE_PASSWORD","secret")
CH_DB   = os.getenv("CLICKHOUSE_DB","agro")

def get_client():
    return clickhouse_connect.get_client(host=CH_HOST, port=CH_PORT, username=CH_USER, password=CH_PASS, database=CH_DB)

def load_quotes_symbols(symbols=None, limit=1_000_000):
    client = get_client()
    where = ""
    if symbols:
        syms = ",".join([f"'{s}'" for s in symbols])
        where = f"WHERE symbol IN ({syms})"
    q = f"SELECT ts, exchange, symbol, bid, ask FROM quotes {where} ORDER BY ts DESC LIMIT {limit}"
    return client.query_df(q)

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    # Simple spreads & microstructure features
    df = df.sort_values(["symbol","ts"])
    df["mid"] = (df["bid"] + df["ask"])/2.0
    df["spread"] = (df["ask"] - df["bid"]).clip(lower=0)
    df["ret1"] = df.groupby("symbol")["mid"].pct_change().fillna(0.0)
    df["ret5"] = df.groupby("symbol")["mid"].pct_change(5).fillna(0.0)
    df["spr_rel"] = (df["spread"] / df["mid"]).fillna(0.0)
    df["side_imb"] = ((df["ask"]-df["mid"]) - (df["mid"]-df["bid"])) / df["spread"].replace(0, 1e-9)
    # Label: future move up in next k steps
    df["mid_f3"] = df.groupby("symbol")["mid"].shift(-3)
    df["y"] = (df["mid_f3"] > df["mid"]).astype(int)
    features = ["spread","ret1","ret5","spr_rel","side_imb"]
    return df.dropna(subset=features+["y"])[features+["y"]]
