
import os, numpy as np
from flaml import AutoML
from .feature_store import load_quotes_symbols, build_features
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
import logging
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    df = load_quotes_symbols(limit=300_000)
    feats = build_features(df)
    X = feats.drop(columns=["y"]).astype('float32').values
    y = feats["y"].values
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    automl = AutoML()
    automl.fit(Xtr, ytr, task="classification", time_budget=int(os.getenv("FLAML_TIME_BUDGET","300")))
    p = automl.predict_proba(Xte)[:,1]
    auc = roc_auc_score(yte, p)
logger.info("FLAML AUC:", auc)