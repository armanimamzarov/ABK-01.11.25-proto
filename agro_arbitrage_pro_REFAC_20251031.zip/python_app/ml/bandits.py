import math, json
from pathlib import Path

_global = {"bandit": None}

def set_global(b): _global["bandit"] = b
def get_global(): return _global.get("bandit")

class UCBBandit:
    def __init__(self, arms, c=2.0, state_file="logs/ml/bandit_state.json"):
        self.arms = list(arms); self.c = c; self.state_file = Path(state_file)
        self.rewards = {a:0.0 for a in self.arms}
        self.counts = {a:0 for a in self.arms}
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self._load()

    def _load(self):
        if self.state_file.exists():
            try:
                data = json.loads(self.state_file.read_text(encoding="utf-8"))
                self.rewards.update(data.get("rewards",{}))
                self.counts.update(data.get("counts",{}))
            except Exception:
                pass

    def _save(self):
        self.state_file.write_text(json.dumps({"rewards":self.rewards,"counts":self.counts}, indent=2), encoding="utf-8")

    def select(self, t):
        # ensure each arm tried at least once
        for a in self.arms:
            if self.counts.get(a,0)==0:
                return a, 1.0
        total = max(1, sum(self.counts.values()))
        best = None; best_score = -1e9
        for a in self.arms:
            n = max(1, self.counts.get(a,0))
            avg = self.rewards.get(a,0.0)/n
            import math
            bonus = self.c*math.sqrt(math.log(total)/n)
            s = avg + bonus
            if s > best_score:
                best, best_score = a, s
        return best, best_score

    def update(self, arm, reward):
        if arm not in self.counts: 
            self.arms.append(arm); self.counts[arm]=0; self.rewards[arm]=0.0
        self.counts[arm]+=1; self.rewards[arm]+=float(reward); self._save()
