
import os, json, pathlib, time
import numpy as np
import pandas as pd
from .feature_store import load_quotes_symbols, build_features
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
import lightgbm as lgb
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import logging
logger = logging.getLogger(__name__)

OUT_PATH = os.getenv("AGRO_AUTOML_OUT","/models/risk.onnx")

def train_and_export(symbols=None, max_rows=500_000):
    df = load_quotes_symbols(symbols, limit=max_rows)
    feats = build_features(df)
    X = feats.drop(columns=["y"]).astype(np.float32).values
    y = feats["y"].values
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    dtrain = lgb.Dataset(Xtr, label=ytr)
    params = dict(objective="binary", boosting_type="gbdt", num_leaves=64, learning_rate=0.05, n_estimators=500, subsample=0.8, colsample_bytree=0.8)
    model = lgb.train(params, dtrain, num_boost_round=400)
    # Evaluate
    p = model.predict(Xte)
    auc = roc_auc_score(yte, p)
logger.info(f"AUC={auc:.4f}")
    # Convert to ONNX (wrap via scikit API)
    from sklearn.ensemble import GradientBoostingClassifier
    # Quick bridge: use LightGBMClassifier wrapper for ONNX via sklearn-API
    from lightgbm import LGBMClassifier
    sk = LGBMClassifier(num_leaves=64, learning_rate=0.05, n_estimators=400, subsample=0.8, colsample_bytree=0.8)
    sk.fit(Xtr, ytr)
    initial_types = [("input", FloatTensorType([None, Xtr.shape[1]]))]
    onx = convert_sklearn(sk, initial_types=initial_types, target_opset=17)
    pathlib.Path(OUT_PATH).parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_PATH, "wb") as f:
        f.write(onx.SerializeToString())
logger.info(f"Saved ONNX to {OUT_PATH}")
    return dict(auc=float(auc), path=OUT_PATH, n_features=Xtr.shape[1])

if __name__ == "__main__":
    train_and_export()