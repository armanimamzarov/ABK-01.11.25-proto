
import os, optuna, numpy as np
from .feature_store import load_quotes_symbols, build_features
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from lightgbm import LGBMClassifier
import logging
logger = logging.getLogger(__name__)

def objective(trial):
    df = load_quotes_symbols(limit=300_000)
    feats = build_features(df)
    X = feats.drop(columns=["y"]).astype(np.float32).values
    y = feats["y"].values
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    params = dict(
        num_leaves = trial.suggest_int("num_leaves", 31, 255),
        learning_rate = trial.suggest_float("learning_rate", 1e-3, 0.2, log=True),
        n_estimators = trial.suggest_int("n_estimators", 200, 1500),
        subsample = trial.suggest_float("subsample", 0.5, 1.0),
        colsample_bytree = trial.suggest_float("colsample_bytree", 0.5, 1.0)
    )
    model = LGBMClassifier(**params)
    model.fit(Xtr, ytr)
    p = model.predict_proba(Xte)[:,1]
    auc = roc_auc_score(yte, p)
    return auc

if __name__ == "__main__":
    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=int(os.getenv("OPTUNA_TRIALS","30")))
logger.info("Best params:", study.best_params)