
import threading, time
from typing import Callable, Dict, Optional

class WSManager:
    def __init__(self, on_snapshot:Callable, on_delta:Callable, heartbeat_seconds:int=15):
        self.on_snapshot = on_snapshot
        self.on_delta = on_delta
        self.heartbeat_seconds = heartbeat_seconds
        self._last_msg = time.time()
        self._stop=False
        self._thread = threading.Thread(target=self._run, daemon=True)
    def start(self):
        self._thread.start()
    def _run(self):
        # Simulate periodic deltas and heartbeats
        self.on_snapshot({"symbol":"BTC/USDT","bids":[[100,1.0]],"asks":[[101,1.0]],"ts":time.time_ns()})
        while not self._stop:
            time.sleep(1.0)
            self._last_msg = time.time()
            self.on_delta({"symbol":"BTC/USDT","bids":[[100,1.1]],"asks":[[101,0.9]],"ts":time.time_ns()})
            if time.time() - self._last_msg > self.heartbeat_seconds:
                # reconnect hook could be here
                pass
    def stop(self):
        self._stop=True
        self._thread.join(timeout=0.2)
