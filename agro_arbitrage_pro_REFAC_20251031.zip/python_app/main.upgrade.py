
import threading, time
from exchanges.dummy import get as dummy_ex
from engine.execution_gateway import ExecutionGateway
from telemetry.server import serve_metrics, ORDERS_TOTAL, ORDER_LATENCY
from risk.risk_hub import RiskHub, RiskConfig
import logging
logger = logging.getLogger(__name__)

def run_metrics():
    serve_metrics(9102)

def main():
    # metrics
    mt = threading.Thread(target=run_metrics, daemon=True)
    mt.start()
    # risk
    risk = RiskHub(RiskConfig())
    # exchanges
    exs = {"DUMMY": dummy_ex()}
    gw = ExecutionGateway(exs)
    # simulate order flow
    start = time.time()
    ORDERS_TOTAL.labels("DUMMY","BTC/USDT","buy").inc()
    with ORDER_LATENCY.time():
        coid = gw.submit_order(exchange="DUMMY", symbol="BTC/USDT", side="buy", qty=0.1, price=None, ord_type="MARKET")
    time.sleep(0.5)
    # idempotency check
    coid2 = gw.submit_order(exchange="DUMMY", symbol="BTC/USDT", side="buy", qty=0.1, price=None, ord_type="MARKET", client_order_id=coid)
logger.info("submitted:", coid, coid2)
    time.sleep(2.0)

if __name__ == "__main__":
    main()