
from loguru import logger

class PortfolioAllocator:
    def __init__(self):
        self.max_per_trade_usd = 200

    def size(self, symbol, price):
        # simple $ exposure sizing
        qty = self.max_per_trade_usd / max(price, 1e-9)
        logger.debug(f"Sized {qty} for {symbol} at {price}")
        return qty
