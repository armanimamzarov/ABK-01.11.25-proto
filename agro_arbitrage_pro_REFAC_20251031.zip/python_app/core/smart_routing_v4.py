
import random

class SmartRouter:
    def __init__(self):
        self.pref = ["binance", "bybit", "okx", "kucoin", "gateio", "mexc"]

    def choose(self, symbol, side):
        # Naive: rotate among preferred exchanges
        return random.choice(self.pref)
