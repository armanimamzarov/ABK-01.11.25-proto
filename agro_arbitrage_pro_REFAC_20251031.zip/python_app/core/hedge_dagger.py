import time

class OrphanHedge:
    def __init__(self, orphan_timeout_ms=1200, max_orphan_notional=50.0, sender=None):
        self.timeout_ms = orphan_timeout_ms
        self.max_notional = max_orphan_notional
        self.sender = sender

    def guard(self, leg_state):
        # leg_state: dict with fields: notional, created_ms, hedged
        now_ms = int(time.time()*1000)
        if leg_state.get("hedged"):
            return
        if leg_state["notional"] > self.max_notional:  # immediate close
            self.sender.close_orphan(leg_state)
        elif now_ms - leg_state["created_ms"] > self.timeout_ms:
            self.sender.close_orphan(leg_state)
