
import asyncio, json
from pathlib import Path
from loguru import logger
import aioredis
from python_app.core.strategy_state import StrategyState
from python_app.core.smart_routing_v4 import SmartRouter
from python_app.core.portfolio_allocator import PortfolioAllocator
from python_app.risk_management.arbitrage_risk_engine import RiskClient
from python_app.strategies import (
    triangular_arb, cross_exchange_arb, cash_and_carry, spread_scalping,
    synthetic_arb, volatility_rebalance, stable_spread_arb, liquidity_pulse,
    stat_arb, funding_arbitrage, mean_reversion_bands
)
from python_app.config.validator import validate
from python_app.observability.alerts import send as tg_send

class ArbitrageEngine:
    def __init__(self):
        cfg = json.loads(Path("configs/system.json").read_text())
        self.state = StrategyState()
        self.router = SmartRouter()
        self.portfolio = PortfolioAllocator()
        self.risk_client = RiskClient(host=cfg.get("grpc_host","0.0.0.0"), port=cfg.get("grpc_port",50051))
        self.redis = None
        self.strategies = [
            triangular_arb.Strategy(self.router, self.risk_client, self.portfolio),
            cross_exchange_arb.Strategy(self.router, self.risk_client, self.portfolio),
            cash_and_carry.Strategy(self.router, self.risk_client, self.portfolio),
            spread_scalping.Strategy(self.router, self.risk_client, self.portfolio),
            synthetic_arb.Strategy(self.router, self.risk_client, self.portfolio),
            volatility_rebalance.Strategy(self.router, self.risk_client, self.portfolio),
            stable_spread_arb.Strategy(self.router, self.risk_client, self.portfolio),
            liquidity_pulse.Strategy(self.router, self.risk_client, self.portfolio),
            stat_arb.Strategy(self.router, self.risk_client, self.portfolio),
            funding_arbitrage.Strategy(self.router, self.risk_client, self.portfolio),
            mean_reversion_bands.Strategy(self.router, self.risk_client, self.portfolio),
        ]

    async def initialize(self):
        errs = validate()
        if errs:
            raise RuntimeError("Config validation errors: \n" + "\n".join(errs))
        logger.info("Connecting risk client...")
        await self.risk_client.connect()
        self.redis = await aioredis.from_url("redis://redis:6379", decode_responses=True)
        await tg_send("AGRO v6 started")

    async def run(self):
        logger.info("Running strategies...")
        tasks = [asyncio.create_task(s.run()) for s in self.strategies]
        try:
            await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            logger.info("Shutdown requested")
        finally:
            await tg_send("AGRO v6 stopped")
