from dataclasses import dataclass

@dataclass
class CoFPolicy:
    on_ws_disconnect_cancel_open: bool = True
    on_rest_5xx_cancel_open: bool = True
    on_auth_error_cancel_open: bool = True

DEFAULT = {
    "binance": CoFPolicy(on_ws_disconnect_cancel_open=True),
    "okx": CoFPolicy(on_ws_disconnect_cancel_open=True),
    "bybit": CoFPolicy(on_ws_disconnect_cancel_open=True),
}
