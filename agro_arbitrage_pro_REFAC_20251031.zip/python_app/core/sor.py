from dataclasses import dataclass
from typing import List

@dataclass
class VenueQuote:
    venue: str
    bid: float
    ask: float
    latency_ms: float
    taker_fee_bps: float
    expected_slip_bps: float

def score(quote: VenueQuote, side: str, edge_bps: float,
          w_lat: float=0.3, w_fee: float=0.4, w_slip: float=0.3) -> float:
    # Higher score is better for execution venue
    cost = quote.taker_fee_bps*w_fee + quote.expected_slip_bps*w_slip + (quote.latency_ms/10.0)*w_lat
    return edge_bps - cost

def choose(venues: List[VenueQuote], side: str, edge_bps: float) -> str:
    best = max(venues, key=lambda v: score(v, side, edge_bps))
    return best.venue
