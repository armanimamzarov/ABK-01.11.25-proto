
class StrategyState:
    def __init__(self):
        self.positions = {}
        self.last_signals = {}
