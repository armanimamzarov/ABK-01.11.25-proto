
import asyncio
from loguru import logger
from python_app.exchanges.binance_handler import BinanceExchange
from python_app.exchanges.bybit_handler import BybitExchange
from python_app.exchanges.okx_handler import OKXExchange
from python_app.exchanges.kucoin_handler import KucoinExchange
from python_app.exchanges.gateio_handler import GateIOExchange
from python_app.exchanges.mexc_handler import MEXCExchange

class ExecutionCoordinator:
    def __init__(self, risk_client):
        self.risk = risk_client
        self.exchanges = {
            "binance": BinanceExchange(),
            "bybit": BybitExchange(),
            "okx": OKXExchange(),
            "kucoin": KucoinExchange(),
            "gateio": GateIOExchange(),
            "mexc": MEXCExchange(),
        }

    async def start(self):
        logger.info("ExecutionCoordinator ready.")

    async def place(self, strategy, exchange, symbol, side, qty, price=None, order_type="LIMIT"):
        allowed, reason = await self.risk.validate(strategy, exchange, symbol, side, qty, price or 0.0, order_type)
        if not allowed:
            logger.warning(f"Order rejected by risk: {reason}")
            return {"status":"rejected","reason":reason}
        handler = self.exchanges[exchange]
        return await handler.place_order(symbol, side, qty, price, order_type)

    async def cancel(self, exchange, order_id, symbol):
        handler = self.exchanges[exchange]
        return await handler.cancel_order(order_id, symbol)
