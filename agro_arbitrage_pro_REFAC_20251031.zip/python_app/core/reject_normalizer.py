import json
from pathlib import Path

CODES = json.loads(Path("configs/reject_codes.json").read_text())

def normalize(venue: str, code: str) -> str:
    t = CODES.get(venue.lower(), {})
    for cat, arr in t.items():
        if str(code) in arr:
            return cat
    return "UNKNOWN"
