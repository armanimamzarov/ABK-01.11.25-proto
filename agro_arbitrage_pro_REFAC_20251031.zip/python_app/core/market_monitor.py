
import asyncio
import json
from pathlib import Path
from loguru import logger
import websockets
import pandas as pd

class MarketMonitor:
    def __init__(self):
        cfg = json.loads(Path("configs/exchanges.json").read_text())
        self.binance_ws = cfg["binance"]["ws_base"]

    async def start(self):
        asyncio.create_task(self._binance_depth_task("btcusdt"))

    async def _binance_depth_task(self, symbol: str):
        url = f"{self.binance_ws}/{symbol}@depth5@100ms"
        while True:
            try:
                async with websockets.connect(url) as ws:
                    logger.info(f"Subscribed to {symbol} depth5")
                    async for msg in ws:
                        _ = msg  # could fan out to strategies via shared state / redis
            except Exception as e:
                logger.error(f"Binance WS error: {e}; reconnecting in 2s")
                await asyncio.sleep(2)
