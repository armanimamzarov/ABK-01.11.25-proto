import time

class MDQualityGate:
    def __init__(self, max_seq_gap=2, max_stale_ms=800):
        self.max_seq_gap = max_seq_gap
        self.max_stale_ms = max_stale_ms
        self.last_seq = None
        self.last_ts_ms = 0

    def on_snapshot(self, seq, ts_ms):
        self.last_seq = seq
        self.last_ts_ms = ts_ms

    def on_delta(self, seq, ts_ms):
        stale = (int(time.time()*1000) - ts_ms) > self.max_stale_ms
        gap = (self.last_seq is not None) and (seq - self.last_seq > self.max_seq_gap)
        self.last_seq = seq
        self.last_ts_ms = ts_ms
        return not (stale or gap)  # True if allowed to trade
