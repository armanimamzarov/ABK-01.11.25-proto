import time
from collections import defaultdict, deque

class TokenBucket:
    def __init__(self, capacity, refill_per_sec):
        self.capacity = capacity
        self.tokens = capacity
        self.refill_per_sec = refill_per_sec
        self.updated = time.time()

    def allow(self, cost=1):
        now = time.time()
        self.tokens = min(self.capacity, self.tokens + (now - self.updated)*self.refill_per_sec)
        self.updated = now
        if self.tokens >= cost:
            self.tokens -= cost
            return True
        return False

class RateLimiter:
    def __init__(self):
        self.buckets = defaultdict(dict)  # buckets[venue][endpoint] = bucket

    def register(self, venue, endpoint, capacity, refill):
        self.buckets[venue][endpoint] = TokenBucket(capacity, refill)

    def allow(self, venue, endpoint, cost=1):
        b = self.buckets[venue].get(endpoint)
        return b.allow(cost) if b else True
