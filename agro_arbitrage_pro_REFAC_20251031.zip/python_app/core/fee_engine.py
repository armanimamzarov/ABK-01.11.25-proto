from dataclasses import dataclass

@dataclass
class FeeProfile:
    taker_bps: float
    maker_bps: float
    funding_bps_per_day: float = 0.0
    borrow_bps_per_day: float = 0.0

def net_edge_bps(raw_edge_bps: float, fee: FeeProfile, slip_bps: float) -> float:
    return raw_edge_bps - fee.taker_bps - slip_bps
