from dataclasses import dataclass

@dataclass
class RiskModeState:
    reduce_only: bool = False
    quotes_only: bool = False
    kill_switch_tripped: bool = False

class RiskModeController:
    def __init__(self, reduce_only_on_trip: bool = True):
        self.state = RiskModeState()
        self.reduce_only_on_trip = reduce_only_on_trip

    def trip_kill_switch(self):
        self.state.kill_switch_tripped = True
        if self.reduce_only_on_trip:
            self.state.reduce_only = True

    def reset(self):
        self.state = RiskModeState(reduce_only=self.reduce_only_on_trip)

    def allow_new_position(self) -> bool:
        if self.state.kill_switch_tripped and self.reduce_only_on_trip:
            return False
        if self.state.quotes_only:
            return False
        return True

    def allow_close(self) -> bool:
        return True
