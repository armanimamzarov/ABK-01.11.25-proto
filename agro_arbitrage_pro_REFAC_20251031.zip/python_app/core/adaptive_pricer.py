from dataclasses import dataclass

@dataclass
class BookTop:
    bid: float
    ask: float
    bid_qty: float
    ask_qty: float
    mid_volatility: float  # annualized or short-term proxy
    book_speed: float      # book updates per second

class AdaptivePricer:
    def __init__(self, max_spread_bps: float = 5.0):
        self.max_spread_bps = max_spread_bps

    def limit_price(self, side: str, top: BookTop) -> float:
        # dynamic cushion: function of vol & speed and available qty
        cushion_bps = min(self.max_spread_bps, 0.5 + 2.0*top.mid_volatility + 0.1*top.book_speed)
        if side.upper() == "BUY":
            px = min(top.ask, top.bid * (1 + cushion_bps/10000.0))
        else:
            px = max(top.bid, top.ask * (1 - cushion_bps/10000.0))
        return round(px, 8)
