import time

class ClockGuard:
    def __init__(self, max_skew_ms=1500):
        self.max_skew_ms = max_skew_ms

    def check(self, exchange_time_ms: int) -> bool:
        local_ms = int(time.time()*1000)
        return abs(local_ms - exchange_time_ms) <= self.max_skew_ms
